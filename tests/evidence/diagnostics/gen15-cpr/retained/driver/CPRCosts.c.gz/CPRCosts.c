// Lean compiler output
// Module: review.diagnostics.CPRCosts
// Imports: public import Init public meta import Init public import Impl public import Impl.JSON public import Lean.Data.Json.Parser public import Lean.Data.Json.FromToJson.Basic
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_string_append(lean_object*, lean_object*);
double lp_lean1090_Lean1090_Impl_CPR_Policy_toFloat(lean_object*);
uint64_t lean_float_to_bits(double);
lean_object* lean_uint64_to_nat(uint64_t);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_push(lean_object*, uint32_t);
lean_object* lean_get_stdout();
lean_object* l_IO_FS_readFile(lean_object*);
lean_object* l_Lean_Json_parse(lean_object*);
lean_object* l_IO_ofExcept___at___00Std_Time_Database_TZdb_parseTZIfFromDisk_spec__0___redArg(lean_object*);
lean_object* l_Lean_Json_getArr_x3f(lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
size_t lean_array_size(lean_object*);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* l_Lean_Json_getObjVal_x3f(lean_object*, lean_object*);
lean_object* l_Lean_Json_getNum_x3f(lean_object*);
lean_object* l_Rat_ofInt(lean_object*);
lean_object* lean_nat_pow(lean_object*, lean_object*);
lean_object* l_Nat_cast___at___00Std_Http_Internal_Test_defaultConfig_spec__0(lean_object*);
lean_object* l_Rat_div(lean_object*, lean_object*);
lean_object* lp_lean1090_Lean1090_Impl_Binary64_round(lean_object*);
extern lean_object* lp_lean1090_Lean1090_Impl_Binary64_maxFinite;
lean_object* l_Rat_abs(lean_object*);
uint8_t l_Rat_blt(lean_object*, lean_object*);
lean_object* l_Lean_Json_getStr_x3f(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
lean_object* lp_lean1090_Lean1090_Spec_instReprMessage_repr___redArg(lean_object*);
lean_object* l_Std_Format_pretty(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_string_to_utf8(lean_object*);
lean_object* lean_byte_array_data(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
uint64_t lean_uint8_to_uint64(uint8_t);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
uint64_t lean_uint64_mul(uint64_t, uint64_t);
lean_object* lean_byte_array_size(lean_object*);
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
lean_object* lean_array_mk(lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
lean_object* lp_lean1090_Lean1090_Impl_JSON_raw(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
lean_object* l_Rat_floor(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_get_stdin();
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_trimAscii(lean_object*);
lean_object* l_String_Slice_toString(lean_object*);
lean_object* lp_lean1090_Lean1090_Impl_CPR_Policy_streamStep(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_String_splitOnAux(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_List_zipIdxTR___redArg(lean_object*, lean_object*);
lean_object* lean_string_data(lean_object*);
uint8_t lean_uint32_dec_le(uint32_t, uint32_t);
lean_object* lean_uint32_to_nat(uint32_t);
lean_object* lean_nat_mul(lean_object*, lean_object*);
uint8_t lean_uint8_of_nat(lean_object*);
lean_object* lean_string_length(lean_object*);
lean_object* l_List_drop___redArg(lean_object*, lean_object*);
lean_object* lean_string_mk(lean_object*);
uint8_t lean_string_memcmp(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_String_Slice_Pos_prevn(lean_object*, lean_object*, lean_object*);
lean_object* l_List_lengthTR___redArg(lean_object*);
lean_object* lp_lean1090_Lean1090_Impl_decode(lean_object*);
lean_object* lp_lean1090_Lean1090_Spec_CPR_instDecidableEqPosition___boxed(lean_object*, lean_object*);
uint8_t l_Option_instDecidableEq___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_lean1090_Lean1090_Spec_CPR_Policy_instReprStreamState_repr___redArg(lean_object*);
lean_object* l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(lean_object*, lean_object*);
lean_object* l_Lean_JsonNumber_fromInt(lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* l_String_intercalate(lean_object*, lean_object*);
lean_object* l_IO_FS_writeFile(lean_object*, lean_object*);
lean_object* lp_lean1090_Lean1090_Impl_CPR_Policy_decodePositions(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lp_lean1090_Lean1090_Spec_CPR_Policy_instDecidableEqStreamState_decEq(lean_object*, lean_object*);
uint8_t l_instDecidableEqList___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_uint8_to_nat(uint8_t);
lean_object* l_IO_eprintln___at___00__private_Init_System_IO_0__IO_eprintlnAux_spec__0(lean_object*);
lean_object* lp_lean1090_Lean1090_Impl_CPR_Policy_numericalGeography(lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_expectedMessages;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_airportPath___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 47, .m_capacity = 47, .m_length = 46, .m_data = "vendor/rs1090/crates/rs1090/data/airports.json"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_airportPath___closed__0 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_airportPath___closed__0_value;
LEAN_EXPORT const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_airportPath = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_airportPath___closed__0_value;
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_nibble(uint32_t);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_nibble___boxed(lean_object*);
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hexBytes___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hexBytes___closed__0 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hexBytes___closed__0_value;
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hexBytes(lean_object*);
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "non-finite input number"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number___closed__0 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number___closed__0_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number___closed__0_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number___closed__1 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number___closed__1_value;
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number(lean_object*);
static const lean_string_object l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "line "};
static const lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__0 = (const lean_object*)&l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__0_value;
static const lean_string_object l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = ": expected timestamp,frame"};
static const lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__1 = (const lean_object*)&l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__1_value;
static const lean_string_object l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 28, .m_capacity = 28, .m_length = 27, .m_data = ": invalid hexadecimal digit"};
static const lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__2 = (const lean_object*)&l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__2_value;
static const lean_string_object l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = ": expected 7 or 14 message bytes"};
static const lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__3 = (const lean_object*)&l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__3_value;
static const lean_string_object l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = ","};
static const lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__4 = (const lean_object*)&l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__4_value;
static const lean_string_object l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = ": missing Beast prefix"};
static const lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__5 = (const lean_object*)&l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__5_value;
static const lean_string_object l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "\r"};
static const lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__6 = (const lean_object*)&l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__6_value;
static lean_once_cell_t l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__7;
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "\n"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs___closed__0 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs___closed__0_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected 172432 messages, found "};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs___closed__1 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs___closed__1_value;
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs(lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "lon"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___closed__0 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___closed__0_value;
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "lat"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___closed__1 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___closed__1_value;
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "icao"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___closed__2 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___closed__2_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "expected 6903 pinned airports"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports___closed__0 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports___closed__0_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports___closed__0_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports___closed__1 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports___closed__1_value;
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports();
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports___boxed(lean_object*);
static const lean_string_object l_List_find_x3f___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "altitude_feet"};
static const lean_object* l_List_find_x3f___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport_spec__0___closed__0 = (const lean_object*)&l_List_find_x3f___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport_spec__0___closed__0_value;
LEAN_EXPORT lean_object* l_List_find_x3f___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_List_find_x3f___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport_spec__0___boxed(lean_object*);
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "tc"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__0 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__0_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "parity"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__1 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__1_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "lat_cpr"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__2 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__2_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "lon_cpr"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__3 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__3_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "time_sync"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__4 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__4_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "ss"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__5 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__5_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "saf_or_nicb"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__6 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__6_value;
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance___lam__0(lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance___lam__0___boxed(lean_object*);
static const lean_closure_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance___closed__0 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance___closed__0_value;
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_floatBits(lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0_spec__0_spec__1(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0_spec__0_spec__1___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0(lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson(lean_object*);
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit(lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit___boxed(lean_object*, lean_object*);
static const lean_string_object l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "poll"};
static const lean_object* l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg___closed__0 = (const lean_object*)&l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg___closed__0_value;
static const lean_string_object l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "expected command "};
static const lean_object* l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg___closed__1 = (const lean_object*)&l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg___closed__1_value;
LEAN_EXPORT lean_object* l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg(lean_object*);
LEAN_EXPORT lean_object* l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command(uint8_t, lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 34, .m_capacity = 34, .m_length = 33, .m_data = "decoder rejected a corpus message"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0___closed__0 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0___closed__0_value;
static const lean_ctor_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0___closed__0_value)}};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0___closed__1 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0___closed__1_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object l_Lean1090_Diagnostics_CPRCosts_runCPR___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_Lean1090_Diagnostics_CPRCosts_runCPR___closed__0 = (const lean_object*)&l_Lean1090_Diagnostics_CPRCosts_runCPR___closed__0_value;
LEAN_EXPORT lean_object* l_Lean1090_Diagnostics_CPRCosts_runCPR(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean1090_Diagnostics_CPRCosts_runCPR___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint64_t l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes_spec__0(lean_object*, size_t, size_t, uint64_t);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint64_t l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes(uint64_t, lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Option_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Option_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__1(lean_object*);
LEAN_EXPORT uint8_t l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__2(uint8_t, lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__2___boxed(lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "missing batch-check input"};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg___closed__0 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg___closed__0_value;
static const lean_ctor_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg___closed__0_value)}};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg___closed__1 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg___closed__1_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__4_spec__4_spec__5(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__4_spec__4_spec__5___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__4_spec__4(lean_object*);
LEAN_EXPORT lean_object* l_Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__4(lean_object*);
static const lean_string_object l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "address"};
static const lean_object* l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__0 = (const lean_object*)&l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__0_value;
static const lean_string_object l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "position"};
static const lean_object* l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__1 = (const lean_object*)&l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__1_value;
static const lean_string_object l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "altitude"};
static const lean_object* l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__2 = (const lean_object*)&l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__2_value;
static const lean_string_object l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "airport"};
static const lean_object* l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__3 = (const lean_object*)&l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__3_value;
static const lean_string_object l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "seen"};
static const lean_object* l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__4 = (const lean_object*)&l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__4_value;
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3(lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "id"};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__0 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__0_value;
static const lean_string_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "routed"};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__1 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__1_value;
static const lean_string_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "missing retained input"};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__2 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__2_value;
static const lean_ctor_object l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__2_value)}};
static const lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__3 = (const lean_object*)&l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__3_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "phase"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__0 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__0_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "result"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__1 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__1_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__1_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__2 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__2_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__0_value),((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__2_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__3 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__3_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "mode"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__4 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__4_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "all"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__5 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__5_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__5_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__6 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__6_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__4_value),((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__6_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__7 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__7_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "digest"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__8 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__8_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "count"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__9 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__9_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "repr_bytes"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__10 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__10_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "fnv1a64_decimal"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__11 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__11_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "positions"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__12 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__12_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "airborne"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__13 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__13_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "surface"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__14 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__14_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "other"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__15 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__15_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "final_state"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__16 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__16_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 22, .m_capacity = 22, .m_length = 21, .m_data = "full_state_repr_bytes"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__17 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__17_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "full_state_fnv1a64_decimal"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__18 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__18_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "batch_state_check"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__19 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__19_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 53, .m_capacity = 53, .m_length = 52, .m_data = "full state/position mismatch against live batch fold"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__20 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__20_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__20_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__21 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__21_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "incomplete retained output"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__22 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__22_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__22_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__23 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__23_value;
static const lean_closure_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__24 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__24_value;
static const lean_closure_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__1___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__25 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__25_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__26_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "final"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__26 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__26_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__27_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "reference"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__27 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__27_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__28_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "aircraft"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__28 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__28_value;
static const lean_closure_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__29_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__2___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__29 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__29_value;
static const lean_array_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__30_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__30 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__30_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__31_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__30_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__31 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__31_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__32_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__31_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__32 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__32_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__33_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__32_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__33 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__33_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__34_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__33_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__34 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__34_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__35_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__34_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__35 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__35_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__36_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__35_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__36 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__36_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__37___boxed__const__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 0}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(37, 35, 34, 132, 228, 156, 242, 203)}};
LEAN_EXPORT const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__37___boxed__const__1 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__37___boxed__const__1_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__37_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__37___boxed__const__1_value),((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__36_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__37 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__37_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__38_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__38 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__38_value;
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__1(lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__2___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = " "};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__2___closed__0 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__2___closed__0_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__2(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__0___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "prepared"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__0 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__0_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__0_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__1 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__1_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__0_value),((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__1_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__2 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__2_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "selected"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__3 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__3_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "airports"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__4 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__4_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__27_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__5 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__5_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "update_reference"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__6 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__6_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "run"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__7 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__7_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "decoded"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__8 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__8_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__8_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__9 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__9_value;
static const lean_ctor_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__0_value),((lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__9_value)}};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__10 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__10_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "retained"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__11 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__11_value;
static const lean_string_object l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "consume"};
static const lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__12 = (const lean_object*)&l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__12_value;
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute(lean_object*, uint8_t, lean_object*, uint8_t, uint8_t);
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 91, .m_capacity = 91, .m_length = 90, .m_data = "usage: cpr-costs all CORPUS [--wait|--audit FILE] | --audit-inputs|--audit-airports CORPUS"};
static const lean_object* l_main___closed__0 = (const lean_object*)&l_main___closed__0_value;
static const lean_string_object l_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "--audit-inputs"};
static const lean_object* l_main___closed__1 = (const lean_object*)&l_main___closed__1_value;
static const lean_string_object l_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "--audit-airports"};
static const lean_object* l_main___closed__2 = (const lean_object*)&l_main___closed__2_value;
static const lean_string_object l_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "--wait"};
static const lean_object* l_main___closed__3 = (const lean_object*)&l_main___closed__3_value;
static const lean_string_object l_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "--audit"};
static const lean_object* l_main___closed__4 = (const lean_object*)&l_main___closed__4_value;
LEAN_EXPORT lean_object* l_main___boxed__const__1;
LEAN_EXPORT lean_object* l_main___boxed__const__2;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* l_main___boxed(lean_object*, lean_object*);
static lean_object* _init_l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_expectedMessages(void){
_start:
{
lean_object* v___x_1_; 
v___x_1_ = lean_unsigned_to_nat(172432u);
return v___x_1_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_nibble(uint32_t v_c_4_){
_start:
{
uint32_t v___x_25_; uint8_t v___x_26_; 
v___x_25_ = 48;
v___x_26_ = lean_uint32_dec_le(v___x_25_, v_c_4_);
if (v___x_26_ == 0)
{
goto v___jp_16_;
}
else
{
uint32_t v___x_27_; uint8_t v___x_28_; 
v___x_27_ = 57;
v___x_28_ = lean_uint32_dec_le(v_c_4_, v___x_27_);
if (v___x_28_ == 0)
{
goto v___jp_16_;
}
else
{
lean_object* v___x_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; 
v___x_29_ = lean_unsigned_to_nat(48u);
v___x_30_ = lean_uint32_to_nat(v_c_4_);
v___x_31_ = lean_nat_sub(v___x_30_, v___x_29_);
lean_dec(v___x_30_);
v___x_32_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_32_, 0, v___x_31_);
return v___x_32_;
}
}
v___jp_5_:
{
uint32_t v___x_6_; uint8_t v___x_7_; 
v___x_6_ = 65;
v___x_7_ = lean_uint32_dec_le(v___x_6_, v_c_4_);
if (v___x_7_ == 0)
{
lean_object* v___x_8_; 
v___x_8_ = lean_box(0);
return v___x_8_;
}
else
{
uint32_t v___x_9_; uint8_t v___x_10_; 
v___x_9_ = 70;
v___x_10_ = lean_uint32_dec_le(v_c_4_, v___x_9_);
if (v___x_10_ == 0)
{
lean_object* v___x_11_; 
v___x_11_ = lean_box(0);
return v___x_11_;
}
else
{
lean_object* v___x_12_; lean_object* v___x_13_; lean_object* v___x_14_; lean_object* v___x_15_; 
v___x_12_ = lean_uint32_to_nat(v_c_4_);
v___x_13_ = lean_unsigned_to_nat(55u);
v___x_14_ = lean_nat_sub(v___x_12_, v___x_13_);
lean_dec(v___x_12_);
v___x_15_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_15_, 0, v___x_14_);
return v___x_15_;
}
}
}
v___jp_16_:
{
uint32_t v___x_17_; uint8_t v___x_18_; 
v___x_17_ = 97;
v___x_18_ = lean_uint32_dec_le(v___x_17_, v_c_4_);
if (v___x_18_ == 0)
{
goto v___jp_5_;
}
else
{
uint32_t v___x_19_; uint8_t v___x_20_; 
v___x_19_ = 102;
v___x_20_ = lean_uint32_dec_le(v_c_4_, v___x_19_);
if (v___x_20_ == 0)
{
goto v___jp_5_;
}
else
{
lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; 
v___x_21_ = lean_uint32_to_nat(v_c_4_);
v___x_22_ = lean_unsigned_to_nat(87u);
v___x_23_ = lean_nat_sub(v___x_21_, v___x_22_);
lean_dec(v___x_21_);
v___x_24_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_24_, 0, v___x_23_);
return v___x_24_;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_nibble___boxed(lean_object* v_c_33_){
_start:
{
uint32_t v_c_boxed_34_; lean_object* v_res_35_; 
v_c_boxed_34_ = lean_unbox_uint32(v_c_33_);
lean_dec(v_c_33_);
v_res_35_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_nibble(v_c_boxed_34_);
return v_res_35_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hexBytes(lean_object* v_x_38_){
_start:
{
if (lean_obj_tag(v_x_38_) == 0)
{
lean_object* v___x_39_; 
v___x_39_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hexBytes___closed__0));
return v___x_39_;
}
else
{
lean_object* v_tail_40_; 
v_tail_40_ = lean_ctor_get(v_x_38_, 1);
lean_inc(v_tail_40_);
if (lean_obj_tag(v_tail_40_) == 1)
{
lean_object* v_head_41_; lean_object* v_head_42_; lean_object* v_tail_43_; lean_object* v___x_45_; uint8_t v_isShared_46_; uint8_t v_isSharedCheck_72_; 
v_head_41_ = lean_ctor_get(v_x_38_, 0);
lean_inc(v_head_41_);
lean_dec_ref_known(v_x_38_, 2);
v_head_42_ = lean_ctor_get(v_tail_40_, 0);
v_tail_43_ = lean_ctor_get(v_tail_40_, 1);
v_isSharedCheck_72_ = !lean_is_exclusive(v_tail_40_);
if (v_isSharedCheck_72_ == 0)
{
v___x_45_ = v_tail_40_;
v_isShared_46_ = v_isSharedCheck_72_;
goto v_resetjp_44_;
}
else
{
lean_inc(v_tail_43_);
lean_inc(v_head_42_);
lean_dec(v_tail_40_);
v___x_45_ = lean_box(0);
v_isShared_46_ = v_isSharedCheck_72_;
goto v_resetjp_44_;
}
v_resetjp_44_:
{
uint32_t v___x_47_; lean_object* v___x_48_; 
v___x_47_ = lean_unbox_uint32(v_head_41_);
lean_dec(v_head_41_);
v___x_48_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_nibble(v___x_47_);
if (lean_obj_tag(v___x_48_) == 0)
{
lean_object* v___x_49_; 
lean_del_object(v___x_45_);
lean_dec(v_tail_43_);
lean_dec(v_head_42_);
v___x_49_ = lean_box(0);
return v___x_49_;
}
else
{
lean_object* v_val_50_; uint32_t v___x_51_; lean_object* v___x_52_; 
v_val_50_ = lean_ctor_get(v___x_48_, 0);
lean_inc(v_val_50_);
lean_dec_ref_known(v___x_48_, 1);
v___x_51_ = lean_unbox_uint32(v_head_42_);
lean_dec(v_head_42_);
v___x_52_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_nibble(v___x_51_);
if (lean_obj_tag(v___x_52_) == 0)
{
lean_object* v___x_53_; 
lean_dec(v_val_50_);
lean_del_object(v___x_45_);
lean_dec(v_tail_43_);
v___x_53_ = lean_box(0);
return v___x_53_;
}
else
{
lean_object* v_val_54_; lean_object* v___x_55_; 
v_val_54_ = lean_ctor_get(v___x_52_, 0);
lean_inc(v_val_54_);
lean_dec_ref_known(v___x_52_, 1);
v___x_55_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hexBytes(v_tail_43_);
if (lean_obj_tag(v___x_55_) == 0)
{
lean_dec(v_val_54_);
lean_dec(v_val_50_);
lean_del_object(v___x_45_);
return v___x_55_;
}
else
{
lean_object* v_val_56_; lean_object* v___x_58_; uint8_t v_isShared_59_; uint8_t v_isSharedCheck_71_; 
v_val_56_ = lean_ctor_get(v___x_55_, 0);
v_isSharedCheck_71_ = !lean_is_exclusive(v___x_55_);
if (v_isSharedCheck_71_ == 0)
{
v___x_58_ = v___x_55_;
v_isShared_59_ = v_isSharedCheck_71_;
goto v_resetjp_57_;
}
else
{
lean_inc(v_val_56_);
lean_dec(v___x_55_);
v___x_58_ = lean_box(0);
v_isShared_59_ = v_isSharedCheck_71_;
goto v_resetjp_57_;
}
v_resetjp_57_:
{
lean_object* v___x_60_; lean_object* v___x_61_; lean_object* v___x_62_; uint8_t v___x_63_; lean_object* v___x_64_; lean_object* v___x_66_; 
v___x_60_ = lean_unsigned_to_nat(16u);
v___x_61_ = lean_nat_mul(v_val_50_, v___x_60_);
lean_dec(v_val_50_);
v___x_62_ = lean_nat_add(v___x_61_, v_val_54_);
lean_dec(v_val_54_);
lean_dec(v___x_61_);
v___x_63_ = lean_uint8_of_nat(v___x_62_);
lean_dec(v___x_62_);
v___x_64_ = lean_box(v___x_63_);
if (v_isShared_46_ == 0)
{
lean_ctor_set(v___x_45_, 1, v_val_56_);
lean_ctor_set(v___x_45_, 0, v___x_64_);
v___x_66_ = v___x_45_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_70_; 
v_reuseFailAlloc_70_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_70_, 0, v___x_64_);
lean_ctor_set(v_reuseFailAlloc_70_, 1, v_val_56_);
v___x_66_ = v_reuseFailAlloc_70_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
lean_object* v___x_68_; 
if (v_isShared_59_ == 0)
{
lean_ctor_set(v___x_58_, 0, v___x_66_);
v___x_68_ = v___x_58_;
goto v_reusejp_67_;
}
else
{
lean_object* v_reuseFailAlloc_69_; 
v_reuseFailAlloc_69_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_69_, 0, v___x_66_);
v___x_68_ = v_reuseFailAlloc_69_;
goto v_reusejp_67_;
}
v_reusejp_67_:
{
return v___x_68_;
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_73_; 
lean_dec(v_tail_40_);
lean_dec_ref_known(v_x_38_, 2);
v___x_73_ = lean_box(0);
return v___x_73_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number(lean_object* v_json_77_){
_start:
{
lean_object* v___x_78_; 
v___x_78_ = l_Lean_Json_getNum_x3f(v_json_77_);
if (lean_obj_tag(v___x_78_) == 0)
{
lean_object* v_a_79_; lean_object* v___x_81_; uint8_t v_isShared_82_; uint8_t v_isSharedCheck_86_; 
v_a_79_ = lean_ctor_get(v___x_78_, 0);
v_isSharedCheck_86_ = !lean_is_exclusive(v___x_78_);
if (v_isSharedCheck_86_ == 0)
{
v___x_81_ = v___x_78_;
v_isShared_82_ = v_isSharedCheck_86_;
goto v_resetjp_80_;
}
else
{
lean_inc(v_a_79_);
lean_dec(v___x_78_);
v___x_81_ = lean_box(0);
v_isShared_82_ = v_isSharedCheck_86_;
goto v_resetjp_80_;
}
v_resetjp_80_:
{
lean_object* v___x_84_; 
if (v_isShared_82_ == 0)
{
v___x_84_ = v___x_81_;
goto v_reusejp_83_;
}
else
{
lean_object* v_reuseFailAlloc_85_; 
v_reuseFailAlloc_85_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_85_, 0, v_a_79_);
v___x_84_ = v_reuseFailAlloc_85_;
goto v_reusejp_83_;
}
v_reusejp_83_:
{
return v___x_84_;
}
}
}
else
{
lean_object* v_a_87_; lean_object* v___x_89_; uint8_t v_isShared_90_; uint8_t v_isSharedCheck_106_; 
v_a_87_ = lean_ctor_get(v___x_78_, 0);
v_isSharedCheck_106_ = !lean_is_exclusive(v___x_78_);
if (v_isSharedCheck_106_ == 0)
{
v___x_89_ = v___x_78_;
v_isShared_90_ = v_isSharedCheck_106_;
goto v_resetjp_88_;
}
else
{
lean_inc(v_a_87_);
lean_dec(v___x_78_);
v___x_89_ = lean_box(0);
v_isShared_90_ = v_isSharedCheck_106_;
goto v_resetjp_88_;
}
v_resetjp_88_:
{
lean_object* v_mantissa_91_; lean_object* v_exponent_92_; lean_object* v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; lean_object* v___x_98_; lean_object* v___x_99_; lean_object* v___x_100_; uint8_t v___x_101_; 
v_mantissa_91_ = lean_ctor_get(v_a_87_, 0);
lean_inc(v_mantissa_91_);
v_exponent_92_ = lean_ctor_get(v_a_87_, 1);
lean_inc(v_exponent_92_);
lean_dec(v_a_87_);
v___x_93_ = l_Rat_ofInt(v_mantissa_91_);
v___x_94_ = lean_unsigned_to_nat(10u);
v___x_95_ = lean_nat_pow(v___x_94_, v_exponent_92_);
lean_dec(v_exponent_92_);
v___x_96_ = l_Nat_cast___at___00Std_Http_Internal_Test_defaultConfig_spec__0(v___x_95_);
v___x_97_ = l_Rat_div(v___x_93_, v___x_96_);
lean_dec_ref(v___x_93_);
v___x_98_ = lp_lean1090_Lean1090_Impl_Binary64_round(v___x_97_);
v___x_99_ = lp_lean1090_Lean1090_Impl_Binary64_maxFinite;
lean_inc_ref(v___x_98_);
v___x_100_ = l_Rat_abs(v___x_98_);
v___x_101_ = l_Rat_blt(v___x_99_, v___x_100_);
if (v___x_101_ == 0)
{
lean_object* v___x_103_; 
if (v_isShared_90_ == 0)
{
lean_ctor_set(v___x_89_, 0, v___x_98_);
v___x_103_ = v___x_89_;
goto v_reusejp_102_;
}
else
{
lean_object* v_reuseFailAlloc_104_; 
v_reuseFailAlloc_104_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_104_, 0, v___x_98_);
v___x_103_ = v_reuseFailAlloc_104_;
goto v_reusejp_102_;
}
v_reusejp_102_:
{
return v___x_103_;
}
}
else
{
lean_object* v___x_105_; 
lean_dec_ref(v___x_98_);
lean_del_object(v___x_89_);
v___x_105_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number___closed__1));
return v___x_105_;
}
}
}
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__7(void){
_start:
{
lean_object* v___x_114_; lean_object* v___x_115_; 
v___x_114_ = ((lean_object*)(l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__6));
v___x_115_ = lean_string_utf8_byte_size(v___x_114_);
return v___x_115_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg(lean_object* v___y_116_, lean_object* v_as_x27_117_, lean_object* v_b_118_){
_start:
{
if (lean_obj_tag(v_as_x27_117_) == 0)
{
lean_object* v___x_120_; 
v___x_120_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_120_, 0, v_b_118_);
return v___x_120_;
}
else
{
lean_object* v_head_121_; lean_object* v_tail_122_; lean_object* v___y_124_; lean_object* v___y_125_; lean_object* v_fst_139_; lean_object* v_snd_140_; lean_object* v___y_152_; lean_object* v___y_153_; lean_object* v___y_178_; lean_object* v___y_179_; uint8_t v___y_193_; lean_object* v___y_194_; uint8_t v___y_222_; lean_object* v___x_235_; lean_object* v___x_236_; uint8_t v___x_237_; 
v_head_121_ = lean_ctor_get(v_as_x27_117_, 0);
v_tail_122_ = lean_ctor_get(v_as_x27_117_, 1);
v_fst_139_ = lean_ctor_get(v_head_121_, 0);
v_snd_140_ = lean_ctor_get(v_head_121_, 1);
v___x_235_ = lean_string_utf8_byte_size(v_fst_139_);
v___x_236_ = lean_unsigned_to_nat(0u);
v___x_237_ = lean_nat_dec_eq(v___x_235_, v___x_236_);
if (v___x_237_ == 0)
{
v___y_222_ = v___x_237_;
goto v___jp_221_;
}
else
{
lean_object* v___x_238_; lean_object* v___x_239_; lean_object* v___x_240_; uint8_t v___x_241_; 
v___x_238_ = lean_unsigned_to_nat(1u);
v___x_239_ = lean_nat_add(v_snd_140_, v___x_238_);
v___x_240_ = l_List_lengthTR___redArg(v___y_116_);
v___x_241_ = lean_nat_dec_eq(v___x_239_, v___x_240_);
lean_dec(v___x_240_);
lean_dec(v___x_239_);
if (v___x_241_ == 0)
{
v___y_222_ = v___x_241_;
goto v___jp_221_;
}
else
{
v_as_x27_117_ = v_tail_122_;
goto _start;
}
}
v___jp_123_:
{
lean_object* v___x_126_; 
v___x_126_ = l_IO_ofExcept___at___00Std_Time_Database_TZdb_parseTZIfFromDisk_spec__0___redArg(v___y_125_);
if (lean_obj_tag(v___x_126_) == 0)
{
lean_object* v_a_127_; lean_object* v___x_128_; lean_object* v___x_129_; 
v_a_127_ = lean_ctor_get(v___x_126_, 0);
lean_inc(v_a_127_);
lean_dec_ref_known(v___x_126_, 1);
v___x_128_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_128_, 0, v_a_127_);
lean_ctor_set(v___x_128_, 1, v___y_124_);
v___x_129_ = lean_array_push(v_b_118_, v___x_128_);
v_as_x27_117_ = v_tail_122_;
v_b_118_ = v___x_129_;
goto _start;
}
else
{
lean_object* v_a_131_; lean_object* v___x_133_; uint8_t v_isShared_134_; uint8_t v_isSharedCheck_138_; 
lean_dec(v___y_124_);
lean_dec_ref(v_b_118_);
v_a_131_ = lean_ctor_get(v___x_126_, 0);
v_isSharedCheck_138_ = !lean_is_exclusive(v___x_126_);
if (v_isSharedCheck_138_ == 0)
{
v___x_133_ = v___x_126_;
v_isShared_134_ = v_isSharedCheck_138_;
goto v_resetjp_132_;
}
else
{
lean_inc(v_a_131_);
lean_dec(v___x_126_);
v___x_133_ = lean_box(0);
v_isShared_134_ = v_isSharedCheck_138_;
goto v_resetjp_132_;
}
v_resetjp_132_:
{
lean_object* v___x_136_; 
if (v_isShared_134_ == 0)
{
v___x_136_ = v___x_133_;
goto v_reusejp_135_;
}
else
{
lean_object* v_reuseFailAlloc_137_; 
v_reuseFailAlloc_137_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_137_, 0, v_a_131_);
v___x_136_ = v_reuseFailAlloc_137_;
goto v_reusejp_135_;
}
v_reusejp_135_:
{
return v___x_136_;
}
}
}
}
v___jp_141_:
{
lean_object* v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; 
v___x_142_ = ((lean_object*)(l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__0));
v___x_143_ = lean_unsigned_to_nat(1u);
v___x_144_ = lean_nat_add(v_snd_140_, v___x_143_);
v___x_145_ = l_Nat_reprFast(v___x_144_);
v___x_146_ = lean_string_append(v___x_142_, v___x_145_);
lean_dec_ref(v___x_145_);
v___x_147_ = ((lean_object*)(l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__1));
v___x_148_ = lean_string_append(v___x_146_, v___x_147_);
v___x_149_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_149_, 0, v___x_148_);
v___x_150_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_150_, 0, v___x_149_);
return v___x_150_;
}
v___jp_151_:
{
lean_object* v___x_154_; lean_object* v___x_155_; 
v___x_154_ = lean_string_data(v___y_152_);
v___x_155_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hexBytes(v___x_154_);
if (lean_obj_tag(v___x_155_) == 1)
{
lean_object* v_val_156_; lean_object* v___x_157_; 
v_val_156_ = lean_ctor_get(v___x_155_, 0);
lean_inc(v_val_156_);
lean_dec_ref_known(v___x_155_, 1);
v___x_157_ = l_Lean_Json_parse(v___y_153_);
if (lean_obj_tag(v___x_157_) == 0)
{
lean_object* v_a_158_; lean_object* v___x_160_; uint8_t v_isShared_161_; uint8_t v_isSharedCheck_165_; 
v_a_158_ = lean_ctor_get(v___x_157_, 0);
v_isSharedCheck_165_ = !lean_is_exclusive(v___x_157_);
if (v_isSharedCheck_165_ == 0)
{
v___x_160_ = v___x_157_;
v_isShared_161_ = v_isSharedCheck_165_;
goto v_resetjp_159_;
}
else
{
lean_inc(v_a_158_);
lean_dec(v___x_157_);
v___x_160_ = lean_box(0);
v_isShared_161_ = v_isSharedCheck_165_;
goto v_resetjp_159_;
}
v_resetjp_159_:
{
lean_object* v___x_163_; 
if (v_isShared_161_ == 0)
{
v___x_163_ = v___x_160_;
goto v_reusejp_162_;
}
else
{
lean_object* v_reuseFailAlloc_164_; 
v_reuseFailAlloc_164_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_164_, 0, v_a_158_);
v___x_163_ = v_reuseFailAlloc_164_;
goto v_reusejp_162_;
}
v_reusejp_162_:
{
v___y_124_ = v_val_156_;
v___y_125_ = v___x_163_;
goto v___jp_123_;
}
}
}
else
{
lean_object* v_a_166_; lean_object* v___x_167_; 
v_a_166_ = lean_ctor_get(v___x_157_, 0);
lean_inc(v_a_166_);
lean_dec_ref_known(v___x_157_, 1);
v___x_167_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number(v_a_166_);
v___y_124_ = v_val_156_;
v___y_125_ = v___x_167_;
goto v___jp_123_;
}
}
else
{
lean_object* v___x_168_; lean_object* v___x_169_; lean_object* v___x_170_; lean_object* v___x_171_; lean_object* v___x_172_; lean_object* v___x_173_; lean_object* v___x_174_; lean_object* v___x_175_; lean_object* v___x_176_; 
lean_dec(v___x_155_);
lean_dec_ref(v___y_153_);
lean_dec_ref(v_b_118_);
v___x_168_ = ((lean_object*)(l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__0));
v___x_169_ = lean_unsigned_to_nat(1u);
v___x_170_ = lean_nat_add(v_snd_140_, v___x_169_);
v___x_171_ = l_Nat_reprFast(v___x_170_);
v___x_172_ = lean_string_append(v___x_168_, v___x_171_);
lean_dec_ref(v___x_171_);
v___x_173_ = ((lean_object*)(l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__2));
v___x_174_ = lean_string_append(v___x_172_, v___x_173_);
v___x_175_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_175_, 0, v___x_174_);
v___x_176_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_176_, 0, v___x_175_);
return v___x_176_;
}
}
v___jp_177_:
{
lean_object* v___x_180_; lean_object* v___x_181_; uint8_t v___x_182_; 
v___x_180_ = lean_string_length(v___y_178_);
v___x_181_ = lean_unsigned_to_nat(28u);
v___x_182_ = lean_nat_dec_eq(v___x_180_, v___x_181_);
if (v___x_182_ == 0)
{
lean_object* v___x_183_; lean_object* v___x_184_; lean_object* v___x_185_; lean_object* v___x_186_; lean_object* v___x_187_; lean_object* v___x_188_; lean_object* v___x_189_; lean_object* v___x_190_; lean_object* v___x_191_; 
lean_dec_ref(v___y_179_);
lean_dec_ref(v___y_178_);
lean_dec_ref(v_b_118_);
v___x_183_ = ((lean_object*)(l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__0));
v___x_184_ = lean_unsigned_to_nat(1u);
v___x_185_ = lean_nat_add(v_snd_140_, v___x_184_);
v___x_186_ = l_Nat_reprFast(v___x_185_);
v___x_187_ = lean_string_append(v___x_183_, v___x_186_);
lean_dec_ref(v___x_186_);
v___x_188_ = ((lean_object*)(l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__3));
v___x_189_ = lean_string_append(v___x_187_, v___x_188_);
v___x_190_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_190_, 0, v___x_189_);
v___x_191_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_191_, 0, v___x_190_);
return v___x_191_;
}
else
{
v___y_152_ = v___y_178_;
v___y_153_ = v___y_179_;
goto v___jp_151_;
}
}
v___jp_192_:
{
lean_object* v___x_195_; lean_object* v___x_196_; lean_object* v___x_197_; lean_object* v___x_198_; 
v___x_195_ = ((lean_object*)(l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__4));
v___x_196_ = lean_unsigned_to_nat(0u);
v___x_197_ = lean_box(0);
v___x_198_ = l_String_splitOnAux(v___y_194_, v___x_195_, v___x_196_, v___x_196_, v___x_196_, v___x_197_);
lean_dec_ref(v___y_194_);
if (lean_obj_tag(v___x_198_) == 1)
{
lean_object* v_tail_199_; 
v_tail_199_ = lean_ctor_get(v___x_198_, 1);
lean_inc(v_tail_199_);
if (lean_obj_tag(v_tail_199_) == 1)
{
lean_object* v_tail_200_; 
v_tail_200_ = lean_ctor_get(v_tail_199_, 1);
if (lean_obj_tag(v_tail_200_) == 0)
{
lean_object* v_head_201_; lean_object* v_head_202_; lean_object* v___x_203_; lean_object* v___x_204_; uint8_t v___x_205_; 
v_head_201_ = lean_ctor_get(v___x_198_, 0);
lean_inc(v_head_201_);
lean_dec_ref_known(v___x_198_, 2);
v_head_202_ = lean_ctor_get(v_tail_199_, 0);
lean_inc(v_head_202_);
lean_dec_ref_known(v_tail_199_, 2);
v___x_203_ = lean_string_length(v_head_202_);
v___x_204_ = lean_unsigned_to_nat(18u);
v___x_205_ = lean_nat_dec_lt(v___x_203_, v___x_204_);
if (v___x_205_ == 0)
{
lean_object* v___x_206_; lean_object* v___x_207_; lean_object* v___x_208_; lean_object* v___x_209_; lean_object* v___x_210_; uint8_t v___x_211_; 
v___x_206_ = lean_string_data(v_head_202_);
v___x_207_ = l_List_drop___redArg(v___x_204_, v___x_206_);
lean_dec(v___x_206_);
v___x_208_ = lean_string_mk(v___x_207_);
v___x_209_ = lean_string_length(v___x_208_);
v___x_210_ = lean_unsigned_to_nat(14u);
v___x_211_ = lean_nat_dec_eq(v___x_209_, v___x_210_);
if (v___x_211_ == 0)
{
v___y_178_ = v___x_208_;
v___y_179_ = v_head_201_;
goto v___jp_177_;
}
else
{
if (v___y_193_ == 0)
{
v___y_152_ = v___x_208_;
v___y_153_ = v_head_201_;
goto v___jp_151_;
}
else
{
v___y_178_ = v___x_208_;
v___y_179_ = v_head_201_;
goto v___jp_177_;
}
}
}
else
{
lean_object* v___x_212_; lean_object* v___x_213_; lean_object* v___x_214_; lean_object* v___x_215_; lean_object* v___x_216_; lean_object* v___x_217_; lean_object* v___x_218_; lean_object* v___x_219_; lean_object* v___x_220_; 
lean_dec(v_head_202_);
lean_dec(v_head_201_);
lean_dec_ref(v_b_118_);
v___x_212_ = ((lean_object*)(l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__0));
v___x_213_ = lean_unsigned_to_nat(1u);
v___x_214_ = lean_nat_add(v_snd_140_, v___x_213_);
v___x_215_ = l_Nat_reprFast(v___x_214_);
v___x_216_ = lean_string_append(v___x_212_, v___x_215_);
lean_dec_ref(v___x_215_);
v___x_217_ = ((lean_object*)(l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__5));
v___x_218_ = lean_string_append(v___x_216_, v___x_217_);
v___x_219_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_219_, 0, v___x_218_);
v___x_220_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_220_, 0, v___x_219_);
return v___x_220_;
}
}
else
{
lean_dec_ref_known(v_tail_199_, 2);
lean_dec_ref_known(v___x_198_, 2);
lean_dec_ref(v_b_118_);
goto v___jp_141_;
}
}
else
{
lean_dec(v_tail_199_);
lean_dec_ref_known(v___x_198_, 2);
lean_dec_ref(v_b_118_);
goto v___jp_141_;
}
}
else
{
lean_dec(v___x_198_);
lean_dec_ref(v_b_118_);
goto v___jp_141_;
}
}
v___jp_221_:
{
lean_object* v___x_223_; lean_object* v___x_224_; lean_object* v___x_225_; uint8_t v___x_226_; 
v___x_223_ = ((lean_object*)(l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__6));
v___x_224_ = lean_string_utf8_byte_size(v_fst_139_);
v___x_225_ = lean_obj_once(&l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__7, &l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__7_once, _init_l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___closed__7);
v___x_226_ = lean_nat_dec_le(v___x_225_, v___x_224_);
if (v___x_226_ == 0)
{
lean_inc(v_fst_139_);
v___y_193_ = v___y_222_;
v___y_194_ = v_fst_139_;
goto v___jp_192_;
}
else
{
lean_object* v___x_227_; lean_object* v___x_228_; uint8_t v___x_229_; 
v___x_227_ = lean_unsigned_to_nat(0u);
v___x_228_ = lean_nat_sub(v___x_224_, v___x_225_);
v___x_229_ = lean_string_memcmp(v_fst_139_, v___x_223_, v___x_228_, v___x_227_, v___x_225_);
lean_dec(v___x_228_);
if (v___x_229_ == 0)
{
lean_inc(v_fst_139_);
v___y_193_ = v___y_222_;
v___y_194_ = v_fst_139_;
goto v___jp_192_;
}
else
{
lean_object* v___x_230_; lean_object* v___x_231_; lean_object* v___x_232_; lean_object* v___x_233_; lean_object* v___x_234_; 
v___x_230_ = lean_unsigned_to_nat(1u);
lean_inc_n(v_fst_139_, 2);
v___x_231_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_231_, 0, v_fst_139_);
lean_ctor_set(v___x_231_, 1, v___x_227_);
lean_ctor_set(v___x_231_, 2, v___x_224_);
v___x_232_ = l_String_Slice_Pos_prevn(v___x_231_, v___x_224_, v___x_230_);
lean_dec_ref_known(v___x_231_, 3);
v___x_233_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_233_, 0, v_fst_139_);
lean_ctor_set(v___x_233_, 1, v___x_227_);
lean_ctor_set(v___x_233_, 2, v___x_232_);
v___x_234_ = l_String_Slice_toString(v___x_233_);
lean_dec_ref_known(v___x_233_, 3);
v___y_193_ = v___y_222_;
v___y_194_ = v___x_234_;
goto v___jp_192_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg___boxed(lean_object* v___y_243_, lean_object* v_as_x27_244_, lean_object* v_b_245_, lean_object* v___y_246_){
_start:
{
lean_object* v_res_247_; 
v_res_247_ = l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg(v___y_243_, v_as_x27_244_, v_b_245_);
lean_dec(v_as_x27_244_);
lean_dec(v___y_243_);
return v_res_247_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs(lean_object* v_path_250_){
_start:
{
lean_object* v___x_252_; 
v___x_252_ = l_IO_FS_readFile(v_path_250_);
if (lean_obj_tag(v___x_252_) == 0)
{
lean_object* v_a_253_; lean_object* v___x_254_; lean_object* v___x_255_; lean_object* v___x_256_; lean_object* v___x_257_; lean_object* v___x_258_; lean_object* v___x_259_; lean_object* v___x_260_; lean_object* v___x_261_; 
v_a_253_ = lean_ctor_get(v___x_252_, 0);
lean_inc(v_a_253_);
lean_dec_ref_known(v___x_252_, 1);
v___x_254_ = lean_unsigned_to_nat(172432u);
v___x_255_ = lean_mk_empty_array_with_capacity(v___x_254_);
v___x_256_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs___closed__0));
v___x_257_ = lean_unsigned_to_nat(0u);
v___x_258_ = lean_box(0);
v___x_259_ = l_String_splitOnAux(v_a_253_, v___x_256_, v___x_257_, v___x_257_, v___x_257_, v___x_258_);
lean_dec(v_a_253_);
lean_inc(v___x_259_);
v___x_260_ = l_List_zipIdxTR___redArg(v___x_259_, v___x_257_);
v___x_261_ = l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg(v___x_259_, v___x_260_, v___x_255_);
lean_dec(v___x_260_);
lean_dec(v___x_259_);
if (lean_obj_tag(v___x_261_) == 0)
{
lean_object* v_a_262_; lean_object* v___x_263_; uint8_t v___x_264_; 
v_a_262_ = lean_ctor_get(v___x_261_, 0);
lean_inc(v_a_262_);
v___x_263_ = lean_array_get_size(v_a_262_);
lean_dec(v_a_262_);
v___x_264_ = lean_nat_dec_eq(v___x_263_, v___x_254_);
if (v___x_264_ == 0)
{
lean_object* v___x_266_; uint8_t v_isShared_267_; uint8_t v_isSharedCheck_275_; 
v_isSharedCheck_275_ = !lean_is_exclusive(v___x_261_);
if (v_isSharedCheck_275_ == 0)
{
lean_object* v_unused_276_; 
v_unused_276_ = lean_ctor_get(v___x_261_, 0);
lean_dec(v_unused_276_);
v___x_266_ = v___x_261_;
v_isShared_267_ = v_isSharedCheck_275_;
goto v_resetjp_265_;
}
else
{
lean_dec(v___x_261_);
v___x_266_ = lean_box(0);
v_isShared_267_ = v_isSharedCheck_275_;
goto v_resetjp_265_;
}
v_resetjp_265_:
{
lean_object* v___x_268_; lean_object* v___x_269_; lean_object* v___x_270_; lean_object* v___x_271_; lean_object* v___x_273_; 
v___x_268_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs___closed__1));
v___x_269_ = l_Nat_reprFast(v___x_263_);
v___x_270_ = lean_string_append(v___x_268_, v___x_269_);
lean_dec_ref(v___x_269_);
v___x_271_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_271_, 0, v___x_270_);
if (v_isShared_267_ == 0)
{
lean_ctor_set_tag(v___x_266_, 1);
lean_ctor_set(v___x_266_, 0, v___x_271_);
v___x_273_ = v___x_266_;
goto v_reusejp_272_;
}
else
{
lean_object* v_reuseFailAlloc_274_; 
v_reuseFailAlloc_274_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_274_, 0, v___x_271_);
v___x_273_ = v_reuseFailAlloc_274_;
goto v_reusejp_272_;
}
v_reusejp_272_:
{
return v___x_273_;
}
}
}
else
{
return v___x_261_;
}
}
else
{
return v___x_261_;
}
}
else
{
lean_object* v_a_277_; lean_object* v___x_279_; uint8_t v_isShared_280_; uint8_t v_isSharedCheck_284_; 
v_a_277_ = lean_ctor_get(v___x_252_, 0);
v_isSharedCheck_284_ = !lean_is_exclusive(v___x_252_);
if (v_isSharedCheck_284_ == 0)
{
v___x_279_ = v___x_252_;
v_isShared_280_ = v_isSharedCheck_284_;
goto v_resetjp_278_;
}
else
{
lean_inc(v_a_277_);
lean_dec(v___x_252_);
v___x_279_ = lean_box(0);
v_isShared_280_ = v_isSharedCheck_284_;
goto v_resetjp_278_;
}
v_resetjp_278_:
{
lean_object* v___x_282_; 
if (v_isShared_280_ == 0)
{
v___x_282_ = v___x_279_;
goto v_reusejp_281_;
}
else
{
lean_object* v_reuseFailAlloc_283_; 
v_reuseFailAlloc_283_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_283_, 0, v_a_277_);
v___x_282_ = v_reuseFailAlloc_283_;
goto v_reusejp_281_;
}
v_reusejp_281_:
{
return v___x_282_;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs___boxed(lean_object* v_path_285_, lean_object* v_a_286_){
_start:
{
lean_object* v_res_287_; 
v_res_287_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs(v_path_285_);
lean_dec_ref(v_path_285_);
return v_res_287_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0(lean_object* v___y_288_, lean_object* v_as_289_, lean_object* v_as_x27_290_, lean_object* v_b_291_, lean_object* v_a_292_){
_start:
{
lean_object* v___x_294_; 
v___x_294_ = l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___redArg(v___y_288_, v_as_x27_290_, v_b_291_);
return v___x_294_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0___boxed(lean_object* v___y_295_, lean_object* v_as_296_, lean_object* v_as_x27_297_, lean_object* v_b_298_, lean_object* v_a_299_, lean_object* v___y_300_){
_start:
{
lean_object* v_res_301_; 
v_res_301_ = l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs_spec__0(v___y_295_, v_as_296_, v_as_x27_297_, v_b_298_, v_a_299_);
lean_dec(v_as_x27_297_);
lean_dec(v_as_296_);
lean_dec(v___y_295_);
return v_res_301_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0(lean_object* v_as_305_, size_t v_sz_306_, size_t v_i_307_, lean_object* v_b_308_){
_start:
{
lean_object* v___y_311_; lean_object* v___y_312_; lean_object* v___y_313_; uint8_t v___x_330_; 
v___x_330_ = lean_usize_dec_lt(v_i_307_, v_sz_306_);
if (v___x_330_ == 0)
{
lean_object* v___x_331_; 
v___x_331_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_331_, 0, v_b_308_);
return v___x_331_;
}
else
{
lean_object* v_a_332_; lean_object* v___y_334_; lean_object* v___y_335_; lean_object* v___y_359_; lean_object* v___x_382_; lean_object* v___x_383_; 
v_a_332_ = lean_array_uget_borrowed(v_as_305_, v_i_307_);
v___x_382_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___closed__2));
lean_inc(v_a_332_);
v___x_383_ = l_Lean_Json_getObjVal_x3f(v_a_332_, v___x_382_);
if (lean_obj_tag(v___x_383_) == 0)
{
lean_object* v_a_384_; lean_object* v___x_386_; uint8_t v_isShared_387_; uint8_t v_isSharedCheck_391_; 
v_a_384_ = lean_ctor_get(v___x_383_, 0);
v_isSharedCheck_391_ = !lean_is_exclusive(v___x_383_);
if (v_isSharedCheck_391_ == 0)
{
v___x_386_ = v___x_383_;
v_isShared_387_ = v_isSharedCheck_391_;
goto v_resetjp_385_;
}
else
{
lean_inc(v_a_384_);
lean_dec(v___x_383_);
v___x_386_ = lean_box(0);
v_isShared_387_ = v_isSharedCheck_391_;
goto v_resetjp_385_;
}
v_resetjp_385_:
{
lean_object* v___x_389_; 
if (v_isShared_387_ == 0)
{
v___x_389_ = v___x_386_;
goto v_reusejp_388_;
}
else
{
lean_object* v_reuseFailAlloc_390_; 
v_reuseFailAlloc_390_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_390_, 0, v_a_384_);
v___x_389_ = v_reuseFailAlloc_390_;
goto v_reusejp_388_;
}
v_reusejp_388_:
{
v___y_359_ = v___x_389_;
goto v___jp_358_;
}
}
}
else
{
lean_object* v_a_392_; lean_object* v___x_393_; 
v_a_392_ = lean_ctor_get(v___x_383_, 0);
lean_inc(v_a_392_);
lean_dec_ref_known(v___x_383_, 1);
v___x_393_ = l_Lean_Json_getStr_x3f(v_a_392_);
v___y_359_ = v___x_393_;
goto v___jp_358_;
}
v___jp_333_:
{
lean_object* v___x_336_; 
v___x_336_ = l_IO_ofExcept___at___00Std_Time_Database_TZdb_parseTZIfFromDisk_spec__0___redArg(v___y_335_);
if (lean_obj_tag(v___x_336_) == 0)
{
lean_object* v_a_337_; lean_object* v___x_338_; lean_object* v___x_339_; 
v_a_337_ = lean_ctor_get(v___x_336_, 0);
lean_inc(v_a_337_);
lean_dec_ref_known(v___x_336_, 1);
v___x_338_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___closed__0));
lean_inc(v_a_332_);
v___x_339_ = l_Lean_Json_getObjVal_x3f(v_a_332_, v___x_338_);
if (lean_obj_tag(v___x_339_) == 0)
{
lean_object* v_a_340_; lean_object* v___x_342_; uint8_t v_isShared_343_; uint8_t v_isSharedCheck_347_; 
v_a_340_ = lean_ctor_get(v___x_339_, 0);
v_isSharedCheck_347_ = !lean_is_exclusive(v___x_339_);
if (v_isSharedCheck_347_ == 0)
{
v___x_342_ = v___x_339_;
v_isShared_343_ = v_isSharedCheck_347_;
goto v_resetjp_341_;
}
else
{
lean_inc(v_a_340_);
lean_dec(v___x_339_);
v___x_342_ = lean_box(0);
v_isShared_343_ = v_isSharedCheck_347_;
goto v_resetjp_341_;
}
v_resetjp_341_:
{
lean_object* v___x_345_; 
if (v_isShared_343_ == 0)
{
v___x_345_ = v___x_342_;
goto v_reusejp_344_;
}
else
{
lean_object* v_reuseFailAlloc_346_; 
v_reuseFailAlloc_346_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_346_, 0, v_a_340_);
v___x_345_ = v_reuseFailAlloc_346_;
goto v_reusejp_344_;
}
v_reusejp_344_:
{
v___y_311_ = v_a_337_;
v___y_312_ = v___y_334_;
v___y_313_ = v___x_345_;
goto v___jp_310_;
}
}
}
else
{
lean_object* v_a_348_; lean_object* v___x_349_; 
v_a_348_ = lean_ctor_get(v___x_339_, 0);
lean_inc(v_a_348_);
lean_dec_ref_known(v___x_339_, 1);
v___x_349_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number(v_a_348_);
v___y_311_ = v_a_337_;
v___y_312_ = v___y_334_;
v___y_313_ = v___x_349_;
goto v___jp_310_;
}
}
else
{
lean_object* v_a_350_; lean_object* v___x_352_; uint8_t v_isShared_353_; uint8_t v_isSharedCheck_357_; 
lean_dec_ref(v___y_334_);
lean_dec(v_b_308_);
v_a_350_ = lean_ctor_get(v___x_336_, 0);
v_isSharedCheck_357_ = !lean_is_exclusive(v___x_336_);
if (v_isSharedCheck_357_ == 0)
{
v___x_352_ = v___x_336_;
v_isShared_353_ = v_isSharedCheck_357_;
goto v_resetjp_351_;
}
else
{
lean_inc(v_a_350_);
lean_dec(v___x_336_);
v___x_352_ = lean_box(0);
v_isShared_353_ = v_isSharedCheck_357_;
goto v_resetjp_351_;
}
v_resetjp_351_:
{
lean_object* v___x_355_; 
if (v_isShared_353_ == 0)
{
v___x_355_ = v___x_352_;
goto v_reusejp_354_;
}
else
{
lean_object* v_reuseFailAlloc_356_; 
v_reuseFailAlloc_356_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_356_, 0, v_a_350_);
v___x_355_ = v_reuseFailAlloc_356_;
goto v_reusejp_354_;
}
v_reusejp_354_:
{
return v___x_355_;
}
}
}
}
v___jp_358_:
{
lean_object* v___x_360_; 
v___x_360_ = l_IO_ofExcept___at___00Std_Time_Database_TZdb_parseTZIfFromDisk_spec__0___redArg(v___y_359_);
if (lean_obj_tag(v___x_360_) == 0)
{
lean_object* v_a_361_; lean_object* v___x_362_; lean_object* v___x_363_; 
v_a_361_ = lean_ctor_get(v___x_360_, 0);
lean_inc(v_a_361_);
lean_dec_ref_known(v___x_360_, 1);
v___x_362_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___closed__1));
lean_inc(v_a_332_);
v___x_363_ = l_Lean_Json_getObjVal_x3f(v_a_332_, v___x_362_);
if (lean_obj_tag(v___x_363_) == 0)
{
lean_object* v_a_364_; lean_object* v___x_366_; uint8_t v_isShared_367_; uint8_t v_isSharedCheck_371_; 
v_a_364_ = lean_ctor_get(v___x_363_, 0);
v_isSharedCheck_371_ = !lean_is_exclusive(v___x_363_);
if (v_isSharedCheck_371_ == 0)
{
v___x_366_ = v___x_363_;
v_isShared_367_ = v_isSharedCheck_371_;
goto v_resetjp_365_;
}
else
{
lean_inc(v_a_364_);
lean_dec(v___x_363_);
v___x_366_ = lean_box(0);
v_isShared_367_ = v_isSharedCheck_371_;
goto v_resetjp_365_;
}
v_resetjp_365_:
{
lean_object* v___x_369_; 
if (v_isShared_367_ == 0)
{
v___x_369_ = v___x_366_;
goto v_reusejp_368_;
}
else
{
lean_object* v_reuseFailAlloc_370_; 
v_reuseFailAlloc_370_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_370_, 0, v_a_364_);
v___x_369_ = v_reuseFailAlloc_370_;
goto v_reusejp_368_;
}
v_reusejp_368_:
{
v___y_334_ = v_a_361_;
v___y_335_ = v___x_369_;
goto v___jp_333_;
}
}
}
else
{
lean_object* v_a_372_; lean_object* v___x_373_; 
v_a_372_ = lean_ctor_get(v___x_363_, 0);
lean_inc(v_a_372_);
lean_dec_ref_known(v___x_363_, 1);
v___x_373_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_number(v_a_372_);
v___y_334_ = v_a_361_;
v___y_335_ = v___x_373_;
goto v___jp_333_;
}
}
else
{
lean_object* v_a_374_; lean_object* v___x_376_; uint8_t v_isShared_377_; uint8_t v_isSharedCheck_381_; 
lean_dec(v_b_308_);
v_a_374_ = lean_ctor_get(v___x_360_, 0);
v_isSharedCheck_381_ = !lean_is_exclusive(v___x_360_);
if (v_isSharedCheck_381_ == 0)
{
v___x_376_ = v___x_360_;
v_isShared_377_ = v_isSharedCheck_381_;
goto v_resetjp_375_;
}
else
{
lean_inc(v_a_374_);
lean_dec(v___x_360_);
v___x_376_ = lean_box(0);
v_isShared_377_ = v_isSharedCheck_381_;
goto v_resetjp_375_;
}
v_resetjp_375_:
{
lean_object* v___x_379_; 
if (v_isShared_377_ == 0)
{
v___x_379_ = v___x_376_;
goto v_reusejp_378_;
}
else
{
lean_object* v_reuseFailAlloc_380_; 
v_reuseFailAlloc_380_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_380_, 0, v_a_374_);
v___x_379_ = v_reuseFailAlloc_380_;
goto v_reusejp_378_;
}
v_reusejp_378_:
{
return v___x_379_;
}
}
}
}
}
v___jp_310_:
{
lean_object* v___x_314_; 
v___x_314_ = l_IO_ofExcept___at___00Std_Time_Database_TZdb_parseTZIfFromDisk_spec__0___redArg(v___y_313_);
if (lean_obj_tag(v___x_314_) == 0)
{
lean_object* v_a_315_; lean_object* v___x_316_; lean_object* v___x_317_; lean_object* v___x_318_; size_t v___x_319_; size_t v___x_320_; 
v_a_315_ = lean_ctor_get(v___x_314_, 0);
lean_inc(v_a_315_);
lean_dec_ref_known(v___x_314_, 1);
v___x_316_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_316_, 0, v___y_311_);
lean_ctor_set(v___x_316_, 1, v_a_315_);
v___x_317_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_317_, 0, v___y_312_);
lean_ctor_set(v___x_317_, 1, v___x_316_);
v___x_318_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_318_, 0, v___x_317_);
lean_ctor_set(v___x_318_, 1, v_b_308_);
v___x_319_ = ((size_t)1ULL);
v___x_320_ = lean_usize_add(v_i_307_, v___x_319_);
v_i_307_ = v___x_320_;
v_b_308_ = v___x_318_;
goto _start;
}
else
{
lean_object* v_a_322_; lean_object* v___x_324_; uint8_t v_isShared_325_; uint8_t v_isSharedCheck_329_; 
lean_dec_ref(v___y_312_);
lean_dec_ref(v___y_311_);
lean_dec(v_b_308_);
v_a_322_ = lean_ctor_get(v___x_314_, 0);
v_isSharedCheck_329_ = !lean_is_exclusive(v___x_314_);
if (v_isSharedCheck_329_ == 0)
{
v___x_324_ = v___x_314_;
v_isShared_325_ = v_isSharedCheck_329_;
goto v_resetjp_323_;
}
else
{
lean_inc(v_a_322_);
lean_dec(v___x_314_);
v___x_324_ = lean_box(0);
v_isShared_325_ = v_isSharedCheck_329_;
goto v_resetjp_323_;
}
v_resetjp_323_:
{
lean_object* v___x_327_; 
if (v_isShared_325_ == 0)
{
v___x_327_ = v___x_324_;
goto v_reusejp_326_;
}
else
{
lean_object* v_reuseFailAlloc_328_; 
v_reuseFailAlloc_328_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_328_, 0, v_a_322_);
v___x_327_ = v_reuseFailAlloc_328_;
goto v_reusejp_326_;
}
v_reusejp_326_:
{
return v___x_327_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0___boxed(lean_object* v_as_394_, lean_object* v_sz_395_, lean_object* v_i_396_, lean_object* v_b_397_, lean_object* v___y_398_){
_start:
{
size_t v_sz_boxed_399_; size_t v_i_boxed_400_; lean_object* v_res_401_; 
v_sz_boxed_399_ = lean_unbox_usize(v_sz_395_);
lean_dec(v_sz_395_);
v_i_boxed_400_ = lean_unbox_usize(v_i_396_);
lean_dec(v_i_396_);
v_res_401_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0(v_as_394_, v_sz_boxed_399_, v_i_boxed_400_, v_b_397_);
lean_dec_ref(v_as_394_);
return v_res_401_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports(){
_start:
{
lean_object* v___x_406_; lean_object* v___x_407_; 
v___x_406_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_airportPath___closed__0));
v___x_407_ = l_IO_FS_readFile(v___x_406_);
if (lean_obj_tag(v___x_407_) == 0)
{
lean_object* v_a_408_; lean_object* v___x_409_; lean_object* v___x_410_; 
v_a_408_ = lean_ctor_get(v___x_407_, 0);
lean_inc(v_a_408_);
lean_dec_ref_known(v___x_407_, 1);
v___x_409_ = l_Lean_Json_parse(v_a_408_);
v___x_410_ = l_IO_ofExcept___at___00Std_Time_Database_TZdb_parseTZIfFromDisk_spec__0___redArg(v___x_409_);
if (lean_obj_tag(v___x_410_) == 0)
{
lean_object* v_a_411_; lean_object* v___x_412_; lean_object* v___x_413_; 
v_a_411_ = lean_ctor_get(v___x_410_, 0);
lean_inc(v_a_411_);
lean_dec_ref_known(v___x_410_, 1);
v___x_412_ = l_Lean_Json_getArr_x3f(v_a_411_);
v___x_413_ = l_IO_ofExcept___at___00Std_Time_Database_TZdb_parseTZIfFromDisk_spec__0___redArg(v___x_412_);
if (lean_obj_tag(v___x_413_) == 0)
{
lean_object* v_a_414_; lean_object* v___x_416_; uint8_t v_isShared_417_; uint8_t v_isSharedCheck_438_; 
v_a_414_ = lean_ctor_get(v___x_413_, 0);
v_isSharedCheck_438_ = !lean_is_exclusive(v___x_413_);
if (v_isSharedCheck_438_ == 0)
{
v___x_416_ = v___x_413_;
v_isShared_417_ = v_isSharedCheck_438_;
goto v_resetjp_415_;
}
else
{
lean_inc(v_a_414_);
lean_dec(v___x_413_);
v___x_416_ = lean_box(0);
v_isShared_417_ = v_isSharedCheck_438_;
goto v_resetjp_415_;
}
v_resetjp_415_:
{
lean_object* v___x_418_; lean_object* v___x_419_; uint8_t v___x_420_; 
v___x_418_ = lean_array_get_size(v_a_414_);
v___x_419_ = lean_unsigned_to_nat(6903u);
v___x_420_ = lean_nat_dec_eq(v___x_418_, v___x_419_);
if (v___x_420_ == 0)
{
lean_object* v___x_421_; lean_object* v___x_423_; 
lean_dec(v_a_414_);
v___x_421_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports___closed__1));
if (v_isShared_417_ == 0)
{
lean_ctor_set_tag(v___x_416_, 1);
lean_ctor_set(v___x_416_, 0, v___x_421_);
v___x_423_ = v___x_416_;
goto v_reusejp_422_;
}
else
{
lean_object* v_reuseFailAlloc_424_; 
v_reuseFailAlloc_424_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_424_, 0, v___x_421_);
v___x_423_ = v_reuseFailAlloc_424_;
goto v_reusejp_422_;
}
v_reusejp_422_:
{
return v___x_423_;
}
}
else
{
lean_object* v___x_425_; size_t v_sz_426_; size_t v___x_427_; lean_object* v___x_428_; 
lean_del_object(v___x_416_);
v___x_425_ = lean_box(0);
v_sz_426_ = lean_array_size(v_a_414_);
v___x_427_ = ((size_t)0ULL);
v___x_428_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports_spec__0(v_a_414_, v_sz_426_, v___x_427_, v___x_425_);
lean_dec(v_a_414_);
if (lean_obj_tag(v___x_428_) == 0)
{
lean_object* v_a_429_; lean_object* v___x_431_; uint8_t v_isShared_432_; uint8_t v_isSharedCheck_437_; 
v_a_429_ = lean_ctor_get(v___x_428_, 0);
v_isSharedCheck_437_ = !lean_is_exclusive(v___x_428_);
if (v_isSharedCheck_437_ == 0)
{
v___x_431_ = v___x_428_;
v_isShared_432_ = v_isSharedCheck_437_;
goto v_resetjp_430_;
}
else
{
lean_inc(v_a_429_);
lean_dec(v___x_428_);
v___x_431_ = lean_box(0);
v_isShared_432_ = v_isSharedCheck_437_;
goto v_resetjp_430_;
}
v_resetjp_430_:
{
lean_object* v___x_433_; lean_object* v___x_435_; 
v___x_433_ = l_List_reverse___redArg(v_a_429_);
if (v_isShared_432_ == 0)
{
lean_ctor_set(v___x_431_, 0, v___x_433_);
v___x_435_ = v___x_431_;
goto v_reusejp_434_;
}
else
{
lean_object* v_reuseFailAlloc_436_; 
v_reuseFailAlloc_436_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_436_, 0, v___x_433_);
v___x_435_ = v_reuseFailAlloc_436_;
goto v_reusejp_434_;
}
v_reusejp_434_:
{
return v___x_435_;
}
}
}
else
{
return v___x_428_;
}
}
}
}
else
{
lean_object* v_a_439_; lean_object* v___x_441_; uint8_t v_isShared_442_; uint8_t v_isSharedCheck_446_; 
v_a_439_ = lean_ctor_get(v___x_413_, 0);
v_isSharedCheck_446_ = !lean_is_exclusive(v___x_413_);
if (v_isSharedCheck_446_ == 0)
{
v___x_441_ = v___x_413_;
v_isShared_442_ = v_isSharedCheck_446_;
goto v_resetjp_440_;
}
else
{
lean_inc(v_a_439_);
lean_dec(v___x_413_);
v___x_441_ = lean_box(0);
v_isShared_442_ = v_isSharedCheck_446_;
goto v_resetjp_440_;
}
v_resetjp_440_:
{
lean_object* v___x_444_; 
if (v_isShared_442_ == 0)
{
v___x_444_ = v___x_441_;
goto v_reusejp_443_;
}
else
{
lean_object* v_reuseFailAlloc_445_; 
v_reuseFailAlloc_445_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_445_, 0, v_a_439_);
v___x_444_ = v_reuseFailAlloc_445_;
goto v_reusejp_443_;
}
v_reusejp_443_:
{
return v___x_444_;
}
}
}
}
else
{
lean_object* v_a_447_; lean_object* v___x_449_; uint8_t v_isShared_450_; uint8_t v_isSharedCheck_454_; 
v_a_447_ = lean_ctor_get(v___x_410_, 0);
v_isSharedCheck_454_ = !lean_is_exclusive(v___x_410_);
if (v_isSharedCheck_454_ == 0)
{
v___x_449_ = v___x_410_;
v_isShared_450_ = v_isSharedCheck_454_;
goto v_resetjp_448_;
}
else
{
lean_inc(v_a_447_);
lean_dec(v___x_410_);
v___x_449_ = lean_box(0);
v_isShared_450_ = v_isSharedCheck_454_;
goto v_resetjp_448_;
}
v_resetjp_448_:
{
lean_object* v___x_452_; 
if (v_isShared_450_ == 0)
{
v___x_452_ = v___x_449_;
goto v_reusejp_451_;
}
else
{
lean_object* v_reuseFailAlloc_453_; 
v_reuseFailAlloc_453_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_453_, 0, v_a_447_);
v___x_452_ = v_reuseFailAlloc_453_;
goto v_reusejp_451_;
}
v_reusejp_451_:
{
return v___x_452_;
}
}
}
}
else
{
lean_object* v_a_455_; lean_object* v___x_457_; uint8_t v_isShared_458_; uint8_t v_isSharedCheck_462_; 
v_a_455_ = lean_ctor_get(v___x_407_, 0);
v_isSharedCheck_462_ = !lean_is_exclusive(v___x_407_);
if (v_isSharedCheck_462_ == 0)
{
v___x_457_ = v___x_407_;
v_isShared_458_ = v_isSharedCheck_462_;
goto v_resetjp_456_;
}
else
{
lean_inc(v_a_455_);
lean_dec(v___x_407_);
v___x_457_ = lean_box(0);
v_isShared_458_ = v_isSharedCheck_462_;
goto v_resetjp_456_;
}
v_resetjp_456_:
{
lean_object* v___x_460_; 
if (v_isShared_458_ == 0)
{
v___x_460_ = v___x_457_;
goto v_reusejp_459_;
}
else
{
lean_object* v_reuseFailAlloc_461_; 
v_reuseFailAlloc_461_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_461_, 0, v_a_455_);
v___x_460_ = v_reuseFailAlloc_461_;
goto v_reusejp_459_;
}
v_reusejp_459_:
{
return v___x_460_;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports___boxed(lean_object* v_a_463_){
_start:
{
lean_object* v_res_464_; 
v_res_464_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports();
return v_res_464_;
}
}
LEAN_EXPORT lean_object* l_List_find_x3f___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport_spec__0(lean_object* v_x_466_){
_start:
{
if (lean_obj_tag(v_x_466_) == 0)
{
lean_object* v___x_467_; 
v___x_467_ = lean_box(0);
return v___x_467_;
}
else
{
lean_object* v_head_468_; lean_object* v_tail_469_; lean_object* v_fst_470_; lean_object* v___x_471_; uint8_t v___x_472_; 
v_head_468_ = lean_ctor_get(v_x_466_, 0);
v_tail_469_ = lean_ctor_get(v_x_466_, 1);
v_fst_470_ = lean_ctor_get(v_head_468_, 0);
v___x_471_ = ((lean_object*)(l_List_find_x3f___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport_spec__0___closed__0));
v___x_472_ = lean_string_dec_eq(v_fst_470_, v___x_471_);
if (v___x_472_ == 0)
{
v_x_466_ = v_tail_469_;
goto _start;
}
else
{
lean_object* v___x_474_; 
lean_inc(v_head_468_);
v___x_474_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_474_, 0, v_head_468_);
return v___x_474_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_find_x3f___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport_spec__0___boxed(lean_object* v_x_475_){
_start:
{
lean_object* v_res_476_; 
v_res_476_ = l_List_find_x3f___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport_spec__0(v_x_475_);
lean_dec(v_x_475_);
return v_res_476_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport(lean_object* v_timestamp_484_, lean_object* v_message_485_){
_start:
{
lean_object* v_fields_486_; lean_object* v_body_487_; 
v_fields_486_ = lean_ctor_get(v_message_485_, 0);
v_body_487_ = lean_ctor_get(v_fields_486_, 0);
if (lean_obj_tag(v_body_487_) == 4)
{
lean_object* v_decoded_488_; lean_object* v_address_489_; 
v_decoded_488_ = lean_ctor_get(v_message_485_, 1);
lean_inc_ref(v_decoded_488_);
lean_dec_ref(v_message_485_);
v_address_489_ = lean_ctor_get(v_decoded_488_, 1);
lean_inc(v_address_489_);
if (lean_obj_tag(v_address_489_) == 0)
{
lean_object* v___x_490_; 
lean_dec_ref(v_decoded_488_);
lean_dec_ref(v_timestamp_484_);
v___x_490_ = lean_box(0);
return v___x_490_;
}
else
{
lean_object* v_adsb_491_; lean_object* v_semanticADSB_492_; lean_object* v_val_493_; lean_object* v___x_495_; uint8_t v_isShared_496_; uint8_t v_isSharedCheck_621_; 
v_adsb_491_ = lean_ctor_get(v_decoded_488_, 5);
lean_inc(v_adsb_491_);
v_semanticADSB_492_ = lean_ctor_get(v_decoded_488_, 7);
lean_inc(v_semanticADSB_492_);
lean_dec_ref(v_decoded_488_);
v_val_493_ = lean_ctor_get(v_address_489_, 0);
v_isSharedCheck_621_ = !lean_is_exclusive(v_address_489_);
if (v_isSharedCheck_621_ == 0)
{
v___x_495_ = v_address_489_;
v_isShared_496_ = v_isSharedCheck_621_;
goto v_resetjp_494_;
}
else
{
lean_inc(v_val_493_);
lean_dec(v_address_489_);
v___x_495_ = lean_box(0);
v_isShared_496_ = v_isSharedCheck_621_;
goto v_resetjp_494_;
}
v_resetjp_494_:
{
lean_object* v___y_498_; uint8_t v___y_504_; 
if (lean_obj_tag(v_adsb_491_) == 0)
{
lean_object* v___x_506_; 
lean_del_object(v___x_495_);
lean_dec(v_val_493_);
lean_dec(v_semanticADSB_492_);
lean_dec_ref(v_timestamp_484_);
v___x_506_ = lean_box(0);
return v___x_506_;
}
else
{
if (lean_obj_tag(v_semanticADSB_492_) == 0)
{
lean_object* v___x_507_; 
lean_dec_ref_known(v_adsb_491_, 1);
lean_del_object(v___x_495_);
lean_dec(v_val_493_);
lean_dec_ref(v_timestamp_484_);
v___x_507_ = lean_box(0);
return v___x_507_;
}
else
{
lean_object* v_val_508_; lean_object* v___x_510_; uint8_t v_isShared_511_; uint8_t v_isSharedCheck_620_; 
v_val_508_ = lean_ctor_get(v_adsb_491_, 0);
v_isSharedCheck_620_ = !lean_is_exclusive(v_adsb_491_);
if (v_isSharedCheck_620_ == 0)
{
v___x_510_ = v_adsb_491_;
v_isShared_511_ = v_isSharedCheck_620_;
goto v_resetjp_509_;
}
else
{
lean_inc(v_val_508_);
lean_dec(v_adsb_491_);
v___x_510_ = lean_box(0);
v_isShared_511_ = v_isSharedCheck_620_;
goto v_resetjp_509_;
}
v_resetjp_509_:
{
lean_object* v_val_512_; lean_object* v___x_514_; uint8_t v_isShared_515_; uint8_t v_isSharedCheck_619_; 
v_val_512_ = lean_ctor_get(v_semanticADSB_492_, 0);
v_isSharedCheck_619_ = !lean_is_exclusive(v_semanticADSB_492_);
if (v_isSharedCheck_619_ == 0)
{
v___x_514_ = v_semanticADSB_492_;
v_isShared_515_ = v_isSharedCheck_619_;
goto v_resetjp_513_;
}
else
{
lean_inc(v_val_512_);
lean_dec(v_semanticADSB_492_);
v___x_514_ = lean_box(0);
v_isShared_515_ = v_isSharedCheck_619_;
goto v_resetjp_513_;
}
v_resetjp_513_:
{
lean_object* v___x_516_; lean_object* v___x_517_; lean_object* v___x_532_; lean_object* v___x_533_; lean_object* v___x_534_; uint8_t v___x_540_; lean_object* v___x_541_; lean_object* v___x_542_; lean_object* v___x_543_; lean_object* v___x_544_; lean_object* v___x_545_; lean_object* v___y_547_; lean_object* v___y_548_; lean_object* v___y_549_; lean_object* v___y_550_; lean_object* v___y_559_; uint8_t v___y_560_; lean_object* v___y_561_; lean_object* v___y_571_; uint8_t v___y_572_; lean_object* v___y_576_; lean_object* v___x_612_; uint8_t v___x_613_; 
v___x_516_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__0));
v___x_517_ = lp_lean1090_Lean1090_Impl_JSON_raw(v_val_508_, v___x_516_);
v___x_532_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__1));
v___x_533_ = lp_lean1090_Lean1090_Impl_JSON_raw(v_val_508_, v___x_532_);
v___x_534_ = lean_unsigned_to_nat(1u);
v___x_540_ = lean_nat_dec_eq(v___x_533_, v___x_534_);
lean_dec(v___x_533_);
v___x_541_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__2));
v___x_542_ = lp_lean1090_Lean1090_Impl_JSON_raw(v_val_508_, v___x_541_);
v___x_543_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__3));
v___x_544_ = lp_lean1090_Lean1090_Impl_JSON_raw(v_val_508_, v___x_543_);
v___x_545_ = lean_alloc_ctor(0, 2, 1);
lean_ctor_set(v___x_545_, 0, v___x_542_);
lean_ctor_set(v___x_545_, 1, v___x_544_);
lean_ctor_set_uint8(v___x_545_, sizeof(void*)*2, v___x_540_);
v___x_612_ = lean_unsigned_to_nat(5u);
v___x_613_ = lean_nat_dec_le(v___x_612_, v___x_517_);
if (v___x_613_ == 0)
{
lean_del_object(v___x_510_);
goto v___jp_607_;
}
else
{
lean_object* v___x_614_; uint8_t v___x_615_; 
v___x_614_ = lean_unsigned_to_nat(8u);
v___x_615_ = lean_nat_dec_le(v___x_517_, v___x_614_);
if (v___x_615_ == 0)
{
lean_del_object(v___x_510_);
goto v___jp_607_;
}
else
{
lean_object* v___x_617_; 
lean_dec(v___x_517_);
lean_del_object(v___x_514_);
lean_dec(v_val_512_);
lean_dec(v_val_508_);
if (v_isShared_511_ == 0)
{
lean_ctor_set(v___x_510_, 0, v___x_545_);
v___x_617_ = v___x_510_;
goto v_reusejp_616_;
}
else
{
lean_object* v_reuseFailAlloc_618_; 
v_reuseFailAlloc_618_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_618_, 0, v___x_545_);
v___x_617_ = v_reuseFailAlloc_618_;
goto v_reusejp_616_;
}
v_reusejp_616_:
{
v___y_498_ = v___x_617_;
goto v___jp_497_;
}
}
}
v___jp_518_:
{
lean_object* v___x_519_; uint8_t v___x_520_; 
v___x_519_ = lean_unsigned_to_nat(19u);
v___x_520_ = lean_nat_dec_eq(v___x_517_, v___x_519_);
if (v___x_520_ == 0)
{
lean_object* v___x_521_; uint8_t v___x_522_; 
v___x_521_ = lean_unsigned_to_nat(28u);
v___x_522_ = lean_nat_dec_eq(v___x_517_, v___x_521_);
if (v___x_522_ == 0)
{
lean_object* v___x_523_; uint8_t v___x_524_; 
v___x_523_ = lean_unsigned_to_nat(29u);
v___x_524_ = lean_nat_dec_eq(v___x_517_, v___x_523_);
if (v___x_524_ == 0)
{
lean_object* v___x_525_; uint8_t v___x_526_; 
v___x_525_ = lean_unsigned_to_nat(31u);
v___x_526_ = lean_nat_dec_eq(v___x_517_, v___x_525_);
lean_dec(v___x_517_);
if (v___x_526_ == 0)
{
uint8_t v___x_527_; 
v___x_527_ = 5;
v___y_504_ = v___x_527_;
goto v___jp_503_;
}
else
{
uint8_t v___x_528_; 
v___x_528_ = 4;
v___y_504_ = v___x_528_;
goto v___jp_503_;
}
}
else
{
uint8_t v___x_529_; 
lean_dec(v___x_517_);
v___x_529_ = 3;
v___y_504_ = v___x_529_;
goto v___jp_503_;
}
}
else
{
uint8_t v___x_530_; 
lean_dec(v___x_517_);
v___x_530_ = 2;
v___y_504_ = v___x_530_;
goto v___jp_503_;
}
}
else
{
uint8_t v___x_531_; 
lean_dec(v___x_517_);
v___x_531_ = 1;
v___y_504_ = v___x_531_;
goto v___jp_503_;
}
}
v___jp_535_:
{
uint8_t v___x_536_; 
v___x_536_ = lean_nat_dec_le(v___x_534_, v___x_517_);
if (v___x_536_ == 0)
{
goto v___jp_518_;
}
else
{
lean_object* v___x_537_; uint8_t v___x_538_; 
v___x_537_ = lean_unsigned_to_nat(4u);
v___x_538_ = lean_nat_dec_le(v___x_517_, v___x_537_);
if (v___x_538_ == 0)
{
goto v___jp_518_;
}
else
{
uint8_t v___x_539_; 
lean_dec(v___x_517_);
v___x_539_ = 0;
v___y_504_ = v___x_539_;
goto v___jp_503_;
}
}
}
v___jp_546_:
{
lean_object* v___x_551_; uint8_t v___x_552_; lean_object* v___x_553_; lean_object* v___x_554_; uint8_t v___x_555_; lean_object* v___x_556_; lean_object* v___x_557_; 
v___x_551_ = lean_unsigned_to_nat(20u);
v___x_552_ = lean_nat_dec_le(v___x_551_, v___x_517_);
lean_dec(v___x_517_);
v___x_553_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__4));
v___x_554_ = lp_lean1090_Lean1090_Impl_JSON_raw(v_val_508_, v___x_553_);
lean_dec(v_val_508_);
v___x_555_ = lean_nat_dec_eq(v___x_554_, v___x_534_);
lean_dec(v___x_554_);
v___x_556_ = lean_alloc_ctor(0, 3, 2);
lean_ctor_set(v___x_556_, 0, v___y_548_);
lean_ctor_set(v___x_556_, 1, v___y_549_);
lean_ctor_set(v___x_556_, 2, v___y_550_);
lean_ctor_set_uint8(v___x_556_, sizeof(void*)*3, v___x_552_);
lean_ctor_set_uint8(v___x_556_, sizeof(void*)*3 + 1, v___x_555_);
v___x_557_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_557_, 0, v___x_545_);
lean_ctor_set(v___x_557_, 1, v___y_547_);
lean_ctor_set(v___x_557_, 2, v___x_556_);
v___y_498_ = v___x_557_;
goto v___jp_497_;
}
v___jp_558_:
{
lean_object* v___x_562_; lean_object* v___x_563_; 
v___x_562_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__5));
v___x_563_ = lp_lean1090_Lean1090_Impl_JSON_raw(v_val_508_, v___x_562_);
if (v___y_560_ == 0)
{
lean_object* v___x_564_; 
lean_del_object(v___x_514_);
v___x_564_ = lean_box(0);
v___y_547_ = v___y_559_;
v___y_548_ = v___y_561_;
v___y_549_ = v___x_563_;
v___y_550_ = v___x_564_;
goto v___jp_546_;
}
else
{
lean_object* v___x_565_; lean_object* v___x_566_; lean_object* v___x_568_; 
v___x_565_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport___closed__6));
v___x_566_ = lp_lean1090_Lean1090_Impl_JSON_raw(v_val_508_, v___x_565_);
if (v_isShared_515_ == 0)
{
lean_ctor_set(v___x_514_, 0, v___x_566_);
v___x_568_ = v___x_514_;
goto v_reusejp_567_;
}
else
{
lean_object* v_reuseFailAlloc_569_; 
v_reuseFailAlloc_569_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_569_, 0, v___x_566_);
v___x_568_ = v_reuseFailAlloc_569_;
goto v_reusejp_567_;
}
v_reusejp_567_:
{
v___y_547_ = v___y_559_;
v___y_548_ = v___y_561_;
v___y_549_ = v___x_563_;
v___y_550_ = v___x_568_;
goto v___jp_546_;
}
}
}
v___jp_570_:
{
lean_object* v___x_573_; lean_object* v___x_574_; 
v___x_573_ = lean_unsigned_to_nat(29u);
v___x_574_ = lean_nat_sub(v___x_573_, v___x_517_);
v___y_559_ = v___y_571_;
v___y_560_ = v___y_572_;
v___y_561_ = v___x_574_;
goto v___jp_558_;
}
v___jp_575_:
{
lean_object* v___x_577_; uint8_t v___x_578_; 
v___x_577_ = lean_unsigned_to_nat(19u);
v___x_578_ = lean_nat_dec_lt(v___x_517_, v___x_577_);
if (v___x_578_ == 0)
{
lean_object* v___x_579_; uint8_t v___x_580_; 
v___x_579_ = lean_unsigned_to_nat(20u);
v___x_580_ = lean_nat_dec_eq(v___x_517_, v___x_579_);
if (v___x_580_ == 0)
{
lean_object* v___x_581_; uint8_t v___x_582_; 
v___x_581_ = lean_unsigned_to_nat(21u);
v___x_582_ = lean_nat_dec_eq(v___x_517_, v___x_581_);
if (v___x_582_ == 0)
{
lean_object* v___x_583_; 
v___x_583_ = lean_unsigned_to_nat(0u);
v___y_559_ = v___y_576_;
v___y_560_ = v___x_578_;
v___y_561_ = v___x_583_;
goto v___jp_558_;
}
else
{
v___y_571_ = v___y_576_;
v___y_572_ = v___x_578_;
goto v___jp_570_;
}
}
else
{
v___y_571_ = v___y_576_;
v___y_572_ = v___x_578_;
goto v___jp_570_;
}
}
else
{
lean_object* v___x_584_; lean_object* v___x_585_; 
v___x_584_ = lean_unsigned_to_nat(18u);
v___x_585_ = lean_nat_sub(v___x_584_, v___x_517_);
v___y_559_ = v___y_576_;
v___y_560_ = v___x_578_;
v___y_561_ = v___x_585_;
goto v___jp_558_;
}
}
v___jp_586_:
{
lean_object* v___x_587_; 
v___x_587_ = lean_box(0);
v___y_576_ = v___x_587_;
goto v___jp_575_;
}
v___jp_588_:
{
lean_object* v_oracleValues_589_; lean_object* v___x_590_; 
v_oracleValues_589_ = lean_ctor_get(v_val_512_, 2);
lean_inc(v_oracleValues_589_);
lean_dec(v_val_512_);
v___x_590_ = l_List_find_x3f___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport_spec__0(v_oracleValues_589_);
lean_dec(v_oracleValues_589_);
if (lean_obj_tag(v___x_590_) == 0)
{
goto v___jp_586_;
}
else
{
lean_object* v_val_591_; lean_object* v_snd_592_; 
v_val_591_ = lean_ctor_get(v___x_590_, 0);
lean_inc(v_val_591_);
lean_dec_ref_known(v___x_590_, 1);
v_snd_592_ = lean_ctor_get(v_val_591_, 1);
lean_inc(v_snd_592_);
lean_dec(v_val_591_);
if (lean_obj_tag(v_snd_592_) == 0)
{
goto v___jp_586_;
}
else
{
lean_object* v_val_593_; lean_object* v___x_595_; uint8_t v_isShared_596_; uint8_t v_isSharedCheck_601_; 
v_val_593_ = lean_ctor_get(v_snd_592_, 0);
v_isSharedCheck_601_ = !lean_is_exclusive(v_snd_592_);
if (v_isSharedCheck_601_ == 0)
{
v___x_595_ = v_snd_592_;
v_isShared_596_ = v_isSharedCheck_601_;
goto v_resetjp_594_;
}
else
{
lean_inc(v_val_593_);
lean_dec(v_snd_592_);
v___x_595_ = lean_box(0);
v_isShared_596_ = v_isSharedCheck_601_;
goto v_resetjp_594_;
}
v_resetjp_594_:
{
lean_object* v___x_597_; lean_object* v___x_599_; 
v___x_597_ = l_Rat_floor(v_val_593_);
if (v_isShared_596_ == 0)
{
lean_ctor_set(v___x_595_, 0, v___x_597_);
v___x_599_ = v___x_595_;
goto v_reusejp_598_;
}
else
{
lean_object* v_reuseFailAlloc_600_; 
v_reuseFailAlloc_600_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_600_, 0, v___x_597_);
v___x_599_ = v_reuseFailAlloc_600_;
goto v_reusejp_598_;
}
v_reusejp_598_:
{
v___y_576_ = v___x_599_;
goto v___jp_575_;
}
}
}
}
}
v___jp_602_:
{
lean_object* v___x_603_; uint8_t v___x_604_; 
v___x_603_ = lean_unsigned_to_nat(20u);
v___x_604_ = lean_nat_dec_le(v___x_603_, v___x_517_);
if (v___x_604_ == 0)
{
lean_dec_ref_known(v___x_545_, 2);
lean_del_object(v___x_514_);
lean_dec(v_val_512_);
lean_dec(v_val_508_);
goto v___jp_535_;
}
else
{
lean_object* v___x_605_; uint8_t v___x_606_; 
v___x_605_ = lean_unsigned_to_nat(22u);
v___x_606_ = lean_nat_dec_le(v___x_517_, v___x_605_);
if (v___x_606_ == 0)
{
lean_dec_ref_known(v___x_545_, 2);
lean_del_object(v___x_514_);
lean_dec(v_val_512_);
lean_dec(v_val_508_);
goto v___jp_535_;
}
else
{
goto v___jp_588_;
}
}
}
v___jp_607_:
{
lean_object* v___x_608_; uint8_t v___x_609_; 
v___x_608_ = lean_unsigned_to_nat(9u);
v___x_609_ = lean_nat_dec_le(v___x_608_, v___x_517_);
if (v___x_609_ == 0)
{
goto v___jp_602_;
}
else
{
lean_object* v___x_610_; uint8_t v___x_611_; 
v___x_610_ = lean_unsigned_to_nat(18u);
v___x_611_ = lean_nat_dec_le(v___x_517_, v___x_610_);
if (v___x_611_ == 0)
{
goto v___jp_602_;
}
else
{
goto v___jp_588_;
}
}
}
}
}
}
}
v___jp_497_:
{
lean_object* v___x_499_; lean_object* v___x_501_; 
v___x_499_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_499_, 0, v_val_493_);
lean_ctor_set(v___x_499_, 1, v_timestamp_484_);
lean_ctor_set(v___x_499_, 2, v___y_498_);
if (v_isShared_496_ == 0)
{
lean_ctor_set(v___x_495_, 0, v___x_499_);
v___x_501_ = v___x_495_;
goto v_reusejp_500_;
}
else
{
lean_object* v_reuseFailAlloc_502_; 
v_reuseFailAlloc_502_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_502_, 0, v___x_499_);
v___x_501_ = v_reuseFailAlloc_502_;
goto v_reusejp_500_;
}
v_reusejp_500_:
{
return v___x_501_;
}
}
v___jp_503_:
{
lean_object* v___x_505_; 
v___x_505_ = lean_alloc_ctor(2, 0, 1);
lean_ctor_set_uint8(v___x_505_, 0, v___y_504_);
v___y_498_ = v___x_505_;
goto v___jp_497_;
}
}
}
}
else
{
lean_object* v___x_622_; 
lean_dec_ref(v_message_485_);
lean_dec_ref(v_timestamp_484_);
v___x_622_ = lean_box(0);
return v___x_622_;
}
}
}
LEAN_EXPORT uint8_t l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance___lam__0(lean_object* v_x_623_){
_start:
{
uint8_t v___x_624_; 
v___x_624_ = 0;
return v___x_624_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance___lam__0___boxed(lean_object* v_x_625_){
_start:
{
uint8_t v_res_626_; lean_object* v_r_627_; 
v_res_626_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance___lam__0(v_x_625_);
lean_dec_ref(v_x_625_);
v_r_627_ = lean_box(v_res_626_);
return v_r_627_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance(lean_object* v_geo_629_, lean_object* v_state_630_, lean_object* v_timestamp_631_, lean_object* v_message_632_){
_start:
{
lean_object* v___x_633_; 
v___x_633_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport(v_timestamp_631_, v_message_632_);
if (lean_obj_tag(v___x_633_) == 0)
{
lean_object* v___x_634_; lean_object* v___x_635_; 
lean_dec_ref(v_geo_629_);
v___x_634_ = lean_box(0);
v___x_635_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_635_, 0, v_state_630_);
lean_ctor_set(v___x_635_, 1, v___x_634_);
return v___x_635_;
}
else
{
lean_object* v_val_636_; lean_object* v___f_637_; lean_object* v___x_638_; 
v_val_636_ = lean_ctor_get(v___x_633_, 0);
lean_inc(v_val_636_);
lean_dec_ref_known(v___x_633_, 1);
v___f_637_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance___closed__0));
v___x_638_ = lp_lean1090_Lean1090_Impl_CPR_Policy_streamStep(v_geo_629_, v___f_637_, v_state_630_, v_val_636_);
return v___x_638_;
}
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_floatBits(lean_object* v_value_639_){
_start:
{
double v___x_640_; uint64_t v___x_641_; lean_object* v___x_642_; 
v___x_640_ = lp_lean1090_Lean1090_Impl_CPR_Policy_toFloat(v_value_639_);
v___x_641_ = lean_float_to_bits(v___x_640_);
v___x_642_ = lean_uint64_to_nat(v___x_641_);
return v___x_642_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0_spec__0_spec__1(size_t v_sz_643_, size_t v_i_644_, lean_object* v_bs_645_){
_start:
{
uint8_t v___x_646_; 
v___x_646_ = lean_usize_dec_lt(v_i_644_, v_sz_643_);
if (v___x_646_ == 0)
{
return v_bs_645_;
}
else
{
lean_object* v_v_647_; lean_object* v___x_648_; lean_object* v_bs_x27_649_; lean_object* v___x_650_; lean_object* v___x_651_; size_t v___x_652_; size_t v___x_653_; lean_object* v___x_654_; 
v_v_647_ = lean_array_uget(v_bs_645_, v_i_644_);
v___x_648_ = lean_unsigned_to_nat(0u);
v_bs_x27_649_ = lean_array_uset(v_bs_645_, v_i_644_, v___x_648_);
v___x_650_ = l_Lean_JsonNumber_fromNat(v_v_647_);
v___x_651_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_651_, 0, v___x_650_);
v___x_652_ = ((size_t)1ULL);
v___x_653_ = lean_usize_add(v_i_644_, v___x_652_);
v___x_654_ = lean_array_uset(v_bs_x27_649_, v_i_644_, v___x_651_);
v_i_644_ = v___x_653_;
v_bs_645_ = v___x_654_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0_spec__0_spec__1___boxed(lean_object* v_sz_656_, lean_object* v_i_657_, lean_object* v_bs_658_){
_start:
{
size_t v_sz_boxed_659_; size_t v_i_boxed_660_; lean_object* v_res_661_; 
v_sz_boxed_659_ = lean_unbox_usize(v_sz_656_);
lean_dec(v_sz_656_);
v_i_boxed_660_ = lean_unbox_usize(v_i_657_);
lean_dec(v_i_657_);
v_res_661_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0_spec__0_spec__1(v_sz_boxed_659_, v_i_boxed_660_, v_bs_658_);
return v_res_661_;
}
}
LEAN_EXPORT lean_object* l_Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0_spec__0(lean_object* v_a_662_){
_start:
{
size_t v_sz_663_; size_t v___x_664_; lean_object* v___x_665_; lean_object* v___x_666_; 
v_sz_663_ = lean_array_size(v_a_662_);
v___x_664_ = ((size_t)0ULL);
v___x_665_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0_spec__0_spec__1(v_sz_663_, v___x_664_, v_a_662_);
v___x_666_ = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(v___x_666_, 0, v___x_665_);
return v___x_666_;
}
}
LEAN_EXPORT lean_object* l_Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0(lean_object* v_a_667_){
_start:
{
lean_object* v___x_668_; lean_object* v___x_669_; 
v___x_668_ = lean_array_mk(v_a_667_);
v___x_669_ = l_Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0_spec__0(v___x_668_);
return v___x_669_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson(lean_object* v_p_670_){
_start:
{
if (lean_obj_tag(v_p_670_) == 0)
{
lean_object* v___x_671_; 
v___x_671_ = lean_box(0);
return v___x_671_;
}
else
{
lean_object* v_val_672_; lean_object* v_lat_673_; lean_object* v_lon_674_; lean_object* v___x_676_; uint8_t v_isShared_677_; uint8_t v_isSharedCheck_686_; 
v_val_672_ = lean_ctor_get(v_p_670_, 0);
lean_inc(v_val_672_);
lean_dec_ref_known(v_p_670_, 1);
v_lat_673_ = lean_ctor_get(v_val_672_, 0);
v_lon_674_ = lean_ctor_get(v_val_672_, 1);
v_isSharedCheck_686_ = !lean_is_exclusive(v_val_672_);
if (v_isSharedCheck_686_ == 0)
{
v___x_676_ = v_val_672_;
v_isShared_677_ = v_isSharedCheck_686_;
goto v_resetjp_675_;
}
else
{
lean_inc(v_lon_674_);
lean_inc(v_lat_673_);
lean_dec(v_val_672_);
v___x_676_ = lean_box(0);
v_isShared_677_ = v_isSharedCheck_686_;
goto v_resetjp_675_;
}
v_resetjp_675_:
{
lean_object* v___x_678_; lean_object* v___x_679_; lean_object* v___x_680_; lean_object* v___x_682_; 
v___x_678_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_floatBits(v_lat_673_);
v___x_679_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_floatBits(v_lon_674_);
v___x_680_ = lean_box(0);
if (v_isShared_677_ == 0)
{
lean_ctor_set_tag(v___x_676_, 1);
lean_ctor_set(v___x_676_, 1, v___x_680_);
lean_ctor_set(v___x_676_, 0, v___x_679_);
v___x_682_ = v___x_676_;
goto v_reusejp_681_;
}
else
{
lean_object* v_reuseFailAlloc_685_; 
v_reuseFailAlloc_685_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_685_, 0, v___x_679_);
lean_ctor_set(v_reuseFailAlloc_685_, 1, v___x_680_);
v___x_682_ = v_reuseFailAlloc_685_;
goto v_reusejp_681_;
}
v_reusejp_681_:
{
lean_object* v___x_683_; lean_object* v___x_684_; 
v___x_683_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_683_, 0, v___x_678_);
lean_ctor_set(v___x_683_, 1, v___x_682_);
v___x_684_ = l_Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0(v___x_683_);
return v___x_684_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0_spec__0(lean_object* v_s_687_){
_start:
{
lean_object* v___x_689_; lean_object* v_putStr_690_; lean_object* v___x_691_; 
v___x_689_ = lean_get_stdout();
v_putStr_690_ = lean_ctor_get(v___x_689_, 4);
lean_inc_ref(v_putStr_690_);
lean_dec_ref(v___x_689_);
v___x_691_ = lean_apply_2(v_putStr_690_, v_s_687_, lean_box(0));
return v___x_691_;
}
}
LEAN_EXPORT lean_object* l_IO_print___at___00IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0_spec__0___boxed(lean_object* v_s_692_, lean_object* v_a_693_){
_start:
{
lean_object* v_res_694_; 
v_res_694_ = l_IO_print___at___00IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0_spec__0(v_s_692_);
return v_res_694_;
}
}
LEAN_EXPORT lean_object* l_IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0(lean_object* v_s_695_){
_start:
{
uint32_t v___x_697_; lean_object* v___x_698_; lean_object* v___x_699_; 
v___x_697_ = 10;
v___x_698_ = lean_string_push(v_s_695_, v___x_697_);
v___x_699_ = l_IO_print___at___00IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0_spec__0(v___x_698_);
return v___x_699_;
}
}
LEAN_EXPORT lean_object* l_IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0___boxed(lean_object* v_s_700_, lean_object* v_a_701_){
_start:
{
lean_object* v_res_702_; 
v_res_702_ = l_IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0(v_s_700_);
return v_res_702_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit(lean_object* v_value_703_){
_start:
{
lean_object* v___x_705_; lean_object* v___x_706_; 
v___x_705_ = l_Lean_Json_compress(v_value_703_);
v___x_706_ = l_IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0(v___x_705_);
if (lean_obj_tag(v___x_706_) == 0)
{
lean_object* v___x_707_; lean_object* v_flush_708_; lean_object* v___x_709_; 
lean_dec_ref_known(v___x_706_, 1);
v___x_707_ = lean_get_stdout();
v_flush_708_ = lean_ctor_get(v___x_707_, 0);
lean_inc_ref(v_flush_708_);
lean_dec_ref(v___x_707_);
v___x_709_ = lean_apply_1(v_flush_708_, lean_box(0));
return v___x_709_;
}
else
{
return v___x_706_;
}
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit___boxed(lean_object* v_value_710_, lean_object* v_a_711_){
_start:
{
lean_object* v_res_712_; 
v_res_712_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit(v_value_710_);
return v_res_712_;
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg(lean_object* v_expected_715_){
_start:
{
lean_object* v___x_717_; lean_object* v___x_718_; lean_object* v_getLine_719_; lean_object* v___x_720_; 
v___x_717_ = lean_box(0);
v___x_718_ = lean_get_stdin();
v_getLine_719_ = lean_ctor_get(v___x_718_, 3);
lean_inc_ref(v_getLine_719_);
lean_dec_ref(v___x_718_);
v___x_720_ = lean_apply_1(v_getLine_719_, lean_box(0));
if (lean_obj_tag(v___x_720_) == 0)
{
lean_object* v_a_721_; lean_object* v___x_723_; uint8_t v_isShared_724_; uint8_t v_isSharedCheck_743_; 
v_a_721_ = lean_ctor_get(v___x_720_, 0);
v_isSharedCheck_743_ = !lean_is_exclusive(v___x_720_);
if (v_isSharedCheck_743_ == 0)
{
v___x_723_ = v___x_720_;
v_isShared_724_ = v_isSharedCheck_743_;
goto v_resetjp_722_;
}
else
{
lean_inc(v_a_721_);
lean_dec(v___x_720_);
v___x_723_ = lean_box(0);
v_isShared_724_ = v_isSharedCheck_743_;
goto v_resetjp_722_;
}
v_resetjp_722_:
{
lean_object* v___x_725_; lean_object* v___x_726_; lean_object* v___x_727_; lean_object* v___x_728_; lean_object* v___x_729_; lean_object* v___x_730_; uint8_t v___x_731_; 
v___x_725_ = lean_unsigned_to_nat(0u);
v___x_726_ = lean_string_utf8_byte_size(v_a_721_);
v___x_727_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_727_, 0, v_a_721_);
lean_ctor_set(v___x_727_, 1, v___x_725_);
lean_ctor_set(v___x_727_, 2, v___x_726_);
v___x_728_ = l_String_Slice_trimAscii(v___x_727_);
v___x_729_ = l_String_Slice_toString(v___x_728_);
lean_dec_ref(v___x_728_);
v___x_730_ = ((lean_object*)(l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg___closed__0));
v___x_731_ = lean_string_dec_eq(v___x_729_, v___x_730_);
if (v___x_731_ == 0)
{
uint8_t v___x_732_; 
v___x_732_ = lean_string_dec_eq(v___x_729_, v_expected_715_);
lean_dec_ref(v___x_729_);
if (v___x_732_ == 0)
{
lean_object* v___x_733_; lean_object* v___x_734_; lean_object* v___x_735_; lean_object* v___x_737_; 
v___x_733_ = ((lean_object*)(l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg___closed__1));
v___x_734_ = lean_string_append(v___x_733_, v_expected_715_);
v___x_735_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_735_, 0, v___x_734_);
if (v_isShared_724_ == 0)
{
lean_ctor_set_tag(v___x_723_, 1);
lean_ctor_set(v___x_723_, 0, v___x_735_);
v___x_737_ = v___x_723_;
goto v_reusejp_736_;
}
else
{
lean_object* v_reuseFailAlloc_738_; 
v_reuseFailAlloc_738_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_738_, 0, v___x_735_);
v___x_737_ = v_reuseFailAlloc_738_;
goto v_reusejp_736_;
}
v_reusejp_736_:
{
return v___x_737_;
}
}
else
{
lean_object* v___x_740_; 
if (v_isShared_724_ == 0)
{
lean_ctor_set(v___x_723_, 0, v___x_717_);
v___x_740_ = v___x_723_;
goto v_reusejp_739_;
}
else
{
lean_object* v_reuseFailAlloc_741_; 
v_reuseFailAlloc_741_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_741_, 0, v___x_717_);
v___x_740_ = v_reuseFailAlloc_741_;
goto v_reusejp_739_;
}
v_reusejp_739_:
{
return v___x_740_;
}
}
}
else
{
lean_dec_ref(v___x_729_);
lean_del_object(v___x_723_);
goto _start;
}
}
}
else
{
lean_object* v_a_744_; lean_object* v___x_746_; uint8_t v_isShared_747_; uint8_t v_isSharedCheck_751_; 
v_a_744_ = lean_ctor_get(v___x_720_, 0);
v_isSharedCheck_751_ = !lean_is_exclusive(v___x_720_);
if (v_isSharedCheck_751_ == 0)
{
v___x_746_ = v___x_720_;
v_isShared_747_ = v_isSharedCheck_751_;
goto v_resetjp_745_;
}
else
{
lean_inc(v_a_744_);
lean_dec(v___x_720_);
v___x_746_ = lean_box(0);
v_isShared_747_ = v_isSharedCheck_751_;
goto v_resetjp_745_;
}
v_resetjp_745_:
{
lean_object* v___x_749_; 
if (v_isShared_747_ == 0)
{
v___x_749_ = v___x_746_;
goto v_reusejp_748_;
}
else
{
lean_object* v_reuseFailAlloc_750_; 
v_reuseFailAlloc_750_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_750_, 0, v_a_744_);
v___x_749_ = v_reuseFailAlloc_750_;
goto v_reusejp_748_;
}
v_reusejp_748_:
{
return v___x_749_;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg___boxed(lean_object* v_expected_752_, lean_object* v___y_753_){
_start:
{
lean_object* v_res_754_; 
v_res_754_ = l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg(v_expected_752_);
lean_dec_ref(v_expected_752_);
return v_res_754_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command(uint8_t v_enabled_755_, lean_object* v_expected_756_){
_start:
{
if (v_enabled_755_ == 0)
{
lean_object* v___x_758_; lean_object* v___x_759_; 
v___x_758_ = lean_box(0);
v___x_759_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_759_, 0, v___x_758_);
return v___x_759_;
}
else
{
lean_object* v___x_760_; lean_object* v___x_761_; 
v___x_760_ = lean_box(0);
v___x_761_ = l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg(v_expected_756_);
if (lean_obj_tag(v___x_761_) == 0)
{
lean_object* v___x_763_; uint8_t v_isShared_764_; uint8_t v_isSharedCheck_768_; 
v_isSharedCheck_768_ = !lean_is_exclusive(v___x_761_);
if (v_isSharedCheck_768_ == 0)
{
lean_object* v_unused_769_; 
v_unused_769_ = lean_ctor_get(v___x_761_, 0);
lean_dec(v_unused_769_);
v___x_763_ = v___x_761_;
v_isShared_764_ = v_isSharedCheck_768_;
goto v_resetjp_762_;
}
else
{
lean_dec(v___x_761_);
v___x_763_ = lean_box(0);
v_isShared_764_ = v_isSharedCheck_768_;
goto v_resetjp_762_;
}
v_resetjp_762_:
{
lean_object* v___x_766_; 
if (v_isShared_764_ == 0)
{
lean_ctor_set(v___x_763_, 0, v___x_760_);
v___x_766_ = v___x_763_;
goto v_reusejp_765_;
}
else
{
lean_object* v_reuseFailAlloc_767_; 
v_reuseFailAlloc_767_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_767_, 0, v___x_760_);
v___x_766_ = v_reuseFailAlloc_767_;
goto v_reusejp_765_;
}
v_reusejp_765_:
{
return v___x_766_;
}
}
}
else
{
return v___x_761_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command___boxed(lean_object* v_enabled_770_, lean_object* v_expected_771_, lean_object* v_a_772_){
_start:
{
uint8_t v_enabled_boxed_773_; lean_object* v_res_774_; 
v_enabled_boxed_773_ = lean_unbox(v_enabled_770_);
v_res_774_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command(v_enabled_boxed_773_, v_expected_771_);
lean_dec_ref(v_expected_771_);
return v_res_774_;
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0(lean_object* v_expected_775_, lean_object* v_inst_776_, lean_object* v_a_777_){
_start:
{
lean_object* v___x_779_; 
v___x_779_ = l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___redArg(v_expected_775_);
return v___x_779_;
}
}
LEAN_EXPORT lean_object* l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0___boxed(lean_object* v_expected_780_, lean_object* v_inst_781_, lean_object* v_a_782_, lean_object* v___y_783_){
_start:
{
lean_object* v_res_784_; 
v_res_784_ = l___private_Init_While_0__repeatM_erased___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command_spec__0(v_expected_780_, v_inst_781_, v_a_782_);
lean_dec_ref(v_expected_780_);
return v_res_784_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0(lean_object* v_geo_788_, lean_object* v_as_789_, size_t v_sz_790_, size_t v_i_791_, lean_object* v_b_792_){
_start:
{
uint8_t v___x_794_; 
v___x_794_ = lean_usize_dec_lt(v_i_791_, v_sz_790_);
if (v___x_794_ == 0)
{
lean_object* v___x_795_; 
lean_dec_ref(v_geo_788_);
v___x_795_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_795_, 0, v_b_792_);
return v___x_795_;
}
else
{
lean_object* v_a_796_; lean_object* v_timestamp_797_; lean_object* v_bytes_798_; lean_object* v___x_799_; 
v_a_796_ = lean_array_uget_borrowed(v_as_789_, v_i_791_);
v_timestamp_797_ = lean_ctor_get(v_a_796_, 0);
v_bytes_798_ = lean_ctor_get(v_a_796_, 1);
lean_inc(v_bytes_798_);
v___x_799_ = lp_lean1090_Lean1090_Impl_decode(v_bytes_798_);
if (lean_obj_tag(v___x_799_) == 1)
{
lean_object* v_val_800_; lean_object* v_fst_801_; lean_object* v_snd_802_; lean_object* v___x_804_; uint8_t v_isShared_805_; uint8_t v_isSharedCheck_823_; 
v_val_800_ = lean_ctor_get(v___x_799_, 0);
lean_inc(v_val_800_);
lean_dec_ref_known(v___x_799_, 1);
v_fst_801_ = lean_ctor_get(v_b_792_, 0);
v_snd_802_ = lean_ctor_get(v_b_792_, 1);
v_isSharedCheck_823_ = !lean_is_exclusive(v_b_792_);
if (v_isSharedCheck_823_ == 0)
{
v___x_804_ = v_b_792_;
v_isShared_805_ = v_isSharedCheck_823_;
goto v_resetjp_803_;
}
else
{
lean_inc(v_snd_802_);
lean_inc(v_fst_801_);
lean_dec(v_b_792_);
v___x_804_ = lean_box(0);
v_isShared_805_ = v_isSharedCheck_823_;
goto v_resetjp_803_;
}
v_resetjp_803_:
{
lean_object* v___x_806_; lean_object* v_fst_807_; lean_object* v_snd_808_; lean_object* v___x_810_; uint8_t v_isShared_811_; uint8_t v_isSharedCheck_822_; 
lean_inc(v_val_800_);
lean_inc_ref(v_timestamp_797_);
lean_inc_ref(v_geo_788_);
v___x_806_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_advance(v_geo_788_, v_snd_802_, v_timestamp_797_, v_val_800_);
v_fst_807_ = lean_ctor_get(v___x_806_, 0);
v_snd_808_ = lean_ctor_get(v___x_806_, 1);
v_isSharedCheck_822_ = !lean_is_exclusive(v___x_806_);
if (v_isSharedCheck_822_ == 0)
{
v___x_810_ = v___x_806_;
v_isShared_811_ = v_isSharedCheck_822_;
goto v_resetjp_809_;
}
else
{
lean_inc(v_snd_808_);
lean_inc(v_fst_807_);
lean_dec(v___x_806_);
v___x_810_ = lean_box(0);
v_isShared_811_ = v_isSharedCheck_822_;
goto v_resetjp_809_;
}
v_resetjp_809_:
{
lean_object* v___x_813_; 
if (v_isShared_805_ == 0)
{
lean_ctor_set(v___x_804_, 1, v_snd_808_);
lean_ctor_set(v___x_804_, 0, v_val_800_);
v___x_813_ = v___x_804_;
goto v_reusejp_812_;
}
else
{
lean_object* v_reuseFailAlloc_821_; 
v_reuseFailAlloc_821_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_821_, 0, v_val_800_);
lean_ctor_set(v_reuseFailAlloc_821_, 1, v_snd_808_);
v___x_813_ = v_reuseFailAlloc_821_;
goto v_reusejp_812_;
}
v_reusejp_812_:
{
lean_object* v___x_814_; lean_object* v___x_816_; 
v___x_814_ = lean_array_push(v_fst_801_, v___x_813_);
if (v_isShared_811_ == 0)
{
lean_ctor_set(v___x_810_, 1, v_fst_807_);
lean_ctor_set(v___x_810_, 0, v___x_814_);
v___x_816_ = v___x_810_;
goto v_reusejp_815_;
}
else
{
lean_object* v_reuseFailAlloc_820_; 
v_reuseFailAlloc_820_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_820_, 0, v___x_814_);
lean_ctor_set(v_reuseFailAlloc_820_, 1, v_fst_807_);
v___x_816_ = v_reuseFailAlloc_820_;
goto v_reusejp_815_;
}
v_reusejp_815_:
{
size_t v___x_817_; size_t v___x_818_; 
v___x_817_ = ((size_t)1ULL);
v___x_818_ = lean_usize_add(v_i_791_, v___x_817_);
v_i_791_ = v___x_818_;
v_b_792_ = v___x_816_;
goto _start;
}
}
}
}
}
else
{
lean_object* v___x_824_; lean_object* v___x_825_; 
lean_dec(v___x_799_);
lean_dec_ref(v_b_792_);
lean_dec_ref(v_geo_788_);
v___x_824_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0___closed__1));
v___x_825_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_825_, 0, v___x_824_);
return v___x_825_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0___boxed(lean_object* v_geo_826_, lean_object* v_as_827_, lean_object* v_sz_828_, lean_object* v_i_829_, lean_object* v_b_830_, lean_object* v___y_831_){
_start:
{
size_t v_sz_boxed_832_; size_t v_i_boxed_833_; lean_object* v_res_834_; 
v_sz_boxed_832_ = lean_unbox_usize(v_sz_828_);
lean_dec(v_sz_828_);
v_i_boxed_833_ = lean_unbox_usize(v_i_829_);
lean_dec(v_i_829_);
v_res_834_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0(v_geo_826_, v_as_827_, v_sz_boxed_832_, v_i_boxed_833_, v_b_830_);
lean_dec_ref(v_as_827_);
return v_res_834_;
}
}
LEAN_EXPORT lean_object* l_Lean1090_Diagnostics_CPRCosts_runCPR(lean_object* v_inputs_838_, lean_object* v_geo_839_){
_start:
{
lean_object* v___x_841_; lean_object* v_output_842_; lean_object* v_state_843_; lean_object* v___x_844_; size_t v_sz_845_; size_t v___x_846_; lean_object* v___x_847_; 
v___x_841_ = lean_array_get_size(v_inputs_838_);
v_output_842_ = lean_mk_empty_array_with_capacity(v___x_841_);
v_state_843_ = ((lean_object*)(l_Lean1090_Diagnostics_CPRCosts_runCPR___closed__0));
v___x_844_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_844_, 0, v_output_842_);
lean_ctor_set(v___x_844_, 1, v_state_843_);
v_sz_845_ = lean_array_size(v_inputs_838_);
v___x_846_ = ((size_t)0ULL);
v___x_847_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Lean1090_Diagnostics_CPRCosts_runCPR_spec__0(v_geo_839_, v_inputs_838_, v_sz_845_, v___x_846_, v___x_844_);
if (lean_obj_tag(v___x_847_) == 0)
{
lean_object* v_a_848_; lean_object* v___x_850_; uint8_t v_isShared_851_; uint8_t v_isSharedCheck_864_; 
v_a_848_ = lean_ctor_get(v___x_847_, 0);
v_isSharedCheck_864_ = !lean_is_exclusive(v___x_847_);
if (v_isSharedCheck_864_ == 0)
{
v___x_850_ = v___x_847_;
v_isShared_851_ = v_isSharedCheck_864_;
goto v_resetjp_849_;
}
else
{
lean_inc(v_a_848_);
lean_dec(v___x_847_);
v___x_850_ = lean_box(0);
v_isShared_851_ = v_isSharedCheck_864_;
goto v_resetjp_849_;
}
v_resetjp_849_:
{
lean_object* v_fst_852_; lean_object* v_snd_853_; lean_object* v___x_855_; uint8_t v_isShared_856_; uint8_t v_isSharedCheck_863_; 
v_fst_852_ = lean_ctor_get(v_a_848_, 0);
v_snd_853_ = lean_ctor_get(v_a_848_, 1);
v_isSharedCheck_863_ = !lean_is_exclusive(v_a_848_);
if (v_isSharedCheck_863_ == 0)
{
v___x_855_ = v_a_848_;
v_isShared_856_ = v_isSharedCheck_863_;
goto v_resetjp_854_;
}
else
{
lean_inc(v_snd_853_);
lean_inc(v_fst_852_);
lean_dec(v_a_848_);
v___x_855_ = lean_box(0);
v_isShared_856_ = v_isSharedCheck_863_;
goto v_resetjp_854_;
}
v_resetjp_854_:
{
lean_object* v___x_858_; 
if (v_isShared_856_ == 0)
{
v___x_858_ = v___x_855_;
goto v_reusejp_857_;
}
else
{
lean_object* v_reuseFailAlloc_862_; 
v_reuseFailAlloc_862_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_862_, 0, v_fst_852_);
lean_ctor_set(v_reuseFailAlloc_862_, 1, v_snd_853_);
v___x_858_ = v_reuseFailAlloc_862_;
goto v_reusejp_857_;
}
v_reusejp_857_:
{
lean_object* v___x_860_; 
if (v_isShared_851_ == 0)
{
lean_ctor_set(v___x_850_, 0, v___x_858_);
v___x_860_ = v___x_850_;
goto v_reusejp_859_;
}
else
{
lean_object* v_reuseFailAlloc_861_; 
v_reuseFailAlloc_861_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_861_, 0, v___x_858_);
v___x_860_ = v_reuseFailAlloc_861_;
goto v_reusejp_859_;
}
v_reusejp_859_:
{
return v___x_860_;
}
}
}
}
}
else
{
return v___x_847_;
}
}
}
LEAN_EXPORT lean_object* l_Lean1090_Diagnostics_CPRCosts_runCPR___boxed(lean_object* v_inputs_865_, lean_object* v_geo_866_, lean_object* v_a_867_){
_start:
{
lean_object* v_res_868_; 
v_res_868_ = l_Lean1090_Diagnostics_CPRCosts_runCPR(v_inputs_865_, v_geo_866_);
lean_dec_ref(v_inputs_865_);
return v_res_868_;
}
}
LEAN_EXPORT uint64_t l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes_spec__0(lean_object* v_as_869_, size_t v_i_870_, size_t v_stop_871_, uint64_t v_b_872_){
_start:
{
uint8_t v___x_873_; 
v___x_873_ = lean_usize_dec_eq(v_i_870_, v_stop_871_);
if (v___x_873_ == 0)
{
lean_object* v___x_874_; uint8_t v___x_875_; uint64_t v___x_876_; uint64_t v___x_877_; uint64_t v___x_878_; uint64_t v___x_879_; size_t v___x_880_; size_t v___x_881_; 
v___x_874_ = lean_array_uget_borrowed(v_as_869_, v_i_870_);
v___x_875_ = lean_unbox(v___x_874_);
v___x_876_ = lean_uint8_to_uint64(v___x_875_);
v___x_877_ = lean_uint64_xor(v_b_872_, v___x_876_);
v___x_878_ = 1099511628211ULL;
v___x_879_ = lean_uint64_mul(v___x_877_, v___x_878_);
v___x_880_ = ((size_t)1ULL);
v___x_881_ = lean_usize_add(v_i_870_, v___x_880_);
v_i_870_ = v___x_881_;
v_b_872_ = v___x_879_;
goto _start;
}
else
{
return v_b_872_;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes_spec__0___boxed(lean_object* v_as_883_, lean_object* v_i_884_, lean_object* v_stop_885_, lean_object* v_b_886_){
_start:
{
size_t v_i_boxed_887_; size_t v_stop_boxed_888_; uint64_t v_b_boxed_889_; uint64_t v_res_890_; lean_object* v_r_891_; 
v_i_boxed_887_ = lean_unbox_usize(v_i_884_);
lean_dec(v_i_884_);
v_stop_boxed_888_ = lean_unbox_usize(v_stop_885_);
lean_dec(v_stop_885_);
v_b_boxed_889_ = lean_unbox_uint64(v_b_886_);
lean_dec_ref(v_b_886_);
v_res_890_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes_spec__0(v_as_883_, v_i_boxed_887_, v_stop_boxed_888_, v_b_boxed_889_);
lean_dec_ref(v_as_883_);
v_r_891_ = lean_box_uint64(v_res_890_);
return v_r_891_;
}
}
LEAN_EXPORT uint64_t l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes(uint64_t v_hash_892_, lean_object* v_bytes_893_){
_start:
{
lean_object* v___x_894_; lean_object* v___x_895_; lean_object* v___x_896_; uint8_t v___x_897_; 
v___x_894_ = lean_byte_array_data(v_bytes_893_);
v___x_895_ = lean_unsigned_to_nat(0u);
v___x_896_ = lean_array_get_size(v___x_894_);
v___x_897_ = lean_nat_dec_lt(v___x_895_, v___x_896_);
if (v___x_897_ == 0)
{
lean_dec_ref(v___x_894_);
return v_hash_892_;
}
else
{
uint8_t v___x_898_; 
v___x_898_ = lean_nat_dec_le(v___x_896_, v___x_896_);
if (v___x_898_ == 0)
{
if (v___x_897_ == 0)
{
lean_dec_ref(v___x_894_);
return v_hash_892_;
}
else
{
size_t v___x_899_; size_t v___x_900_; uint64_t v___x_901_; 
v___x_899_ = ((size_t)0ULL);
v___x_900_ = lean_usize_of_nat(v___x_896_);
v___x_901_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes_spec__0(v___x_894_, v___x_899_, v___x_900_, v_hash_892_);
lean_dec_ref(v___x_894_);
return v___x_901_;
}
}
else
{
size_t v___x_902_; size_t v___x_903_; uint64_t v___x_904_; 
v___x_902_ = ((size_t)0ULL);
v___x_903_ = lean_usize_of_nat(v___x_896_);
v___x_904_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes_spec__0(v___x_894_, v___x_902_, v___x_903_, v_hash_892_);
lean_dec_ref(v___x_894_);
return v___x_904_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes___boxed(lean_object* v_hash_905_, lean_object* v_bytes_906_){
_start:
{
uint64_t v_hash_boxed_907_; uint64_t v_res_908_; lean_object* v_r_909_; 
v_hash_boxed_907_ = lean_unbox_uint64(v_hash_905_);
lean_dec_ref(v_hash_905_);
v_res_908_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes(v_hash_boxed_907_, v_bytes_906_);
v_r_909_ = lean_box_uint64(v_res_908_);
return v_r_909_;
}
}
LEAN_EXPORT lean_object* l_Lean_Option_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__0(lean_object* v_x_910_){
_start:
{
if (lean_obj_tag(v_x_910_) == 0)
{
lean_object* v___x_911_; 
v___x_911_ = lean_box(0);
return v___x_911_;
}
else
{
lean_object* v_val_912_; lean_object* v___x_914_; uint8_t v_isShared_915_; uint8_t v_isSharedCheck_920_; 
v_val_912_ = lean_ctor_get(v_x_910_, 0);
v_isSharedCheck_920_ = !lean_is_exclusive(v_x_910_);
if (v_isSharedCheck_920_ == 0)
{
v___x_914_ = v_x_910_;
v_isShared_915_ = v_isSharedCheck_920_;
goto v_resetjp_913_;
}
else
{
lean_inc(v_val_912_);
lean_dec(v_x_910_);
v___x_914_ = lean_box(0);
v_isShared_915_ = v_isSharedCheck_920_;
goto v_resetjp_913_;
}
v_resetjp_913_:
{
lean_object* v___x_916_; lean_object* v___x_918_; 
v___x_916_ = l_Lean_JsonNumber_fromInt(v_val_912_);
if (v_isShared_915_ == 0)
{
lean_ctor_set_tag(v___x_914_, 2);
lean_ctor_set(v___x_914_, 0, v___x_916_);
v___x_918_ = v___x_914_;
goto v_reusejp_917_;
}
else
{
lean_object* v_reuseFailAlloc_919_; 
v_reuseFailAlloc_919_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_919_, 0, v___x_916_);
v___x_918_ = v_reuseFailAlloc_919_;
goto v_reusejp_917_;
}
v_reusejp_917_:
{
return v___x_918_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Option_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__1(lean_object* v_x_921_){
_start:
{
if (lean_obj_tag(v_x_921_) == 0)
{
lean_object* v___x_922_; 
v___x_922_ = lean_box(0);
return v___x_922_;
}
else
{
lean_object* v_val_923_; lean_object* v___x_925_; uint8_t v_isShared_926_; uint8_t v_isSharedCheck_930_; 
v_val_923_ = lean_ctor_get(v_x_921_, 0);
v_isSharedCheck_930_ = !lean_is_exclusive(v_x_921_);
if (v_isSharedCheck_930_ == 0)
{
v___x_925_ = v_x_921_;
v_isShared_926_ = v_isSharedCheck_930_;
goto v_resetjp_924_;
}
else
{
lean_inc(v_val_923_);
lean_dec(v_x_921_);
v___x_925_ = lean_box(0);
v_isShared_926_ = v_isSharedCheck_930_;
goto v_resetjp_924_;
}
v_resetjp_924_:
{
lean_object* v___x_928_; 
if (v_isShared_926_ == 0)
{
lean_ctor_set_tag(v___x_925_, 3);
v___x_928_ = v___x_925_;
goto v_reusejp_927_;
}
else
{
lean_object* v_reuseFailAlloc_929_; 
v_reuseFailAlloc_929_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_929_, 0, v_val_923_);
v___x_928_ = v_reuseFailAlloc_929_;
goto v_reusejp_927_;
}
v_reusejp_927_:
{
return v___x_928_;
}
}
}
}
}
LEAN_EXPORT uint8_t l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__0(lean_object* v_a_931_, lean_object* v_b_932_){
_start:
{
lean_object* v___x_933_; uint8_t v___x_934_; 
v___x_933_ = lean_alloc_closure((void*)(lp_lean1090_Lean1090_Spec_CPR_instDecidableEqPosition___boxed), 2, 0);
v___x_934_ = l_Option_instDecidableEq___redArg(v___x_933_, v_a_931_, v_b_932_);
return v___x_934_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__0___boxed(lean_object* v_a_935_, lean_object* v_b_936_){
_start:
{
uint8_t v_res_937_; lean_object* v_r_938_; 
v_res_937_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__0(v_a_935_, v_b_936_);
v_r_938_ = lean_box(v_res_937_);
return v_r_938_;
}
}
LEAN_EXPORT uint8_t l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__1(lean_object* v_a_939_, lean_object* v_b_940_){
_start:
{
lean_object* v_fst_941_; lean_object* v_fst_942_; uint8_t v___x_943_; 
v_fst_941_ = lean_ctor_get(v_a_939_, 0);
v_fst_942_ = lean_ctor_get(v_b_940_, 0);
v___x_943_ = lean_nat_dec_le(v_fst_941_, v_fst_942_);
return v___x_943_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__1___boxed(lean_object* v_a_944_, lean_object* v_b_945_){
_start:
{
uint8_t v_res_946_; lean_object* v_r_947_; 
v_res_946_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__1(v_a_944_, v_b_945_);
lean_dec_ref(v_b_945_);
lean_dec_ref(v_a_944_);
v_r_947_ = lean_box(v_res_946_);
return v_r_947_;
}
}
LEAN_EXPORT uint8_t l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__2(uint8_t v___x_948_, lean_object* v_x_949_){
_start:
{
return v___x_948_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__2___boxed(lean_object* v___x_950_, lean_object* v_x_951_){
_start:
{
uint8_t v___x_4457__boxed_952_; uint8_t v_res_953_; lean_object* v_r_954_; 
v___x_4457__boxed_952_ = lean_unbox(v___x_950_);
v_res_953_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___lam__2(v___x_4457__boxed_952_, v_x_951_);
lean_dec_ref(v_x_951_);
v_r_954_ = lean_box(v_res_953_);
return v_r_954_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg(lean_object* v_inputs_958_, lean_object* v_output_959_, lean_object* v_range_960_, lean_object* v_b_961_, lean_object* v_i_962_){
_start:
{
lean_object* v_stop_964_; lean_object* v_step_965_; lean_object* v_a_967_; uint8_t v___x_970_; 
v_stop_964_ = lean_ctor_get(v_range_960_, 1);
v_step_965_ = lean_ctor_get(v_range_960_, 2);
v___x_970_ = lean_nat_dec_lt(v_i_962_, v_stop_964_);
if (v___x_970_ == 0)
{
lean_object* v___x_971_; 
lean_dec(v_i_962_);
v___x_971_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_971_, 0, v_b_961_);
return v___x_971_;
}
else
{
lean_object* v___x_972_; uint8_t v___x_973_; 
v___x_972_ = lean_array_get_size(v_inputs_958_);
v___x_973_ = lean_nat_dec_lt(v_i_962_, v___x_972_);
if (v___x_973_ == 0)
{
lean_object* v___x_974_; lean_object* v___x_975_; 
lean_dec(v_i_962_);
lean_dec_ref(v_b_961_);
v___x_974_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg___closed__1));
v___x_975_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_975_, 0, v___x_974_);
return v___x_975_;
}
else
{
lean_object* v_fst_976_; lean_object* v_snd_977_; lean_object* v___x_979_; uint8_t v_isShared_980_; uint8_t v_isSharedCheck_1009_; 
v_fst_976_ = lean_ctor_get(v_b_961_, 0);
v_snd_977_ = lean_ctor_get(v_b_961_, 1);
v_isSharedCheck_1009_ = !lean_is_exclusive(v_b_961_);
if (v_isSharedCheck_1009_ == 0)
{
v___x_979_ = v_b_961_;
v_isShared_980_ = v_isSharedCheck_1009_;
goto v_resetjp_978_;
}
else
{
lean_inc(v_snd_977_);
lean_inc(v_fst_976_);
lean_dec(v_b_961_);
v___x_979_ = lean_box(0);
v_isShared_980_ = v_isSharedCheck_1009_;
goto v_resetjp_978_;
}
v_resetjp_978_:
{
lean_object* v___x_981_; lean_object* v_timestamp_982_; lean_object* v___x_984_; uint8_t v_isShared_985_; uint8_t v_isSharedCheck_1007_; 
v___x_981_ = lean_array_fget(v_inputs_958_, v_i_962_);
v_timestamp_982_ = lean_ctor_get(v___x_981_, 0);
v_isSharedCheck_1007_ = !lean_is_exclusive(v___x_981_);
if (v_isSharedCheck_1007_ == 0)
{
lean_object* v_unused_1008_; 
v_unused_1008_ = lean_ctor_get(v___x_981_, 1);
lean_dec(v_unused_1008_);
v___x_984_ = v___x_981_;
v_isShared_985_ = v_isSharedCheck_1007_;
goto v_resetjp_983_;
}
else
{
lean_inc(v_timestamp_982_);
lean_dec(v___x_981_);
v___x_984_ = lean_box(0);
v_isShared_985_ = v_isSharedCheck_1007_;
goto v_resetjp_983_;
}
v_resetjp_983_:
{
lean_object* v___x_986_; lean_object* v_message_987_; lean_object* v_position_988_; lean_object* v___x_990_; uint8_t v_isShared_991_; uint8_t v_isSharedCheck_1006_; 
v___x_986_ = lean_array_fget(v_output_959_, v_i_962_);
v_message_987_ = lean_ctor_get(v___x_986_, 0);
v_position_988_ = lean_ctor_get(v___x_986_, 1);
v_isSharedCheck_1006_ = !lean_is_exclusive(v___x_986_);
if (v_isSharedCheck_1006_ == 0)
{
v___x_990_ = v___x_986_;
v_isShared_991_ = v_isSharedCheck_1006_;
goto v_resetjp_989_;
}
else
{
lean_inc(v_position_988_);
lean_inc(v_message_987_);
lean_dec(v___x_986_);
v___x_990_ = lean_box(0);
v_isShared_991_ = v_isSharedCheck_1006_;
goto v_resetjp_989_;
}
v_resetjp_989_:
{
lean_object* v___x_992_; 
v___x_992_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport(v_timestamp_982_, v_message_987_);
if (lean_obj_tag(v___x_992_) == 1)
{
lean_object* v_val_993_; lean_object* v___x_995_; 
v_val_993_ = lean_ctor_get(v___x_992_, 0);
lean_inc(v_val_993_);
lean_dec_ref_known(v___x_992_, 1);
if (v_isShared_991_ == 0)
{
lean_ctor_set_tag(v___x_990_, 1);
lean_ctor_set(v___x_990_, 1, v_fst_976_);
lean_ctor_set(v___x_990_, 0, v_val_993_);
v___x_995_ = v___x_990_;
goto v_reusejp_994_;
}
else
{
lean_object* v_reuseFailAlloc_1002_; 
v_reuseFailAlloc_1002_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1002_, 0, v_val_993_);
lean_ctor_set(v_reuseFailAlloc_1002_, 1, v_fst_976_);
v___x_995_ = v_reuseFailAlloc_1002_;
goto v_reusejp_994_;
}
v_reusejp_994_:
{
lean_object* v___x_997_; 
if (v_isShared_985_ == 0)
{
lean_ctor_set_tag(v___x_984_, 1);
lean_ctor_set(v___x_984_, 1, v_snd_977_);
lean_ctor_set(v___x_984_, 0, v_position_988_);
v___x_997_ = v___x_984_;
goto v_reusejp_996_;
}
else
{
lean_object* v_reuseFailAlloc_1001_; 
v_reuseFailAlloc_1001_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1001_, 0, v_position_988_);
lean_ctor_set(v_reuseFailAlloc_1001_, 1, v_snd_977_);
v___x_997_ = v_reuseFailAlloc_1001_;
goto v_reusejp_996_;
}
v_reusejp_996_:
{
lean_object* v___x_999_; 
if (v_isShared_980_ == 0)
{
lean_ctor_set(v___x_979_, 1, v___x_997_);
lean_ctor_set(v___x_979_, 0, v___x_995_);
v___x_999_ = v___x_979_;
goto v_reusejp_998_;
}
else
{
lean_object* v_reuseFailAlloc_1000_; 
v_reuseFailAlloc_1000_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1000_, 0, v___x_995_);
lean_ctor_set(v_reuseFailAlloc_1000_, 1, v___x_997_);
v___x_999_ = v_reuseFailAlloc_1000_;
goto v_reusejp_998_;
}
v_reusejp_998_:
{
v_a_967_ = v___x_999_;
goto v___jp_966_;
}
}
}
}
else
{
lean_object* v___x_1004_; 
lean_dec(v___x_992_);
lean_del_object(v___x_990_);
lean_dec(v_position_988_);
lean_del_object(v___x_984_);
if (v_isShared_980_ == 0)
{
v___x_1004_ = v___x_979_;
goto v_reusejp_1003_;
}
else
{
lean_object* v_reuseFailAlloc_1005_; 
v_reuseFailAlloc_1005_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1005_, 0, v_fst_976_);
lean_ctor_set(v_reuseFailAlloc_1005_, 1, v_snd_977_);
v___x_1004_ = v_reuseFailAlloc_1005_;
goto v_reusejp_1003_;
}
v_reusejp_1003_:
{
v_a_967_ = v___x_1004_;
goto v___jp_966_;
}
}
}
}
}
}
}
v___jp_966_:
{
lean_object* v___x_968_; 
v___x_968_ = lean_nat_add(v_i_962_, v_step_965_);
lean_dec(v_i_962_);
v_b_961_ = v_a_967_;
v_i_962_ = v___x_968_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg___boxed(lean_object* v_inputs_1010_, lean_object* v_output_1011_, lean_object* v_range_1012_, lean_object* v_b_1013_, lean_object* v_i_1014_, lean_object* v___y_1015_){
_start:
{
lean_object* v_res_1016_; 
v_res_1016_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg(v_inputs_1010_, v_output_1011_, v_range_1012_, v_b_1013_, v_i_1014_);
lean_dec_ref(v_range_1012_);
lean_dec_ref(v_output_1011_);
lean_dec_ref(v_inputs_1010_);
return v_res_1016_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__4_spec__4_spec__5(size_t v_sz_1017_, size_t v_i_1018_, lean_object* v_bs_1019_){
_start:
{
uint8_t v___x_1020_; 
v___x_1020_ = lean_usize_dec_lt(v_i_1018_, v_sz_1017_);
if (v___x_1020_ == 0)
{
return v_bs_1019_;
}
else
{
lean_object* v_v_1021_; lean_object* v___x_1022_; lean_object* v_bs_x27_1023_; size_t v___x_1024_; size_t v___x_1025_; lean_object* v___x_1026_; 
v_v_1021_ = lean_array_uget(v_bs_1019_, v_i_1018_);
v___x_1022_ = lean_unsigned_to_nat(0u);
v_bs_x27_1023_ = lean_array_uset(v_bs_1019_, v_i_1018_, v___x_1022_);
v___x_1024_ = ((size_t)1ULL);
v___x_1025_ = lean_usize_add(v_i_1018_, v___x_1024_);
v___x_1026_ = lean_array_uset(v_bs_x27_1023_, v_i_1018_, v_v_1021_);
v_i_1018_ = v___x_1025_;
v_bs_1019_ = v___x_1026_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__4_spec__4_spec__5___boxed(lean_object* v_sz_1028_, lean_object* v_i_1029_, lean_object* v_bs_1030_){
_start:
{
size_t v_sz_boxed_1031_; size_t v_i_boxed_1032_; lean_object* v_res_1033_; 
v_sz_boxed_1031_ = lean_unbox_usize(v_sz_1028_);
lean_dec(v_sz_1028_);
v_i_boxed_1032_ = lean_unbox_usize(v_i_1029_);
lean_dec(v_i_1029_);
v_res_1033_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__4_spec__4_spec__5(v_sz_boxed_1031_, v_i_boxed_1032_, v_bs_1030_);
return v_res_1033_;
}
}
LEAN_EXPORT lean_object* l_Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__4_spec__4(lean_object* v_a_1034_){
_start:
{
size_t v_sz_1035_; size_t v___x_1036_; lean_object* v___x_1037_; lean_object* v___x_1038_; 
v_sz_1035_ = lean_array_size(v_a_1034_);
v___x_1036_ = ((size_t)0ULL);
v___x_1037_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__4_spec__4_spec__5(v_sz_1035_, v___x_1036_, v_a_1034_);
v___x_1038_ = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(v___x_1038_, 0, v___x_1037_);
return v___x_1038_;
}
}
LEAN_EXPORT lean_object* l_Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__4(lean_object* v_a_1039_){
_start:
{
lean_object* v___x_1040_; lean_object* v___x_1041_; 
v___x_1040_ = lean_array_mk(v_a_1039_);
v___x_1041_ = l_Lean_Array_toJson___at___00Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__4_spec__4(v___x_1040_);
return v___x_1041_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3(lean_object* v_a_1047_, lean_object* v_a_1048_){
_start:
{
if (lean_obj_tag(v_a_1047_) == 0)
{
lean_object* v___x_1049_; 
v___x_1049_ = l_List_reverse___redArg(v_a_1048_);
return v___x_1049_;
}
else
{
lean_object* v_head_1050_; lean_object* v_snd_1051_; lean_object* v_tail_1052_; lean_object* v___x_1054_; uint8_t v_isShared_1055_; uint8_t v_isSharedCheck_1095_; 
v_head_1050_ = lean_ctor_get(v_a_1047_, 0);
lean_inc(v_head_1050_);
v_snd_1051_ = lean_ctor_get(v_head_1050_, 1);
lean_inc(v_snd_1051_);
v_tail_1052_ = lean_ctor_get(v_a_1047_, 1);
v_isSharedCheck_1095_ = !lean_is_exclusive(v_a_1047_);
if (v_isSharedCheck_1095_ == 0)
{
lean_object* v_unused_1096_; 
v_unused_1096_ = lean_ctor_get(v_a_1047_, 0);
lean_dec(v_unused_1096_);
v___x_1054_ = v_a_1047_;
v_isShared_1055_ = v_isSharedCheck_1095_;
goto v_resetjp_1053_;
}
else
{
lean_inc(v_tail_1052_);
lean_dec(v_a_1047_);
v___x_1054_ = lean_box(0);
v_isShared_1055_ = v_isSharedCheck_1095_;
goto v_resetjp_1053_;
}
v_resetjp_1053_:
{
lean_object* v_fst_1056_; lean_object* v___x_1058_; uint8_t v_isShared_1059_; uint8_t v_isSharedCheck_1093_; 
v_fst_1056_ = lean_ctor_get(v_head_1050_, 0);
v_isSharedCheck_1093_ = !lean_is_exclusive(v_head_1050_);
if (v_isSharedCheck_1093_ == 0)
{
lean_object* v_unused_1094_; 
v_unused_1094_ = lean_ctor_get(v_head_1050_, 1);
lean_dec(v_unused_1094_);
v___x_1058_ = v_head_1050_;
v_isShared_1059_ = v_isSharedCheck_1093_;
goto v_resetjp_1057_;
}
else
{
lean_inc(v_fst_1056_);
lean_dec(v_head_1050_);
v___x_1058_ = lean_box(0);
v_isShared_1059_ = v_isSharedCheck_1093_;
goto v_resetjp_1057_;
}
v_resetjp_1057_:
{
lean_object* v_position_1060_; lean_object* v_lastAltitude_1061_; lean_object* v_airport_1062_; lean_object* v_seenBDS_1063_; lean_object* v___x_1064_; lean_object* v___x_1065_; lean_object* v___x_1066_; lean_object* v___x_1068_; 
v_position_1060_ = lean_ctor_get(v_snd_1051_, 1);
lean_inc(v_position_1060_);
v_lastAltitude_1061_ = lean_ctor_get(v_snd_1051_, 2);
lean_inc(v_lastAltitude_1061_);
v_airport_1062_ = lean_ctor_get(v_snd_1051_, 3);
lean_inc(v_airport_1062_);
v_seenBDS_1063_ = lean_ctor_get(v_snd_1051_, 4);
lean_inc(v_seenBDS_1063_);
lean_dec(v_snd_1051_);
v___x_1064_ = ((lean_object*)(l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__0));
v___x_1065_ = l_Lean_JsonNumber_fromNat(v_fst_1056_);
v___x_1066_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1066_, 0, v___x_1065_);
if (v_isShared_1059_ == 0)
{
lean_ctor_set(v___x_1058_, 1, v___x_1066_);
lean_ctor_set(v___x_1058_, 0, v___x_1064_);
v___x_1068_ = v___x_1058_;
goto v_reusejp_1067_;
}
else
{
lean_object* v_reuseFailAlloc_1092_; 
v_reuseFailAlloc_1092_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1092_, 0, v___x_1064_);
lean_ctor_set(v_reuseFailAlloc_1092_, 1, v___x_1066_);
v___x_1068_ = v_reuseFailAlloc_1092_;
goto v_reusejp_1067_;
}
v_reusejp_1067_:
{
lean_object* v___x_1069_; lean_object* v___x_1070_; lean_object* v___x_1071_; lean_object* v___x_1072_; lean_object* v___x_1073_; lean_object* v___x_1074_; lean_object* v___x_1075_; lean_object* v___x_1076_; lean_object* v___x_1077_; lean_object* v___x_1078_; lean_object* v___x_1079_; lean_object* v___x_1080_; lean_object* v___x_1081_; lean_object* v___x_1083_; 
v___x_1069_ = ((lean_object*)(l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__1));
v___x_1070_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson(v_position_1060_);
v___x_1071_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1071_, 0, v___x_1069_);
lean_ctor_set(v___x_1071_, 1, v___x_1070_);
v___x_1072_ = ((lean_object*)(l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__2));
v___x_1073_ = l_Lean_Option_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__0(v_lastAltitude_1061_);
v___x_1074_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1074_, 0, v___x_1072_);
lean_ctor_set(v___x_1074_, 1, v___x_1073_);
v___x_1075_ = ((lean_object*)(l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__3));
v___x_1076_ = l_Lean_Option_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__1(v_airport_1062_);
v___x_1077_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1077_, 0, v___x_1075_);
lean_ctor_set(v___x_1077_, 1, v___x_1076_);
v___x_1078_ = ((lean_object*)(l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__4));
v___x_1079_ = l_Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson_spec__0(v_seenBDS_1063_);
v___x_1080_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1080_, 0, v___x_1078_);
lean_ctor_set(v___x_1080_, 1, v___x_1079_);
v___x_1081_ = lean_box(0);
if (v_isShared_1055_ == 0)
{
lean_ctor_set(v___x_1054_, 1, v___x_1081_);
lean_ctor_set(v___x_1054_, 0, v___x_1080_);
v___x_1083_ = v___x_1054_;
goto v_reusejp_1082_;
}
else
{
lean_object* v_reuseFailAlloc_1091_; 
v_reuseFailAlloc_1091_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1091_, 0, v___x_1080_);
lean_ctor_set(v_reuseFailAlloc_1091_, 1, v___x_1081_);
v___x_1083_ = v_reuseFailAlloc_1091_;
goto v_reusejp_1082_;
}
v_reusejp_1082_:
{
lean_object* v___x_1084_; lean_object* v___x_1085_; lean_object* v___x_1086_; lean_object* v___x_1087_; lean_object* v___x_1088_; lean_object* v___x_1089_; 
v___x_1084_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1084_, 0, v___x_1077_);
lean_ctor_set(v___x_1084_, 1, v___x_1083_);
v___x_1085_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1085_, 0, v___x_1074_);
lean_ctor_set(v___x_1085_, 1, v___x_1084_);
v___x_1086_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1086_, 0, v___x_1071_);
lean_ctor_set(v___x_1086_, 1, v___x_1085_);
v___x_1087_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1087_, 0, v___x_1068_);
lean_ctor_set(v___x_1087_, 1, v___x_1086_);
v___x_1088_ = l_Lean_Json_mkObj(v___x_1087_);
lean_dec_ref_known(v___x_1087_, 2);
v___x_1089_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1089_, 0, v___x_1088_);
lean_ctor_set(v___x_1089_, 1, v_a_1048_);
v_a_1047_ = v_tail_1052_;
v_a_1048_ = v___x_1089_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg(lean_object* v_output_1102_, lean_object* v_audit_1103_, lean_object* v_inputs_1104_, lean_object* v___x_1105_, lean_object* v___x_1106_, uint8_t v___y_1107_, lean_object* v_range_1108_, lean_object* v_b_1109_, lean_object* v_i_1110_){
_start:
{
lean_object* v_stop_1112_; lean_object* v_step_1113_; lean_object* v_a_1115_; uint8_t v___x_1118_; 
v_stop_1112_ = lean_ctor_get(v_range_1108_, 1);
v_step_1113_ = lean_ctor_get(v_range_1108_, 2);
v___x_1118_ = lean_nat_dec_lt(v_i_1110_, v_stop_1112_);
if (v___x_1118_ == 0)
{
lean_object* v___x_1119_; 
lean_dec(v_i_1110_);
v___x_1119_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1119_, 0, v_b_1109_);
return v___x_1119_;
}
else
{
lean_object* v_snd_1120_; lean_object* v_snd_1121_; lean_object* v_snd_1122_; lean_object* v_snd_1123_; lean_object* v_snd_1124_; lean_object* v_snd_1125_; lean_object* v_fst_1126_; lean_object* v___x_1128_; uint8_t v_isShared_1129_; uint8_t v_isSharedCheck_1281_; 
v_snd_1120_ = lean_ctor_get(v_b_1109_, 1);
lean_inc(v_snd_1120_);
v_snd_1121_ = lean_ctor_get(v_snd_1120_, 1);
lean_inc(v_snd_1121_);
v_snd_1122_ = lean_ctor_get(v_snd_1121_, 1);
lean_inc(v_snd_1122_);
v_snd_1123_ = lean_ctor_get(v_snd_1122_, 1);
lean_inc(v_snd_1123_);
v_snd_1124_ = lean_ctor_get(v_snd_1123_, 1);
lean_inc(v_snd_1124_);
v_snd_1125_ = lean_ctor_get(v_snd_1124_, 1);
lean_inc(v_snd_1125_);
v_fst_1126_ = lean_ctor_get(v_b_1109_, 0);
v_isSharedCheck_1281_ = !lean_is_exclusive(v_b_1109_);
if (v_isSharedCheck_1281_ == 0)
{
lean_object* v_unused_1282_; 
v_unused_1282_ = lean_ctor_get(v_b_1109_, 1);
lean_dec(v_unused_1282_);
v___x_1128_ = v_b_1109_;
v_isShared_1129_ = v_isSharedCheck_1281_;
goto v_resetjp_1127_;
}
else
{
lean_inc(v_fst_1126_);
lean_dec(v_b_1109_);
v___x_1128_ = lean_box(0);
v_isShared_1129_ = v_isSharedCheck_1281_;
goto v_resetjp_1127_;
}
v_resetjp_1127_:
{
lean_object* v_fst_1130_; lean_object* v___x_1132_; uint8_t v_isShared_1133_; uint8_t v_isSharedCheck_1279_; 
v_fst_1130_ = lean_ctor_get(v_snd_1120_, 0);
v_isSharedCheck_1279_ = !lean_is_exclusive(v_snd_1120_);
if (v_isSharedCheck_1279_ == 0)
{
lean_object* v_unused_1280_; 
v_unused_1280_ = lean_ctor_get(v_snd_1120_, 1);
lean_dec(v_unused_1280_);
v___x_1132_ = v_snd_1120_;
v_isShared_1133_ = v_isSharedCheck_1279_;
goto v_resetjp_1131_;
}
else
{
lean_inc(v_fst_1130_);
lean_dec(v_snd_1120_);
v___x_1132_ = lean_box(0);
v_isShared_1133_ = v_isSharedCheck_1279_;
goto v_resetjp_1131_;
}
v_resetjp_1131_:
{
lean_object* v_fst_1134_; lean_object* v___x_1136_; uint8_t v_isShared_1137_; uint8_t v_isSharedCheck_1277_; 
v_fst_1134_ = lean_ctor_get(v_snd_1121_, 0);
v_isSharedCheck_1277_ = !lean_is_exclusive(v_snd_1121_);
if (v_isSharedCheck_1277_ == 0)
{
lean_object* v_unused_1278_; 
v_unused_1278_ = lean_ctor_get(v_snd_1121_, 1);
lean_dec(v_unused_1278_);
v___x_1136_ = v_snd_1121_;
v_isShared_1137_ = v_isSharedCheck_1277_;
goto v_resetjp_1135_;
}
else
{
lean_inc(v_fst_1134_);
lean_dec(v_snd_1121_);
v___x_1136_ = lean_box(0);
v_isShared_1137_ = v_isSharedCheck_1277_;
goto v_resetjp_1135_;
}
v_resetjp_1135_:
{
lean_object* v_fst_1138_; lean_object* v___x_1140_; uint8_t v_isShared_1141_; uint8_t v_isSharedCheck_1275_; 
v_fst_1138_ = lean_ctor_get(v_snd_1122_, 0);
v_isSharedCheck_1275_ = !lean_is_exclusive(v_snd_1122_);
if (v_isSharedCheck_1275_ == 0)
{
lean_object* v_unused_1276_; 
v_unused_1276_ = lean_ctor_get(v_snd_1122_, 1);
lean_dec(v_unused_1276_);
v___x_1140_ = v_snd_1122_;
v_isShared_1141_ = v_isSharedCheck_1275_;
goto v_resetjp_1139_;
}
else
{
lean_inc(v_fst_1138_);
lean_dec(v_snd_1122_);
v___x_1140_ = lean_box(0);
v_isShared_1141_ = v_isSharedCheck_1275_;
goto v_resetjp_1139_;
}
v_resetjp_1139_:
{
lean_object* v_fst_1142_; lean_object* v___x_1144_; uint8_t v_isShared_1145_; uint8_t v_isSharedCheck_1273_; 
v_fst_1142_ = lean_ctor_get(v_snd_1123_, 0);
v_isSharedCheck_1273_ = !lean_is_exclusive(v_snd_1123_);
if (v_isSharedCheck_1273_ == 0)
{
lean_object* v_unused_1274_; 
v_unused_1274_ = lean_ctor_get(v_snd_1123_, 1);
lean_dec(v_unused_1274_);
v___x_1144_ = v_snd_1123_;
v_isShared_1145_ = v_isSharedCheck_1273_;
goto v_resetjp_1143_;
}
else
{
lean_inc(v_fst_1142_);
lean_dec(v_snd_1123_);
v___x_1144_ = lean_box(0);
v_isShared_1145_ = v_isSharedCheck_1273_;
goto v_resetjp_1143_;
}
v_resetjp_1143_:
{
lean_object* v_fst_1146_; lean_object* v___x_1148_; uint8_t v_isShared_1149_; uint8_t v_isSharedCheck_1271_; 
v_fst_1146_ = lean_ctor_get(v_snd_1124_, 0);
v_isSharedCheck_1271_ = !lean_is_exclusive(v_snd_1124_);
if (v_isSharedCheck_1271_ == 0)
{
lean_object* v_unused_1272_; 
v_unused_1272_ = lean_ctor_get(v_snd_1124_, 1);
lean_dec(v_unused_1272_);
v___x_1148_ = v_snd_1124_;
v_isShared_1149_ = v_isSharedCheck_1271_;
goto v_resetjp_1147_;
}
else
{
lean_inc(v_fst_1146_);
lean_dec(v_snd_1124_);
v___x_1148_ = lean_box(0);
v_isShared_1149_ = v_isSharedCheck_1271_;
goto v_resetjp_1147_;
}
v_resetjp_1147_:
{
lean_object* v_fst_1150_; lean_object* v_snd_1151_; lean_object* v___x_1153_; uint8_t v_isShared_1154_; uint8_t v_isSharedCheck_1270_; 
v_fst_1150_ = lean_ctor_get(v_snd_1125_, 0);
v_snd_1151_ = lean_ctor_get(v_snd_1125_, 1);
v_isSharedCheck_1270_ = !lean_is_exclusive(v_snd_1125_);
if (v_isSharedCheck_1270_ == 0)
{
v___x_1153_ = v_snd_1125_;
v_isShared_1154_ = v_isSharedCheck_1270_;
goto v_resetjp_1152_;
}
else
{
lean_inc(v_snd_1151_);
lean_inc(v_fst_1150_);
lean_dec(v_snd_1125_);
v___x_1153_ = lean_box(0);
v_isShared_1154_ = v_isSharedCheck_1270_;
goto v_resetjp_1152_;
}
v_resetjp_1152_:
{
lean_object* v_entry_1155_; lean_object* v_message_1156_; lean_object* v_position_1157_; lean_object* v___x_1159_; uint8_t v_isShared_1160_; uint8_t v_isSharedCheck_1269_; 
v_entry_1155_ = lean_array_fget(v_output_1102_, v_i_1110_);
v_message_1156_ = lean_ctor_get(v_entry_1155_, 0);
v_position_1157_ = lean_ctor_get(v_entry_1155_, 1);
v_isSharedCheck_1269_ = !lean_is_exclusive(v_entry_1155_);
if (v_isSharedCheck_1269_ == 0)
{
v___x_1159_ = v_entry_1155_;
v_isShared_1160_ = v_isSharedCheck_1269_;
goto v_resetjp_1158_;
}
else
{
lean_inc(v_position_1157_);
lean_inc(v_message_1156_);
lean_dec(v_entry_1155_);
v___x_1159_ = lean_box(0);
v_isShared_1160_ = v_isSharedCheck_1269_;
goto v_resetjp_1158_;
}
v_resetjp_1158_:
{
lean_object* v___x_1161_; uint8_t v___x_1162_; lean_object* v___x_1163_; lean_object* v___x_1164_; lean_object* v___x_1165_; lean_object* v___x_1166_; lean_object* v___x_1167_; lean_object* v___x_1168_; lean_object* v_bytes_1169_; uint64_t v___x_1170_; uint64_t v_digest_1171_; lean_object* v___x_1172_; lean_object* v_reprBytes_1173_; uint8_t v___y_1175_; lean_object* v___y_1176_; lean_object* v___y_1177_; lean_object* v_airborne_1178_; lean_object* v_surface_1179_; lean_object* v_other_1180_; lean_object* v___y_1245_; uint8_t v___y_1246_; lean_object* v_routed_1247_; lean_object* v___y_1261_; uint8_t v___y_1262_; lean_object* v_resolved_1265_; 
v___x_1161_ = lean_unsigned_to_nat(1u);
v___x_1162_ = lean_nat_dec_eq(v___x_1105_, v___x_1106_);
v___x_1163_ = lean_unsigned_to_nat(0u);
lean_inc_ref(v_message_1156_);
v___x_1164_ = lp_lean1090_Lean1090_Spec_instReprMessage_repr___redArg(v_message_1156_);
v___x_1165_ = lean_unsigned_to_nat(120u);
v___x_1166_ = l_Std_Format_pretty(v___x_1164_, v___x_1165_, v___x_1163_, v___x_1163_);
v___x_1167_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs___closed__0));
v___x_1168_ = lean_string_append(v___x_1166_, v___x_1167_);
v_bytes_1169_ = lean_string_to_utf8(v___x_1168_);
lean_dec_ref(v___x_1168_);
v___x_1170_ = lean_unbox_uint64(v_fst_1126_);
lean_dec(v_fst_1126_);
lean_inc_ref(v_bytes_1169_);
v_digest_1171_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes(v___x_1170_, v_bytes_1169_);
v___x_1172_ = lean_byte_array_size(v_bytes_1169_);
lean_dec_ref(v_bytes_1169_);
v_reprBytes_1173_ = lean_nat_add(v_fst_1130_, v___x_1172_);
lean_dec(v_fst_1130_);
if (lean_obj_tag(v_position_1157_) == 0)
{
v_resolved_1265_ = v_fst_1134_;
goto v___jp_1264_;
}
else
{
lean_object* v_resolved_1268_; 
v_resolved_1268_ = lean_nat_add(v_fst_1134_, v___x_1161_);
lean_dec(v_fst_1134_);
v_resolved_1265_ = v_resolved_1268_;
goto v___jp_1264_;
}
v___jp_1174_:
{
if (lean_obj_tag(v_audit_1103_) == 0)
{
lean_object* v___x_1182_; 
lean_del_object(v___x_1159_);
lean_dec(v_position_1157_);
if (v_isShared_1154_ == 0)
{
lean_ctor_set(v___x_1153_, 0, v_other_1180_);
v___x_1182_ = v___x_1153_;
goto v_reusejp_1181_;
}
else
{
lean_object* v_reuseFailAlloc_1202_; 
v_reuseFailAlloc_1202_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1202_, 0, v_other_1180_);
lean_ctor_set(v_reuseFailAlloc_1202_, 1, v_snd_1151_);
v___x_1182_ = v_reuseFailAlloc_1202_;
goto v_reusejp_1181_;
}
v_reusejp_1181_:
{
lean_object* v___x_1184_; 
if (v_isShared_1149_ == 0)
{
lean_ctor_set(v___x_1148_, 1, v___x_1182_);
lean_ctor_set(v___x_1148_, 0, v_surface_1179_);
v___x_1184_ = v___x_1148_;
goto v_reusejp_1183_;
}
else
{
lean_object* v_reuseFailAlloc_1201_; 
v_reuseFailAlloc_1201_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1201_, 0, v_surface_1179_);
lean_ctor_set(v_reuseFailAlloc_1201_, 1, v___x_1182_);
v___x_1184_ = v_reuseFailAlloc_1201_;
goto v_reusejp_1183_;
}
v_reusejp_1183_:
{
lean_object* v___x_1186_; 
if (v_isShared_1145_ == 0)
{
lean_ctor_set(v___x_1144_, 1, v___x_1184_);
lean_ctor_set(v___x_1144_, 0, v_airborne_1178_);
v___x_1186_ = v___x_1144_;
goto v_reusejp_1185_;
}
else
{
lean_object* v_reuseFailAlloc_1200_; 
v_reuseFailAlloc_1200_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1200_, 0, v_airborne_1178_);
lean_ctor_set(v_reuseFailAlloc_1200_, 1, v___x_1184_);
v___x_1186_ = v_reuseFailAlloc_1200_;
goto v_reusejp_1185_;
}
v_reusejp_1185_:
{
lean_object* v___x_1188_; 
if (v_isShared_1141_ == 0)
{
lean_ctor_set(v___x_1140_, 1, v___x_1186_);
lean_ctor_set(v___x_1140_, 0, v___y_1177_);
v___x_1188_ = v___x_1140_;
goto v_reusejp_1187_;
}
else
{
lean_object* v_reuseFailAlloc_1199_; 
v_reuseFailAlloc_1199_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1199_, 0, v___y_1177_);
lean_ctor_set(v_reuseFailAlloc_1199_, 1, v___x_1186_);
v___x_1188_ = v_reuseFailAlloc_1199_;
goto v_reusejp_1187_;
}
v_reusejp_1187_:
{
lean_object* v___x_1190_; 
if (v_isShared_1137_ == 0)
{
lean_ctor_set(v___x_1136_, 1, v___x_1188_);
lean_ctor_set(v___x_1136_, 0, v___y_1176_);
v___x_1190_ = v___x_1136_;
goto v_reusejp_1189_;
}
else
{
lean_object* v_reuseFailAlloc_1198_; 
v_reuseFailAlloc_1198_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1198_, 0, v___y_1176_);
lean_ctor_set(v_reuseFailAlloc_1198_, 1, v___x_1188_);
v___x_1190_ = v_reuseFailAlloc_1198_;
goto v_reusejp_1189_;
}
v_reusejp_1189_:
{
lean_object* v___x_1192_; 
if (v_isShared_1133_ == 0)
{
lean_ctor_set(v___x_1132_, 1, v___x_1190_);
lean_ctor_set(v___x_1132_, 0, v_reprBytes_1173_);
v___x_1192_ = v___x_1132_;
goto v_reusejp_1191_;
}
else
{
lean_object* v_reuseFailAlloc_1197_; 
v_reuseFailAlloc_1197_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1197_, 0, v_reprBytes_1173_);
lean_ctor_set(v_reuseFailAlloc_1197_, 1, v___x_1190_);
v___x_1192_ = v_reuseFailAlloc_1197_;
goto v_reusejp_1191_;
}
v_reusejp_1191_:
{
lean_object* v___x_1193_; lean_object* v___x_1195_; 
v___x_1193_ = lean_box_uint64(v_digest_1171_);
if (v_isShared_1129_ == 0)
{
lean_ctor_set(v___x_1128_, 1, v___x_1192_);
lean_ctor_set(v___x_1128_, 0, v___x_1193_);
v___x_1195_ = v___x_1128_;
goto v_reusejp_1194_;
}
else
{
lean_object* v_reuseFailAlloc_1196_; 
v_reuseFailAlloc_1196_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1196_, 0, v___x_1193_);
lean_ctor_set(v_reuseFailAlloc_1196_, 1, v___x_1192_);
v___x_1195_ = v_reuseFailAlloc_1196_;
goto v_reusejp_1194_;
}
v_reusejp_1194_:
{
v_a_1115_ = v___x_1195_;
goto v___jp_1114_;
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_1203_; lean_object* v___x_1204_; lean_object* v___x_1205_; lean_object* v___x_1207_; 
v___x_1203_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__0));
lean_inc(v_i_1110_);
v___x_1204_ = l_Lean_JsonNumber_fromNat(v_i_1110_);
v___x_1205_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1205_, 0, v___x_1204_);
if (v_isShared_1154_ == 0)
{
lean_ctor_set(v___x_1153_, 1, v___x_1205_);
lean_ctor_set(v___x_1153_, 0, v___x_1203_);
v___x_1207_ = v___x_1153_;
goto v_reusejp_1206_;
}
else
{
lean_object* v_reuseFailAlloc_1243_; 
v_reuseFailAlloc_1243_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1243_, 0, v___x_1203_);
lean_ctor_set(v_reuseFailAlloc_1243_, 1, v___x_1205_);
v___x_1207_ = v_reuseFailAlloc_1243_;
goto v_reusejp_1206_;
}
v_reusejp_1206_:
{
lean_object* v___x_1208_; lean_object* v___x_1209_; lean_object* v___x_1211_; 
v___x_1208_ = ((lean_object*)(l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3___closed__1));
v___x_1209_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson(v_position_1157_);
if (v_isShared_1149_ == 0)
{
lean_ctor_set(v___x_1148_, 1, v___x_1209_);
lean_ctor_set(v___x_1148_, 0, v___x_1208_);
v___x_1211_ = v___x_1148_;
goto v_reusejp_1210_;
}
else
{
lean_object* v_reuseFailAlloc_1242_; 
v_reuseFailAlloc_1242_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1242_, 0, v___x_1208_);
lean_ctor_set(v_reuseFailAlloc_1242_, 1, v___x_1209_);
v___x_1211_ = v_reuseFailAlloc_1242_;
goto v_reusejp_1210_;
}
v_reusejp_1210_:
{
lean_object* v___x_1212_; lean_object* v___x_1213_; lean_object* v___x_1215_; 
v___x_1212_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__1));
v___x_1213_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_1213_, 0, v___y_1175_);
if (v_isShared_1145_ == 0)
{
lean_ctor_set(v___x_1144_, 1, v___x_1213_);
lean_ctor_set(v___x_1144_, 0, v___x_1212_);
v___x_1215_ = v___x_1144_;
goto v_reusejp_1214_;
}
else
{
lean_object* v_reuseFailAlloc_1241_; 
v_reuseFailAlloc_1241_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1241_, 0, v___x_1212_);
lean_ctor_set(v_reuseFailAlloc_1241_, 1, v___x_1213_);
v___x_1215_ = v_reuseFailAlloc_1241_;
goto v_reusejp_1214_;
}
v_reusejp_1214_:
{
lean_object* v___x_1216_; lean_object* v___x_1218_; 
v___x_1216_ = lean_box(0);
if (v_isShared_1160_ == 0)
{
lean_ctor_set_tag(v___x_1159_, 1);
lean_ctor_set(v___x_1159_, 1, v___x_1216_);
lean_ctor_set(v___x_1159_, 0, v___x_1215_);
v___x_1218_ = v___x_1159_;
goto v_reusejp_1217_;
}
else
{
lean_object* v_reuseFailAlloc_1240_; 
v_reuseFailAlloc_1240_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1240_, 0, v___x_1215_);
lean_ctor_set(v_reuseFailAlloc_1240_, 1, v___x_1216_);
v___x_1218_ = v_reuseFailAlloc_1240_;
goto v_reusejp_1217_;
}
v_reusejp_1217_:
{
lean_object* v___x_1219_; lean_object* v___x_1220_; lean_object* v___x_1221_; lean_object* v___x_1222_; lean_object* v_lines_1223_; lean_object* v___x_1225_; 
v___x_1219_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1219_, 0, v___x_1211_);
lean_ctor_set(v___x_1219_, 1, v___x_1218_);
v___x_1220_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1220_, 0, v___x_1207_);
lean_ctor_set(v___x_1220_, 1, v___x_1219_);
v___x_1221_ = l_Lean_Json_mkObj(v___x_1220_);
lean_dec_ref_known(v___x_1220_, 2);
v___x_1222_ = l_Lean_Json_compress(v___x_1221_);
v_lines_1223_ = lean_array_push(v_snd_1151_, v___x_1222_);
if (v_isShared_1141_ == 0)
{
lean_ctor_set(v___x_1140_, 1, v_lines_1223_);
lean_ctor_set(v___x_1140_, 0, v_other_1180_);
v___x_1225_ = v___x_1140_;
goto v_reusejp_1224_;
}
else
{
lean_object* v_reuseFailAlloc_1239_; 
v_reuseFailAlloc_1239_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1239_, 0, v_other_1180_);
lean_ctor_set(v_reuseFailAlloc_1239_, 1, v_lines_1223_);
v___x_1225_ = v_reuseFailAlloc_1239_;
goto v_reusejp_1224_;
}
v_reusejp_1224_:
{
lean_object* v___x_1227_; 
if (v_isShared_1137_ == 0)
{
lean_ctor_set(v___x_1136_, 1, v___x_1225_);
lean_ctor_set(v___x_1136_, 0, v_surface_1179_);
v___x_1227_ = v___x_1136_;
goto v_reusejp_1226_;
}
else
{
lean_object* v_reuseFailAlloc_1238_; 
v_reuseFailAlloc_1238_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1238_, 0, v_surface_1179_);
lean_ctor_set(v_reuseFailAlloc_1238_, 1, v___x_1225_);
v___x_1227_ = v_reuseFailAlloc_1238_;
goto v_reusejp_1226_;
}
v_reusejp_1226_:
{
lean_object* v___x_1229_; 
if (v_isShared_1133_ == 0)
{
lean_ctor_set(v___x_1132_, 1, v___x_1227_);
lean_ctor_set(v___x_1132_, 0, v_airborne_1178_);
v___x_1229_ = v___x_1132_;
goto v_reusejp_1228_;
}
else
{
lean_object* v_reuseFailAlloc_1237_; 
v_reuseFailAlloc_1237_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1237_, 0, v_airborne_1178_);
lean_ctor_set(v_reuseFailAlloc_1237_, 1, v___x_1227_);
v___x_1229_ = v_reuseFailAlloc_1237_;
goto v_reusejp_1228_;
}
v_reusejp_1228_:
{
lean_object* v___x_1231_; 
if (v_isShared_1129_ == 0)
{
lean_ctor_set(v___x_1128_, 1, v___x_1229_);
lean_ctor_set(v___x_1128_, 0, v___y_1177_);
v___x_1231_ = v___x_1128_;
goto v_reusejp_1230_;
}
else
{
lean_object* v_reuseFailAlloc_1236_; 
v_reuseFailAlloc_1236_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1236_, 0, v___y_1177_);
lean_ctor_set(v_reuseFailAlloc_1236_, 1, v___x_1229_);
v___x_1231_ = v_reuseFailAlloc_1236_;
goto v_reusejp_1230_;
}
v_reusejp_1230_:
{
lean_object* v___x_1232_; lean_object* v___x_1233_; lean_object* v___x_1234_; lean_object* v___x_1235_; 
v___x_1232_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1232_, 0, v___y_1176_);
lean_ctor_set(v___x_1232_, 1, v___x_1231_);
v___x_1233_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1233_, 0, v_reprBytes_1173_);
lean_ctor_set(v___x_1233_, 1, v___x_1232_);
v___x_1234_ = lean_box_uint64(v_digest_1171_);
v___x_1235_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1235_, 0, v___x_1234_);
lean_ctor_set(v___x_1235_, 1, v___x_1233_);
v_a_1115_ = v___x_1235_;
goto v___jp_1114_;
}
}
}
}
}
}
}
}
}
}
v___jp_1244_:
{
lean_object* v___x_1248_; uint8_t v___x_1249_; 
v___x_1248_ = lean_array_get_size(v_inputs_1104_);
v___x_1249_ = lean_nat_dec_lt(v_i_1110_, v___x_1248_);
if (v___x_1249_ == 0)
{
lean_object* v___x_1250_; lean_object* v___x_1251_; 
lean_dec(v_routed_1247_);
lean_dec(v___y_1245_);
lean_dec(v_reprBytes_1173_);
lean_del_object(v___x_1159_);
lean_dec(v_position_1157_);
lean_dec_ref(v_message_1156_);
lean_del_object(v___x_1153_);
lean_dec(v_snd_1151_);
lean_dec(v_fst_1150_);
lean_del_object(v___x_1148_);
lean_dec(v_fst_1146_);
lean_del_object(v___x_1144_);
lean_dec(v_fst_1142_);
lean_del_object(v___x_1140_);
lean_del_object(v___x_1136_);
lean_del_object(v___x_1132_);
lean_del_object(v___x_1128_);
lean_dec(v_i_1110_);
v___x_1250_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__3));
v___x_1251_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1251_, 0, v___x_1250_);
return v___x_1251_;
}
else
{
lean_object* v___x_1252_; lean_object* v_timestamp_1253_; lean_object* v___x_1254_; 
v___x_1252_ = lean_array_fget_borrowed(v_inputs_1104_, v_i_1110_);
v_timestamp_1253_ = lean_ctor_get(v___x_1252_, 0);
lean_inc_ref(v_timestamp_1253_);
v___x_1254_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_trackingReport(v_timestamp_1253_, v_message_1156_);
if (lean_obj_tag(v___x_1254_) == 1)
{
lean_object* v_val_1255_; lean_object* v_message_1256_; 
v_val_1255_ = lean_ctor_get(v___x_1254_, 0);
lean_inc(v_val_1255_);
lean_dec_ref_known(v___x_1254_, 1);
v_message_1256_ = lean_ctor_get(v_val_1255_, 2);
lean_inc_ref(v_message_1256_);
lean_dec(v_val_1255_);
switch(lean_obj_tag(v_message_1256_))
{
case 0:
{
lean_object* v_airborne_1257_; 
lean_dec_ref_known(v_message_1256_, 3);
v_airborne_1257_ = lean_nat_add(v_fst_1142_, v___x_1161_);
lean_dec(v_fst_1142_);
v___y_1175_ = v___y_1246_;
v___y_1176_ = v___y_1245_;
v___y_1177_ = v_routed_1247_;
v_airborne_1178_ = v_airborne_1257_;
v_surface_1179_ = v_fst_1146_;
v_other_1180_ = v_fst_1150_;
goto v___jp_1174_;
}
case 1:
{
lean_object* v_surface_1258_; 
lean_dec_ref_known(v_message_1256_, 1);
v_surface_1258_ = lean_nat_add(v_fst_1146_, v___x_1161_);
lean_dec(v_fst_1146_);
v___y_1175_ = v___y_1246_;
v___y_1176_ = v___y_1245_;
v___y_1177_ = v_routed_1247_;
v_airborne_1178_ = v_fst_1142_;
v_surface_1179_ = v_surface_1258_;
v_other_1180_ = v_fst_1150_;
goto v___jp_1174_;
}
default: 
{
lean_object* v_other_1259_; 
lean_dec_ref_known(v_message_1256_, 0);
v_other_1259_ = lean_nat_add(v_fst_1150_, v___x_1161_);
lean_dec(v_fst_1150_);
v___y_1175_ = v___y_1246_;
v___y_1176_ = v___y_1245_;
v___y_1177_ = v_routed_1247_;
v_airborne_1178_ = v_fst_1142_;
v_surface_1179_ = v_fst_1146_;
v_other_1180_ = v_other_1259_;
goto v___jp_1174_;
}
}
}
else
{
lean_dec(v___x_1254_);
v___y_1175_ = v___y_1246_;
v___y_1176_ = v___y_1245_;
v___y_1177_ = v_routed_1247_;
v_airborne_1178_ = v_fst_1142_;
v_surface_1179_ = v_fst_1146_;
v_other_1180_ = v_fst_1150_;
goto v___jp_1174_;
}
}
}
v___jp_1260_:
{
if (v___y_1262_ == 0)
{
v___y_1245_ = v___y_1261_;
v___y_1246_ = v___y_1262_;
v_routed_1247_ = v_fst_1138_;
goto v___jp_1244_;
}
else
{
lean_object* v_routed_1263_; 
v_routed_1263_ = lean_nat_add(v_fst_1138_, v___x_1161_);
lean_dec(v_fst_1138_);
v___y_1245_ = v___y_1261_;
v___y_1246_ = v___y_1262_;
v_routed_1247_ = v_routed_1263_;
goto v___jp_1244_;
}
}
v___jp_1264_:
{
lean_object* v_fields_1266_; lean_object* v_body_1267_; 
v_fields_1266_ = lean_ctor_get(v_message_1156_, 0);
v_body_1267_ = lean_ctor_get(v_fields_1266_, 0);
if (lean_obj_tag(v_body_1267_) == 4)
{
v___y_1261_ = v_resolved_1265_;
v___y_1262_ = v___x_1162_;
goto v___jp_1260_;
}
else
{
v___y_1261_ = v_resolved_1265_;
v___y_1262_ = v___y_1107_;
goto v___jp_1260_;
}
}
}
}
}
}
}
}
}
}
}
v___jp_1114_:
{
lean_object* v___x_1116_; 
v___x_1116_ = lean_nat_add(v_i_1110_, v_step_1113_);
lean_dec(v_i_1110_);
v_b_1109_ = v_a_1115_;
v_i_1110_ = v___x_1116_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___boxed(lean_object* v_output_1283_, lean_object* v_audit_1284_, lean_object* v_inputs_1285_, lean_object* v___x_1286_, lean_object* v___x_1287_, lean_object* v___y_1288_, lean_object* v_range_1289_, lean_object* v_b_1290_, lean_object* v_i_1291_, lean_object* v___y_1292_){
_start:
{
uint8_t v___y_4696__boxed_1293_; lean_object* v_res_1294_; 
v___y_4696__boxed_1293_ = lean_unbox(v___y_1288_);
v_res_1294_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg(v_output_1283_, v_audit_1284_, v_inputs_1285_, v___x_1286_, v___x_1287_, v___y_4696__boxed_1293_, v_range_1289_, v_b_1290_, v_i_1291_);
lean_dec_ref(v_range_1289_);
lean_dec(v___x_1287_);
lean_dec(v___x_1286_);
lean_dec_ref(v_inputs_1285_);
lean_dec(v_audit_1284_);
lean_dec_ref(v_output_1283_);
return v_res_1294_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume(lean_object* v_inputs_1362_, lean_object* v_output_1363_, lean_object* v_state_1364_, lean_object* v_geo_1365_, lean_object* v_audit_1366_){
_start:
{
lean_object* v___y_1369_; lean_object* v___y_1370_; lean_object* v___y_1371_; lean_object* v___y_1372_; lean_object* v___y_1373_; lean_object* v___y_1374_; lean_object* v___y_1375_; lean_object* v___y_1376_; lean_object* v___y_1377_; lean_object* v___y_1378_; lean_object* v___y_1379_; lean_object* v___y_1380_; lean_object* v___y_1381_; uint8_t v___y_1382_; lean_object* v___y_1400_; lean_object* v___y_1401_; lean_object* v___y_1402_; lean_object* v___y_1403_; lean_object* v___y_1404_; uint8_t v___y_1405_; uint64_t v___y_1406_; lean_object* v___y_1407_; lean_object* v___y_1408_; uint8_t v___y_1409_; lean_object* v___y_1410_; lean_object* v___y_1411_; lean_object* v___y_1412_; lean_object* v___y_1413_; lean_object* v___x_1476_; lean_object* v___x_1477_; uint8_t v___x_1478_; 
v___x_1476_ = lean_array_get_size(v_output_1363_);
v___x_1477_ = lean_unsigned_to_nat(172432u);
v___x_1478_ = lean_nat_dec_eq(v___x_1476_, v___x_1477_);
if (v___x_1478_ == 0)
{
lean_dec_ref(v_geo_1365_);
lean_dec_ref(v_state_1364_);
goto v___jp_1473_;
}
else
{
lean_object* v___x_1479_; uint8_t v___x_1480_; 
v___x_1479_ = lean_array_get_size(v_inputs_1362_);
v___x_1480_ = lean_nat_dec_eq(v___x_1479_, v___x_1476_);
if (v___x_1480_ == 0)
{
lean_dec_ref(v_geo_1365_);
lean_dec_ref(v_state_1364_);
goto v___jp_1473_;
}
else
{
lean_object* v___f_1481_; lean_object* v___f_1482_; lean_object* v___y_1484_; lean_object* v___y_1485_; lean_object* v___y_1486_; lean_object* v___y_1487_; uint8_t v___y_1488_; uint64_t v___y_1489_; lean_object* v___y_1490_; lean_object* v___y_1491_; uint8_t v___y_1492_; lean_object* v___y_1493_; lean_object* v___y_1494_; lean_object* v___y_1495_; lean_object* v___y_1496_; uint8_t v___x_1541_; lean_object* v___f_1542_; uint64_t v_digest_1543_; lean_object* v_reprBytes_1544_; lean_object* v___x_1545_; lean_object* v___x_1546_; lean_object* v___x_1547_; lean_object* v___x_1548_; 
v___f_1481_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__24));
v___f_1482_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__25));
v___x_1541_ = 0;
v___f_1542_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__29));
v_digest_1543_ = 14695981039346656037ULL;
v_reprBytes_1544_ = lean_unsigned_to_nat(0u);
v___x_1545_ = lean_unsigned_to_nat(1u);
v___x_1546_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1546_, 0, v_reprBytes_1544_);
lean_ctor_set(v___x_1546_, 1, v___x_1476_);
lean_ctor_set(v___x_1546_, 2, v___x_1545_);
v___x_1547_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__37));
v___x_1548_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg(v_output_1363_, v_audit_1366_, v_inputs_1362_, v___x_1479_, v___x_1476_, v___x_1541_, v___x_1546_, v___x_1547_, v_reprBytes_1544_);
if (lean_obj_tag(v___x_1548_) == 0)
{
lean_object* v_a_1549_; lean_object* v_snd_1550_; lean_object* v_snd_1551_; lean_object* v_snd_1552_; lean_object* v_snd_1553_; lean_object* v_snd_1554_; lean_object* v_snd_1555_; 
v_a_1549_ = lean_ctor_get(v___x_1548_, 0);
lean_inc(v_a_1549_);
lean_dec_ref_known(v___x_1548_, 1);
v_snd_1550_ = lean_ctor_get(v_a_1549_, 1);
lean_inc(v_snd_1550_);
v_snd_1551_ = lean_ctor_get(v_snd_1550_, 1);
lean_inc(v_snd_1551_);
v_snd_1552_ = lean_ctor_get(v_snd_1551_, 1);
lean_inc(v_snd_1552_);
v_snd_1553_ = lean_ctor_get(v_snd_1552_, 1);
lean_inc(v_snd_1553_);
v_snd_1554_ = lean_ctor_get(v_snd_1553_, 1);
lean_inc(v_snd_1554_);
v_snd_1555_ = lean_ctor_get(v_snd_1554_, 1);
lean_inc(v_snd_1555_);
if (lean_obj_tag(v_audit_1366_) == 0)
{
lean_object* v_fst_1556_; lean_object* v_fst_1557_; lean_object* v_fst_1558_; lean_object* v_fst_1559_; lean_object* v_fst_1560_; lean_object* v_fst_1561_; lean_object* v_fst_1562_; lean_object* v_snd_1563_; 
lean_dec_ref_known(v___x_1546_, 3);
lean_dec_ref(v_geo_1365_);
v_fst_1556_ = lean_ctor_get(v_a_1549_, 0);
lean_inc(v_fst_1556_);
lean_dec(v_a_1549_);
v_fst_1557_ = lean_ctor_get(v_snd_1550_, 0);
lean_inc(v_fst_1557_);
lean_dec(v_snd_1550_);
v_fst_1558_ = lean_ctor_get(v_snd_1551_, 0);
lean_inc(v_fst_1558_);
lean_dec(v_snd_1551_);
v_fst_1559_ = lean_ctor_get(v_snd_1552_, 0);
lean_inc(v_fst_1559_);
lean_dec(v_snd_1552_);
v_fst_1560_ = lean_ctor_get(v_snd_1553_, 0);
lean_inc(v_fst_1560_);
lean_dec(v_snd_1553_);
v_fst_1561_ = lean_ctor_get(v_snd_1554_, 0);
lean_inc(v_fst_1561_);
lean_dec(v_snd_1554_);
v_fst_1562_ = lean_ctor_get(v_snd_1555_, 0);
lean_inc(v_fst_1562_);
v_snd_1563_ = lean_ctor_get(v_snd_1555_, 1);
lean_inc(v_snd_1563_);
lean_dec(v_snd_1555_);
v___y_1484_ = v_fst_1557_;
v___y_1485_ = v_fst_1559_;
v___y_1486_ = v_fst_1561_;
v___y_1487_ = v_snd_1563_;
v___y_1488_ = v___x_1480_;
v___y_1489_ = v_digest_1543_;
v___y_1490_ = v_fst_1560_;
v___y_1491_ = v_fst_1558_;
v___y_1492_ = v___x_1541_;
v___y_1493_ = v_fst_1556_;
v___y_1494_ = v_reprBytes_1544_;
v___y_1495_ = v___x_1476_;
v___y_1496_ = v_fst_1562_;
goto v___jp_1483_;
}
else
{
lean_object* v_fst_1564_; lean_object* v_fst_1565_; lean_object* v_fst_1566_; lean_object* v_fst_1567_; lean_object* v_fst_1568_; lean_object* v_fst_1569_; lean_object* v_fst_1570_; lean_object* v_snd_1571_; lean_object* v___x_1572_; lean_object* v___x_1573_; 
v_fst_1564_ = lean_ctor_get(v_a_1549_, 0);
lean_inc(v_fst_1564_);
lean_dec(v_a_1549_);
v_fst_1565_ = lean_ctor_get(v_snd_1550_, 0);
lean_inc(v_fst_1565_);
lean_dec(v_snd_1550_);
v_fst_1566_ = lean_ctor_get(v_snd_1551_, 0);
lean_inc(v_fst_1566_);
lean_dec(v_snd_1551_);
v_fst_1567_ = lean_ctor_get(v_snd_1552_, 0);
lean_inc(v_fst_1567_);
lean_dec(v_snd_1552_);
v_fst_1568_ = lean_ctor_get(v_snd_1553_, 0);
lean_inc(v_fst_1568_);
lean_dec(v_snd_1553_);
v_fst_1569_ = lean_ctor_get(v_snd_1554_, 0);
lean_inc(v_fst_1569_);
lean_dec(v_snd_1554_);
v_fst_1570_ = lean_ctor_get(v_snd_1555_, 0);
lean_inc(v_fst_1570_);
v_snd_1571_ = lean_ctor_get(v_snd_1555_, 1);
lean_inc(v_snd_1571_);
lean_dec(v_snd_1555_);
v___x_1572_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__38));
v___x_1573_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg(v_inputs_1362_, v_output_1363_, v___x_1546_, v___x_1572_, v_reprBytes_1544_);
lean_dec_ref_known(v___x_1546_, 3);
if (lean_obj_tag(v___x_1573_) == 0)
{
lean_object* v_a_1574_; lean_object* v_fst_1575_; lean_object* v_snd_1576_; lean_object* v___x_1577_; lean_object* v___x_1578_; lean_object* v___x_1579_; lean_object* v_fst_1580_; lean_object* v_snd_1581_; uint8_t v___x_1582_; 
v_a_1574_ = lean_ctor_get(v___x_1573_, 0);
lean_inc(v_a_1574_);
lean_dec_ref_known(v___x_1573_, 1);
v_fst_1575_ = lean_ctor_get(v_a_1574_, 0);
lean_inc(v_fst_1575_);
v_snd_1576_ = lean_ctor_get(v_a_1574_, 1);
lean_inc(v_snd_1576_);
lean_dec(v_a_1574_);
v___x_1577_ = lean_box(0);
v___x_1578_ = l_List_reverse___redArg(v_fst_1575_);
v___x_1579_ = lp_lean1090_Lean1090_Impl_CPR_Policy_decodePositions(v_geo_1365_, v___f_1542_, v___x_1577_, v___x_1578_);
v_fst_1580_ = lean_ctor_get(v___x_1579_, 0);
lean_inc(v_fst_1580_);
v_snd_1581_ = lean_ctor_get(v___x_1579_, 1);
lean_inc(v_snd_1581_);
lean_dec_ref(v___x_1579_);
lean_inc_ref(v_state_1364_);
v___x_1582_ = lp_lean1090_Lean1090_Spec_CPR_Policy_instDecidableEqStreamState_decEq(v_fst_1580_, v_state_1364_);
if (v___x_1582_ == 0)
{
lean_dec(v_snd_1581_);
lean_dec(v_snd_1576_);
lean_dec(v_snd_1571_);
lean_dec(v_fst_1570_);
lean_dec(v_fst_1569_);
lean_dec(v_fst_1568_);
lean_dec(v_fst_1567_);
lean_dec(v_fst_1566_);
lean_dec(v_fst_1565_);
lean_dec(v_fst_1564_);
lean_dec_ref(v_state_1364_);
goto v___jp_1470_;
}
else
{
lean_object* v___x_1583_; uint8_t v___x_1584_; 
v___x_1583_ = l_List_reverse___redArg(v_snd_1576_);
v___x_1584_ = l_instDecidableEqList___redArg(v___f_1481_, v_snd_1581_, v___x_1583_);
if (v___x_1584_ == 0)
{
lean_dec(v_snd_1571_);
lean_dec(v_fst_1570_);
lean_dec(v_fst_1569_);
lean_dec(v_fst_1568_);
lean_dec(v_fst_1567_);
lean_dec(v_fst_1566_);
lean_dec(v_fst_1565_);
lean_dec(v_fst_1564_);
lean_dec_ref(v_state_1364_);
goto v___jp_1470_;
}
else
{
v___y_1484_ = v_fst_1565_;
v___y_1485_ = v_fst_1567_;
v___y_1486_ = v_fst_1569_;
v___y_1487_ = v_snd_1571_;
v___y_1488_ = v___x_1480_;
v___y_1489_ = v_digest_1543_;
v___y_1490_ = v_fst_1568_;
v___y_1491_ = v_fst_1566_;
v___y_1492_ = v___x_1541_;
v___y_1493_ = v_fst_1564_;
v___y_1494_ = v_reprBytes_1544_;
v___y_1495_ = v___x_1476_;
v___y_1496_ = v_fst_1570_;
goto v___jp_1483_;
}
}
}
else
{
lean_object* v_a_1585_; lean_object* v___x_1587_; uint8_t v_isShared_1588_; uint8_t v_isSharedCheck_1592_; 
lean_dec(v_snd_1571_);
lean_dec(v_fst_1570_);
lean_dec(v_fst_1569_);
lean_dec(v_fst_1568_);
lean_dec(v_fst_1567_);
lean_dec(v_fst_1566_);
lean_dec(v_fst_1565_);
lean_dec(v_fst_1564_);
lean_dec_ref(v_geo_1365_);
lean_dec_ref(v_state_1364_);
v_a_1585_ = lean_ctor_get(v___x_1573_, 0);
v_isSharedCheck_1592_ = !lean_is_exclusive(v___x_1573_);
if (v_isSharedCheck_1592_ == 0)
{
v___x_1587_ = v___x_1573_;
v_isShared_1588_ = v_isSharedCheck_1592_;
goto v_resetjp_1586_;
}
else
{
lean_inc(v_a_1585_);
lean_dec(v___x_1573_);
v___x_1587_ = lean_box(0);
v_isShared_1588_ = v_isSharedCheck_1592_;
goto v_resetjp_1586_;
}
v_resetjp_1586_:
{
lean_object* v___x_1590_; 
if (v_isShared_1588_ == 0)
{
v___x_1590_ = v___x_1587_;
goto v_reusejp_1589_;
}
else
{
lean_object* v_reuseFailAlloc_1591_; 
v_reuseFailAlloc_1591_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1591_, 0, v_a_1585_);
v___x_1590_ = v_reuseFailAlloc_1591_;
goto v_reusejp_1589_;
}
v_reusejp_1589_:
{
return v___x_1590_;
}
}
}
}
}
else
{
lean_object* v_a_1593_; lean_object* v___x_1595_; uint8_t v_isShared_1596_; uint8_t v_isSharedCheck_1600_; 
lean_dec_ref_known(v___x_1546_, 3);
lean_dec_ref(v_geo_1365_);
lean_dec_ref(v_state_1364_);
v_a_1593_ = lean_ctor_get(v___x_1548_, 0);
v_isSharedCheck_1600_ = !lean_is_exclusive(v___x_1548_);
if (v_isSharedCheck_1600_ == 0)
{
v___x_1595_ = v___x_1548_;
v_isShared_1596_ = v_isSharedCheck_1600_;
goto v_resetjp_1594_;
}
else
{
lean_inc(v_a_1593_);
lean_dec(v___x_1548_);
v___x_1595_ = lean_box(0);
v_isShared_1596_ = v_isSharedCheck_1600_;
goto v_resetjp_1594_;
}
v_resetjp_1594_:
{
lean_object* v___x_1598_; 
if (v_isShared_1596_ == 0)
{
v___x_1598_ = v___x_1595_;
goto v_reusejp_1597_;
}
else
{
lean_object* v_reuseFailAlloc_1599_; 
v_reuseFailAlloc_1599_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1599_, 0, v_a_1593_);
v___x_1598_ = v_reuseFailAlloc_1599_;
goto v_reusejp_1597_;
}
v_reusejp_1597_:
{
return v___x_1598_;
}
}
}
v___jp_1483_:
{
lean_object* v___x_1497_; lean_object* v___x_1498_; lean_object* v___x_1499_; lean_object* v_aircraft_1500_; lean_object* v_reference_1501_; lean_object* v___x_1503_; uint8_t v_isShared_1504_; uint8_t v_isSharedCheck_1540_; 
lean_inc_ref(v_state_1364_);
v___x_1497_ = lp_lean1090_Lean1090_Spec_CPR_Policy_instReprStreamState_repr___redArg(v_state_1364_);
v___x_1498_ = lean_unsigned_to_nat(120u);
lean_inc(v___y_1494_);
v___x_1499_ = l_Std_Format_pretty(v___x_1497_, v___x_1498_, v___y_1494_, v___y_1494_);
v_aircraft_1500_ = lean_ctor_get(v_state_1364_, 0);
v_reference_1501_ = lean_ctor_get(v_state_1364_, 1);
v_isSharedCheck_1540_ = !lean_is_exclusive(v_state_1364_);
if (v_isSharedCheck_1540_ == 0)
{
v___x_1503_ = v_state_1364_;
v_isShared_1504_ = v_isSharedCheck_1540_;
goto v_resetjp_1502_;
}
else
{
lean_inc(v_reference_1501_);
lean_inc(v_aircraft_1500_);
lean_dec(v_state_1364_);
v___x_1503_ = lean_box(0);
v_isShared_1504_ = v_isSharedCheck_1540_;
goto v_resetjp_1502_;
}
v_resetjp_1502_:
{
lean_object* v___x_1505_; lean_object* v___x_1506_; lean_object* v___x_1507_; lean_object* v___x_1508_; lean_object* v___x_1510_; 
v___x_1505_ = lean_string_to_utf8(v___x_1499_);
lean_dec_ref(v___x_1499_);
v___x_1506_ = l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(v_aircraft_1500_, v___f_1482_);
v___x_1507_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__26));
v___x_1508_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_1508_, 0, v___y_1488_);
if (v_isShared_1504_ == 0)
{
lean_ctor_set(v___x_1503_, 1, v___x_1508_);
lean_ctor_set(v___x_1503_, 0, v___x_1507_);
v___x_1510_ = v___x_1503_;
goto v_reusejp_1509_;
}
else
{
lean_object* v_reuseFailAlloc_1539_; 
v_reuseFailAlloc_1539_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1539_, 0, v___x_1507_);
lean_ctor_set(v_reuseFailAlloc_1539_, 1, v___x_1508_);
v___x_1510_ = v_reuseFailAlloc_1539_;
goto v_reusejp_1509_;
}
v_reusejp_1509_:
{
lean_object* v___x_1511_; lean_object* v___x_1512_; lean_object* v___x_1513_; lean_object* v___x_1514_; lean_object* v___x_1515_; lean_object* v___x_1516_; lean_object* v___x_1517_; lean_object* v___x_1518_; lean_object* v___x_1519_; lean_object* v___x_1520_; lean_object* v___x_1521_; lean_object* v___x_1522_; 
v___x_1511_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__27));
v___x_1512_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_positionJson(v_reference_1501_);
v___x_1513_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1513_, 0, v___x_1511_);
lean_ctor_set(v___x_1513_, 1, v___x_1512_);
v___x_1514_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__28));
v___x_1515_ = lean_box(0);
v___x_1516_ = l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__3(v___x_1506_, v___x_1515_);
v___x_1517_ = l_Lean_List_toJson___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__4(v___x_1516_);
v___x_1518_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1518_, 0, v___x_1514_);
lean_ctor_set(v___x_1518_, 1, v___x_1517_);
v___x_1519_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1519_, 0, v___x_1518_);
lean_ctor_set(v___x_1519_, 1, v___x_1515_);
v___x_1520_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1520_, 0, v___x_1513_);
lean_ctor_set(v___x_1520_, 1, v___x_1519_);
v___x_1521_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1521_, 0, v___x_1510_);
lean_ctor_set(v___x_1521_, 1, v___x_1520_);
v___x_1522_ = l_Lean_Json_mkObj(v___x_1521_);
lean_dec_ref_known(v___x_1521_, 2);
if (lean_obj_tag(v_audit_1366_) == 1)
{
lean_object* v_val_1523_; lean_object* v___x_1524_; lean_object* v___x_1525_; lean_object* v___x_1526_; lean_object* v___x_1527_; lean_object* v___x_1528_; lean_object* v___x_1529_; lean_object* v___x_1530_; 
v_val_1523_ = lean_ctor_get(v_audit_1366_, 0);
lean_inc(v___x_1522_);
v___x_1524_ = l_Lean_Json_compress(v___x_1522_);
v___x_1525_ = lean_array_push(v___y_1487_, v___x_1524_);
v___x_1526_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs___closed__0));
v___x_1527_ = lean_array_to_list(v___x_1525_);
v___x_1528_ = l_String_intercalate(v___x_1526_, v___x_1527_);
v___x_1529_ = lean_string_append(v___x_1528_, v___x_1526_);
v___x_1530_ = l_IO_FS_writeFile(v_val_1523_, v___x_1529_);
lean_dec_ref(v___x_1529_);
if (lean_obj_tag(v___x_1530_) == 0)
{
lean_dec_ref_known(v___x_1530_, 1);
v___y_1400_ = v___x_1505_;
v___y_1401_ = v___y_1484_;
v___y_1402_ = v___y_1485_;
v___y_1403_ = v___y_1486_;
v___y_1404_ = v___x_1522_;
v___y_1405_ = v___y_1488_;
v___y_1406_ = v___y_1489_;
v___y_1407_ = v___y_1490_;
v___y_1408_ = v___y_1491_;
v___y_1409_ = v___y_1492_;
v___y_1410_ = v___y_1493_;
v___y_1411_ = v___x_1515_;
v___y_1412_ = v___y_1495_;
v___y_1413_ = v___y_1496_;
goto v___jp_1399_;
}
else
{
lean_object* v_a_1531_; lean_object* v___x_1533_; uint8_t v_isShared_1534_; uint8_t v_isSharedCheck_1538_; 
lean_dec(v___x_1522_);
lean_dec_ref(v___x_1505_);
lean_dec(v___y_1496_);
lean_dec(v___y_1495_);
lean_dec(v___y_1493_);
lean_dec(v___y_1491_);
lean_dec(v___y_1490_);
lean_dec(v___y_1486_);
lean_dec(v___y_1485_);
lean_dec(v___y_1484_);
v_a_1531_ = lean_ctor_get(v___x_1530_, 0);
v_isSharedCheck_1538_ = !lean_is_exclusive(v___x_1530_);
if (v_isSharedCheck_1538_ == 0)
{
v___x_1533_ = v___x_1530_;
v_isShared_1534_ = v_isSharedCheck_1538_;
goto v_resetjp_1532_;
}
else
{
lean_inc(v_a_1531_);
lean_dec(v___x_1530_);
v___x_1533_ = lean_box(0);
v_isShared_1534_ = v_isSharedCheck_1538_;
goto v_resetjp_1532_;
}
v_resetjp_1532_:
{
lean_object* v___x_1536_; 
if (v_isShared_1534_ == 0)
{
v___x_1536_ = v___x_1533_;
goto v_reusejp_1535_;
}
else
{
lean_object* v_reuseFailAlloc_1537_; 
v_reuseFailAlloc_1537_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1537_, 0, v_a_1531_);
v___x_1536_ = v_reuseFailAlloc_1537_;
goto v_reusejp_1535_;
}
v_reusejp_1535_:
{
return v___x_1536_;
}
}
}
}
else
{
lean_dec(v___y_1487_);
v___y_1400_ = v___x_1505_;
v___y_1401_ = v___y_1484_;
v___y_1402_ = v___y_1485_;
v___y_1403_ = v___y_1486_;
v___y_1404_ = v___x_1522_;
v___y_1405_ = v___y_1488_;
v___y_1406_ = v___y_1489_;
v___y_1407_ = v___y_1490_;
v___y_1408_ = v___y_1491_;
v___y_1409_ = v___y_1492_;
v___y_1410_ = v___y_1493_;
v___y_1411_ = v___x_1515_;
v___y_1412_ = v___y_1495_;
v___y_1413_ = v___y_1496_;
goto v___jp_1399_;
}
}
}
}
}
}
v___jp_1368_:
{
lean_object* v___x_1383_; lean_object* v___x_1384_; lean_object* v___x_1385_; lean_object* v___x_1386_; lean_object* v___x_1387_; lean_object* v___x_1388_; lean_object* v___x_1389_; lean_object* v___x_1390_; lean_object* v___x_1391_; lean_object* v___x_1392_; lean_object* v___x_1393_; lean_object* v___x_1394_; lean_object* v___x_1395_; lean_object* v___x_1396_; lean_object* v___x_1397_; lean_object* v___x_1398_; 
v___x_1383_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_1383_, 0, v___y_1382_);
lean_inc_ref(v___y_1374_);
v___x_1384_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1384_, 0, v___y_1374_);
lean_ctor_set(v___x_1384_, 1, v___x_1383_);
v___x_1385_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1385_, 0, v___x_1384_);
lean_ctor_set(v___x_1385_, 1, v___y_1377_);
v___x_1386_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1386_, 0, v___y_1370_);
lean_ctor_set(v___x_1386_, 1, v___x_1385_);
v___x_1387_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1387_, 0, v___y_1371_);
lean_ctor_set(v___x_1387_, 1, v___x_1386_);
v___x_1388_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1388_, 0, v___y_1372_);
lean_ctor_set(v___x_1388_, 1, v___x_1387_);
v___x_1389_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1389_, 0, v___y_1381_);
lean_ctor_set(v___x_1389_, 1, v___x_1388_);
v___x_1390_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1390_, 0, v___y_1380_);
lean_ctor_set(v___x_1390_, 1, v___x_1389_);
v___x_1391_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1391_, 0, v___y_1375_);
lean_ctor_set(v___x_1391_, 1, v___x_1390_);
v___x_1392_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1392_, 0, v___y_1376_);
lean_ctor_set(v___x_1392_, 1, v___x_1391_);
v___x_1393_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1393_, 0, v___y_1378_);
lean_ctor_set(v___x_1393_, 1, v___x_1392_);
v___x_1394_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1394_, 0, v___y_1373_);
lean_ctor_set(v___x_1394_, 1, v___x_1393_);
lean_inc_ref(v___y_1379_);
v___x_1395_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1395_, 0, v___y_1379_);
lean_ctor_set(v___x_1395_, 1, v___x_1394_);
lean_inc_ref(v___y_1369_);
v___x_1396_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1396_, 0, v___y_1369_);
lean_ctor_set(v___x_1396_, 1, v___x_1395_);
v___x_1397_ = l_Lean_Json_mkObj(v___x_1396_);
lean_dec_ref_known(v___x_1396_, 2);
v___x_1398_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1398_, 0, v___x_1397_);
return v___x_1398_;
}
v___jp_1399_:
{
lean_object* v___x_1414_; lean_object* v___x_1415_; lean_object* v___x_1416_; lean_object* v___x_1417_; lean_object* v___x_1418_; lean_object* v___x_1419_; lean_object* v___x_1420_; lean_object* v___x_1421_; lean_object* v___x_1422_; lean_object* v___x_1423_; lean_object* v___x_1424_; lean_object* v___x_1425_; uint64_t v___x_1426_; lean_object* v___x_1427_; lean_object* v___x_1428_; lean_object* v___x_1429_; lean_object* v___x_1430_; lean_object* v___x_1431_; lean_object* v___x_1432_; lean_object* v___x_1433_; lean_object* v___x_1434_; lean_object* v___x_1435_; lean_object* v___x_1436_; lean_object* v___x_1437_; lean_object* v___x_1438_; lean_object* v___x_1439_; lean_object* v___x_1440_; lean_object* v___x_1441_; lean_object* v___x_1442_; lean_object* v___x_1443_; lean_object* v___x_1444_; lean_object* v___x_1445_; lean_object* v___x_1446_; lean_object* v___x_1447_; lean_object* v___x_1448_; lean_object* v___x_1449_; lean_object* v___x_1450_; lean_object* v___x_1451_; lean_object* v___x_1452_; lean_object* v___x_1453_; lean_object* v___x_1454_; lean_object* v___x_1455_; lean_object* v___x_1456_; lean_object* v___x_1457_; lean_object* v___x_1458_; lean_object* v___x_1459_; lean_object* v___x_1460_; lean_object* v___x_1461_; lean_object* v___x_1462_; lean_object* v___x_1463_; uint64_t v___x_1464_; lean_object* v___x_1465_; lean_object* v___x_1466_; lean_object* v___x_1467_; lean_object* v___x_1468_; lean_object* v___x_1469_; 
v___x_1414_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__3));
v___x_1415_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__7));
v___x_1416_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__8));
v___x_1417_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__9));
v___x_1418_ = l_Lean_JsonNumber_fromNat(v___y_1412_);
v___x_1419_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1419_, 0, v___x_1418_);
v___x_1420_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1420_, 0, v___x_1417_);
lean_ctor_set(v___x_1420_, 1, v___x_1419_);
v___x_1421_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__10));
v___x_1422_ = l_Lean_JsonNumber_fromNat(v___y_1401_);
v___x_1423_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1423_, 0, v___x_1422_);
v___x_1424_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1424_, 0, v___x_1421_);
lean_ctor_set(v___x_1424_, 1, v___x_1423_);
v___x_1425_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__11));
v___x_1426_ = lean_unbox_uint64(v___y_1410_);
lean_dec(v___y_1410_);
v___x_1427_ = lean_uint64_to_nat(v___x_1426_);
v___x_1428_ = l_Lean_JsonNumber_fromNat(v___x_1427_);
v___x_1429_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1429_, 0, v___x_1428_);
v___x_1430_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1430_, 0, v___x_1425_);
lean_ctor_set(v___x_1430_, 1, v___x_1429_);
lean_inc(v___y_1411_);
v___x_1431_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1431_, 0, v___x_1430_);
lean_ctor_set(v___x_1431_, 1, v___y_1411_);
v___x_1432_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1432_, 0, v___x_1424_);
lean_ctor_set(v___x_1432_, 1, v___x_1431_);
v___x_1433_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1433_, 0, v___x_1420_);
lean_ctor_set(v___x_1433_, 1, v___x_1432_);
v___x_1434_ = l_Lean_Json_mkObj(v___x_1433_);
lean_dec_ref_known(v___x_1433_, 2);
v___x_1435_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1435_, 0, v___x_1416_);
lean_ctor_set(v___x_1435_, 1, v___x_1434_);
v___x_1436_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__12));
v___x_1437_ = l_Lean_JsonNumber_fromNat(v___y_1408_);
v___x_1438_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1438_, 0, v___x_1437_);
v___x_1439_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1439_, 0, v___x_1436_);
lean_ctor_set(v___x_1439_, 1, v___x_1438_);
v___x_1440_ = ((lean_object*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg___closed__1));
v___x_1441_ = l_Lean_JsonNumber_fromNat(v___y_1402_);
v___x_1442_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1442_, 0, v___x_1441_);
v___x_1443_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1443_, 0, v___x_1440_);
lean_ctor_set(v___x_1443_, 1, v___x_1442_);
v___x_1444_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__13));
v___x_1445_ = l_Lean_JsonNumber_fromNat(v___y_1407_);
v___x_1446_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1446_, 0, v___x_1445_);
v___x_1447_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1447_, 0, v___x_1444_);
lean_ctor_set(v___x_1447_, 1, v___x_1446_);
v___x_1448_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__14));
v___x_1449_ = l_Lean_JsonNumber_fromNat(v___y_1403_);
v___x_1450_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1450_, 0, v___x_1449_);
v___x_1451_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1451_, 0, v___x_1448_);
lean_ctor_set(v___x_1451_, 1, v___x_1450_);
v___x_1452_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__15));
v___x_1453_ = l_Lean_JsonNumber_fromNat(v___y_1413_);
v___x_1454_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1454_, 0, v___x_1453_);
v___x_1455_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1455_, 0, v___x_1452_);
lean_ctor_set(v___x_1455_, 1, v___x_1454_);
v___x_1456_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__16));
v___x_1457_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1457_, 0, v___x_1456_);
lean_ctor_set(v___x_1457_, 1, v___y_1404_);
v___x_1458_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__17));
v___x_1459_ = lean_byte_array_size(v___y_1400_);
v___x_1460_ = l_Lean_JsonNumber_fromNat(v___x_1459_);
v___x_1461_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1461_, 0, v___x_1460_);
v___x_1462_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1462_, 0, v___x_1458_);
lean_ctor_set(v___x_1462_, 1, v___x_1461_);
v___x_1463_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__18));
v___x_1464_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_hashBytes(v___y_1406_, v___y_1400_);
v___x_1465_ = lean_uint64_to_nat(v___x_1464_);
v___x_1466_ = l_Lean_JsonNumber_fromNat(v___x_1465_);
v___x_1467_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1467_, 0, v___x_1466_);
v___x_1468_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1468_, 0, v___x_1463_);
lean_ctor_set(v___x_1468_, 1, v___x_1467_);
v___x_1469_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__19));
if (lean_obj_tag(v_audit_1366_) == 0)
{
v___y_1369_ = v___x_1414_;
v___y_1370_ = v___x_1468_;
v___y_1371_ = v___x_1462_;
v___y_1372_ = v___x_1457_;
v___y_1373_ = v___x_1435_;
v___y_1374_ = v___x_1469_;
v___y_1375_ = v___x_1447_;
v___y_1376_ = v___x_1443_;
v___y_1377_ = v___y_1411_;
v___y_1378_ = v___x_1439_;
v___y_1379_ = v___x_1415_;
v___y_1380_ = v___x_1451_;
v___y_1381_ = v___x_1455_;
v___y_1382_ = v___y_1409_;
goto v___jp_1368_;
}
else
{
v___y_1369_ = v___x_1414_;
v___y_1370_ = v___x_1468_;
v___y_1371_ = v___x_1462_;
v___y_1372_ = v___x_1457_;
v___y_1373_ = v___x_1435_;
v___y_1374_ = v___x_1469_;
v___y_1375_ = v___x_1447_;
v___y_1376_ = v___x_1443_;
v___y_1377_ = v___y_1411_;
v___y_1378_ = v___x_1439_;
v___y_1379_ = v___x_1415_;
v___y_1380_ = v___x_1451_;
v___y_1381_ = v___x_1455_;
v___y_1382_ = v___y_1405_;
goto v___jp_1368_;
}
}
v___jp_1470_:
{
lean_object* v___x_1471_; lean_object* v___x_1472_; 
v___x_1471_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__21));
v___x_1472_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1472_, 0, v___x_1471_);
return v___x_1472_;
}
v___jp_1473_:
{
lean_object* v___x_1474_; lean_object* v___x_1475_; 
v___x_1474_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__23));
v___x_1475_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1475_, 0, v___x_1474_);
return v___x_1475_;
}
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___boxed(lean_object* v_inputs_1601_, lean_object* v_output_1602_, lean_object* v_state_1603_, lean_object* v_geo_1604_, lean_object* v_audit_1605_, lean_object* v_a_1606_){
_start:
{
lean_object* v_res_1607_; 
v_res_1607_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume(v_inputs_1601_, v_output_1602_, v_state_1603_, v_geo_1604_, v_audit_1605_);
lean_dec(v_audit_1605_);
lean_dec_ref(v_output_1602_);
lean_dec_ref(v_inputs_1601_);
return v_res_1607_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2(lean_object* v_output_1608_, lean_object* v_audit_1609_, lean_object* v_inputs_1610_, lean_object* v___x_1611_, lean_object* v___x_1612_, uint8_t v___y_1613_, lean_object* v_range_1614_, lean_object* v_b_1615_, lean_object* v_i_1616_, lean_object* v_hs_1617_, lean_object* v_hl_1618_){
_start:
{
lean_object* v___x_1620_; 
v___x_1620_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___redArg(v_output_1608_, v_audit_1609_, v_inputs_1610_, v___x_1611_, v___x_1612_, v___y_1613_, v_range_1614_, v_b_1615_, v_i_1616_);
return v___x_1620_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2___boxed(lean_object* v_output_1621_, lean_object* v_audit_1622_, lean_object* v_inputs_1623_, lean_object* v___x_1624_, lean_object* v___x_1625_, lean_object* v___y_1626_, lean_object* v_range_1627_, lean_object* v_b_1628_, lean_object* v_i_1629_, lean_object* v_hs_1630_, lean_object* v_hl_1631_, lean_object* v___y_1632_){
_start:
{
uint8_t v___y_5578__boxed_1633_; lean_object* v_res_1634_; 
v___y_5578__boxed_1633_ = lean_unbox(v___y_1626_);
v_res_1634_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__2(v_output_1621_, v_audit_1622_, v_inputs_1623_, v___x_1624_, v___x_1625_, v___y_5578__boxed_1633_, v_range_1627_, v_b_1628_, v_i_1629_, v_hs_1630_, v_hl_1631_);
lean_dec_ref(v_range_1627_);
lean_dec(v___x_1625_);
lean_dec(v___x_1624_);
lean_dec_ref(v_inputs_1623_);
lean_dec(v_audit_1622_);
lean_dec_ref(v_output_1621_);
return v_res_1634_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5(lean_object* v_inputs_1635_, lean_object* v_output_1636_, lean_object* v_range_1637_, lean_object* v_b_1638_, lean_object* v_i_1639_, lean_object* v_hs_1640_, lean_object* v_hl_1641_){
_start:
{
lean_object* v___x_1643_; 
v___x_1643_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___redArg(v_inputs_1635_, v_output_1636_, v_range_1637_, v_b_1638_, v_i_1639_);
return v___x_1643_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5___boxed(lean_object* v_inputs_1644_, lean_object* v_output_1645_, lean_object* v_range_1646_, lean_object* v_b_1647_, lean_object* v_i_1648_, lean_object* v_hs_1649_, lean_object* v_hl_1650_, lean_object* v___y_1651_){
_start:
{
lean_object* v_res_1652_; 
v_res_1652_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume_spec__5(v_inputs_1644_, v_output_1645_, v_range_1646_, v_b_1647_, v_i_1648_, v_hs_1649_, v_hl_1650_);
lean_dec_ref(v_range_1646_);
lean_dec_ref(v_output_1645_);
lean_dec_ref(v_inputs_1644_);
return v_res_1652_;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__1(lean_object* v_a_1653_, lean_object* v_a_1654_){
_start:
{
if (lean_obj_tag(v_a_1653_) == 0)
{
lean_object* v___x_1655_; 
v___x_1655_ = l_List_reverse___redArg(v_a_1654_);
return v___x_1655_;
}
else
{
lean_object* v_head_1656_; lean_object* v_tail_1657_; lean_object* v___x_1659_; uint8_t v_isShared_1660_; uint8_t v_isSharedCheck_1668_; 
v_head_1656_ = lean_ctor_get(v_a_1653_, 0);
v_tail_1657_ = lean_ctor_get(v_a_1653_, 1);
v_isSharedCheck_1668_ = !lean_is_exclusive(v_a_1653_);
if (v_isSharedCheck_1668_ == 0)
{
v___x_1659_ = v_a_1653_;
v_isShared_1660_ = v_isSharedCheck_1668_;
goto v_resetjp_1658_;
}
else
{
lean_inc(v_tail_1657_);
lean_inc(v_head_1656_);
lean_dec(v_a_1653_);
v___x_1659_ = lean_box(0);
v_isShared_1660_ = v_isSharedCheck_1668_;
goto v_resetjp_1658_;
}
v_resetjp_1658_:
{
uint8_t v___x_1661_; lean_object* v___x_1662_; lean_object* v___x_1663_; lean_object* v___x_1665_; 
v___x_1661_ = lean_unbox(v_head_1656_);
lean_dec(v_head_1656_);
v___x_1662_ = lean_uint8_to_nat(v___x_1661_);
v___x_1663_ = l_Nat_reprFast(v___x_1662_);
if (v_isShared_1660_ == 0)
{
lean_ctor_set(v___x_1659_, 1, v_a_1654_);
lean_ctor_set(v___x_1659_, 0, v___x_1663_);
v___x_1665_ = v___x_1659_;
goto v_reusejp_1664_;
}
else
{
lean_object* v_reuseFailAlloc_1667_; 
v_reuseFailAlloc_1667_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1667_, 0, v___x_1663_);
lean_ctor_set(v_reuseFailAlloc_1667_, 1, v_a_1654_);
v___x_1665_ = v_reuseFailAlloc_1667_;
goto v_reusejp_1664_;
}
v_reusejp_1664_:
{
v_a_1653_ = v_tail_1657_;
v_a_1654_ = v___x_1665_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__2(lean_object* v_as_1670_, size_t v_sz_1671_, size_t v_i_1672_, lean_object* v_b_1673_){
_start:
{
uint8_t v___x_1675_; 
v___x_1675_ = lean_usize_dec_lt(v_i_1672_, v_sz_1671_);
if (v___x_1675_ == 0)
{
lean_object* v___x_1676_; 
v___x_1676_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1676_, 0, v_b_1673_);
return v___x_1676_;
}
else
{
lean_object* v_a_1677_; lean_object* v_timestamp_1678_; lean_object* v_bytes_1679_; lean_object* v___x_1680_; lean_object* v___x_1681_; lean_object* v___x_1682_; lean_object* v___x_1683_; lean_object* v___x_1684_; lean_object* v___x_1685_; lean_object* v___x_1686_; lean_object* v___x_1687_; lean_object* v___x_1688_; lean_object* v___x_1689_; 
v_a_1677_ = lean_array_uget_borrowed(v_as_1670_, v_i_1672_);
v_timestamp_1678_ = lean_ctor_get(v_a_1677_, 0);
v_bytes_1679_ = lean_ctor_get(v_a_1677_, 1);
v___x_1680_ = lean_box(0);
lean_inc_ref(v_timestamp_1678_);
v___x_1681_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_floatBits(v_timestamp_1678_);
v___x_1682_ = l_Nat_reprFast(v___x_1681_);
v___x_1683_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__2___closed__0));
v___x_1684_ = lean_string_append(v___x_1682_, v___x_1683_);
v___x_1685_ = lean_box(0);
lean_inc(v_bytes_1679_);
v___x_1686_ = l_List_mapTR_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__1(v_bytes_1679_, v___x_1685_);
v___x_1687_ = l_String_intercalate(v___x_1683_, v___x_1686_);
v___x_1688_ = lean_string_append(v___x_1684_, v___x_1687_);
lean_dec_ref(v___x_1687_);
v___x_1689_ = l_IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0(v___x_1688_);
if (lean_obj_tag(v___x_1689_) == 0)
{
size_t v___x_1690_; size_t v___x_1691_; 
lean_dec_ref_known(v___x_1689_, 1);
v___x_1690_ = ((size_t)1ULL);
v___x_1691_ = lean_usize_add(v_i_1672_, v___x_1690_);
v_i_1672_ = v___x_1691_;
v_b_1673_ = v___x_1680_;
goto _start;
}
else
{
return v___x_1689_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__2___boxed(lean_object* v_as_1693_, lean_object* v_sz_1694_, lean_object* v_i_1695_, lean_object* v_b_1696_, lean_object* v___y_1697_){
_start:
{
size_t v_sz_boxed_1698_; size_t v_i_boxed_1699_; lean_object* v_res_1700_; 
v_sz_boxed_1698_ = lean_unbox_usize(v_sz_1694_);
lean_dec(v_sz_1694_);
v_i_boxed_1699_ = lean_unbox_usize(v_i_1695_);
lean_dec(v_i_1695_);
v_res_1700_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__2(v_as_1693_, v_sz_boxed_1698_, v_i_boxed_1699_, v_b_1696_);
lean_dec_ref(v_as_1693_);
return v_res_1700_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__0___redArg(lean_object* v_as_x27_1701_, lean_object* v_b_1702_){
_start:
{
if (lean_obj_tag(v_as_x27_1701_) == 0)
{
lean_object* v___x_1704_; 
v___x_1704_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1704_, 0, v_b_1702_);
return v___x_1704_;
}
else
{
lean_object* v_head_1705_; lean_object* v_position_1706_; lean_object* v_tail_1707_; lean_object* v_icao_1708_; lean_object* v_lat_1709_; lean_object* v_lon_1710_; lean_object* v___x_1711_; lean_object* v___x_1712_; lean_object* v___x_1713_; lean_object* v___x_1714_; lean_object* v___x_1715_; lean_object* v___x_1716_; lean_object* v___x_1717_; lean_object* v___x_1718_; lean_object* v___x_1719_; lean_object* v___x_1720_; lean_object* v___x_1721_; 
v_head_1705_ = lean_ctor_get(v_as_x27_1701_, 0);
v_position_1706_ = lean_ctor_get(v_head_1705_, 1);
v_tail_1707_ = lean_ctor_get(v_as_x27_1701_, 1);
v_icao_1708_ = lean_ctor_get(v_head_1705_, 0);
v_lat_1709_ = lean_ctor_get(v_position_1706_, 0);
v_lon_1710_ = lean_ctor_get(v_position_1706_, 1);
v___x_1711_ = lean_box(0);
v___x_1712_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__2___closed__0));
lean_inc_ref(v_icao_1708_);
v___x_1713_ = lean_string_append(v_icao_1708_, v___x_1712_);
lean_inc_ref(v_lat_1709_);
v___x_1714_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_floatBits(v_lat_1709_);
v___x_1715_ = l_Nat_reprFast(v___x_1714_);
v___x_1716_ = lean_string_append(v___x_1713_, v___x_1715_);
lean_dec_ref(v___x_1715_);
v___x_1717_ = lean_string_append(v___x_1716_, v___x_1712_);
lean_inc_ref(v_lon_1710_);
v___x_1718_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_floatBits(v_lon_1710_);
v___x_1719_ = l_Nat_reprFast(v___x_1718_);
v___x_1720_ = lean_string_append(v___x_1717_, v___x_1719_);
lean_dec_ref(v___x_1719_);
v___x_1721_ = l_IO_println___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit_spec__0(v___x_1720_);
if (lean_obj_tag(v___x_1721_) == 0)
{
lean_dec_ref_known(v___x_1721_, 1);
v_as_x27_1701_ = v_tail_1707_;
v_b_1702_ = v___x_1711_;
goto _start;
}
else
{
return v___x_1721_;
}
}
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__0___redArg___boxed(lean_object* v_as_x27_1723_, lean_object* v_b_1724_, lean_object* v___y_1725_){
_start:
{
lean_object* v_res_1726_; 
v_res_1726_ = l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__0___redArg(v_as_x27_1723_, v_b_1724_);
lean_dec(v_as_x27_1723_);
return v_res_1726_;
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute(lean_object* v_path_1748_, uint8_t v_wait_1749_, lean_object* v_audit_1750_, uint8_t v_inputAudit_1751_, uint8_t v_airportAudit_1752_){
_start:
{
lean_object* v___x_1754_; 
v___x_1754_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadInputs(v_path_1748_);
if (lean_obj_tag(v___x_1754_) == 0)
{
lean_object* v_a_1755_; lean_object* v___x_1756_; 
v_a_1755_ = lean_ctor_get(v___x_1754_, 0);
lean_inc(v_a_1755_);
lean_dec_ref_known(v___x_1754_, 1);
v___x_1756_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_loadAirports();
if (lean_obj_tag(v___x_1756_) == 0)
{
if (v_inputAudit_1751_ == 0)
{
if (v_airportAudit_1752_ == 0)
{
lean_object* v_a_1757_; lean_object* v___x_1758_; lean_object* v___x_1759_; lean_object* v___x_1760_; lean_object* v___x_1761_; lean_object* v___x_1762_; lean_object* v___x_1763_; lean_object* v___x_1764_; lean_object* v___x_1765_; lean_object* v___x_1766_; lean_object* v___x_1767_; lean_object* v___x_1768_; lean_object* v___x_1769_; lean_object* v___x_1770_; lean_object* v___x_1771_; lean_object* v___x_1772_; lean_object* v___x_1773_; lean_object* v___x_1774_; lean_object* v___x_1775_; lean_object* v___x_1776_; lean_object* v___x_1777_; lean_object* v___x_1778_; lean_object* v___x_1779_; lean_object* v___x_1780_; lean_object* v___x_1781_; lean_object* v___x_1782_; lean_object* v___x_1783_; 
v_a_1757_ = lean_ctor_get(v___x_1756_, 0);
lean_inc_n(v_a_1757_, 2);
lean_dec_ref_known(v___x_1756_, 1);
v___x_1758_ = lp_lean1090_Lean1090_Impl_CPR_Policy_numericalGeography(v_a_1757_);
v___x_1759_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__2));
v___x_1760_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__7));
v___x_1761_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__3));
v___x_1762_ = lean_array_get_size(v_a_1755_);
v___x_1763_ = l_Lean_JsonNumber_fromNat(v___x_1762_);
v___x_1764_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1764_, 0, v___x_1763_);
v___x_1765_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1765_, 0, v___x_1761_);
lean_ctor_set(v___x_1765_, 1, v___x_1764_);
v___x_1766_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__4));
v___x_1767_ = l_List_lengthTR___redArg(v_a_1757_);
lean_dec(v_a_1757_);
v___x_1768_ = l_Lean_JsonNumber_fromNat(v___x_1767_);
v___x_1769_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1769_, 0, v___x_1768_);
v___x_1770_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1770_, 0, v___x_1766_);
lean_ctor_set(v___x_1770_, 1, v___x_1769_);
v___x_1771_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__5));
v___x_1772_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__6));
v___x_1773_ = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(v___x_1773_, 0, v_airportAudit_1752_);
v___x_1774_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1774_, 0, v___x_1772_);
lean_ctor_set(v___x_1774_, 1, v___x_1773_);
v___x_1775_ = lean_box(0);
v___x_1776_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1776_, 0, v___x_1774_);
lean_ctor_set(v___x_1776_, 1, v___x_1775_);
v___x_1777_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1777_, 0, v___x_1771_);
lean_ctor_set(v___x_1777_, 1, v___x_1776_);
v___x_1778_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1778_, 0, v___x_1770_);
lean_ctor_set(v___x_1778_, 1, v___x_1777_);
v___x_1779_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1779_, 0, v___x_1765_);
lean_ctor_set(v___x_1779_, 1, v___x_1778_);
v___x_1780_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1780_, 0, v___x_1760_);
lean_ctor_set(v___x_1780_, 1, v___x_1779_);
v___x_1781_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1781_, 0, v___x_1759_);
lean_ctor_set(v___x_1781_, 1, v___x_1780_);
v___x_1782_ = l_Lean_Json_mkObj(v___x_1781_);
lean_dec_ref_known(v___x_1781_, 2);
v___x_1783_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit(v___x_1782_);
if (lean_obj_tag(v___x_1783_) == 0)
{
lean_object* v___x_1784_; lean_object* v___x_1785_; 
lean_dec_ref_known(v___x_1783_, 1);
v___x_1784_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__7));
v___x_1785_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command(v_wait_1749_, v___x_1784_);
if (lean_obj_tag(v___x_1785_) == 0)
{
lean_object* v___x_1787_; uint8_t v_isShared_1788_; uint8_t v_isSharedCheck_1833_; 
v_isSharedCheck_1833_ = !lean_is_exclusive(v___x_1785_);
if (v_isSharedCheck_1833_ == 0)
{
lean_object* v_unused_1834_; 
v_unused_1834_ = lean_ctor_get(v___x_1785_, 0);
lean_dec(v_unused_1834_);
v___x_1787_ = v___x_1785_;
v_isShared_1788_ = v_isSharedCheck_1833_;
goto v_resetjp_1786_;
}
else
{
lean_dec(v___x_1785_);
v___x_1787_ = lean_box(0);
v_isShared_1788_ = v_isSharedCheck_1833_;
goto v_resetjp_1786_;
}
v_resetjp_1786_:
{
lean_object* v___x_1789_; 
lean_inc_ref(v___x_1758_);
v___x_1789_ = l_Lean1090_Diagnostics_CPRCosts_runCPR(v_a_1755_, v___x_1758_);
if (lean_obj_tag(v___x_1789_) == 0)
{
lean_object* v_a_1790_; lean_object* v_fst_1791_; lean_object* v_snd_1792_; lean_object* v___x_1794_; uint8_t v_isShared_1795_; uint8_t v_isSharedCheck_1824_; 
v_a_1790_ = lean_ctor_get(v___x_1789_, 0);
lean_inc(v_a_1790_);
lean_dec_ref_known(v___x_1789_, 1);
v_fst_1791_ = lean_ctor_get(v_a_1790_, 0);
v_snd_1792_ = lean_ctor_get(v_a_1790_, 1);
v_isSharedCheck_1824_ = !lean_is_exclusive(v_a_1790_);
if (v_isSharedCheck_1824_ == 0)
{
v___x_1794_ = v_a_1790_;
v_isShared_1795_ = v_isSharedCheck_1824_;
goto v_resetjp_1793_;
}
else
{
lean_inc(v_snd_1792_);
lean_inc(v_fst_1791_);
lean_dec(v_a_1790_);
v___x_1794_ = lean_box(0);
v_isShared_1795_ = v_isSharedCheck_1824_;
goto v_resetjp_1793_;
}
v_resetjp_1793_:
{
lean_object* v___x_1796_; lean_object* v___x_1797_; lean_object* v___x_1798_; lean_object* v___x_1799_; lean_object* v___x_1801_; 
v___x_1796_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__10));
v___x_1797_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__11));
v___x_1798_ = lean_array_get_size(v_fst_1791_);
v___x_1799_ = l_Lean_JsonNumber_fromNat(v___x_1798_);
if (v_isShared_1788_ == 0)
{
lean_ctor_set_tag(v___x_1787_, 2);
lean_ctor_set(v___x_1787_, 0, v___x_1799_);
v___x_1801_ = v___x_1787_;
goto v_reusejp_1800_;
}
else
{
lean_object* v_reuseFailAlloc_1823_; 
v_reuseFailAlloc_1823_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1823_, 0, v___x_1799_);
v___x_1801_ = v_reuseFailAlloc_1823_;
goto v_reusejp_1800_;
}
v_reusejp_1800_:
{
lean_object* v___x_1803_; 
if (v_isShared_1795_ == 0)
{
lean_ctor_set(v___x_1794_, 1, v___x_1801_);
lean_ctor_set(v___x_1794_, 0, v___x_1797_);
v___x_1803_ = v___x_1794_;
goto v_reusejp_1802_;
}
else
{
lean_object* v_reuseFailAlloc_1822_; 
v_reuseFailAlloc_1822_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1822_, 0, v___x_1797_);
lean_ctor_set(v_reuseFailAlloc_1822_, 1, v___x_1801_);
v___x_1803_ = v_reuseFailAlloc_1822_;
goto v_reusejp_1802_;
}
v_reusejp_1802_:
{
lean_object* v___x_1804_; lean_object* v___x_1805_; lean_object* v___x_1806_; lean_object* v___x_1807_; lean_object* v___x_1808_; 
v___x_1804_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1804_, 0, v___x_1803_);
lean_ctor_set(v___x_1804_, 1, v___x_1775_);
v___x_1805_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1805_, 0, v___x_1760_);
lean_ctor_set(v___x_1805_, 1, v___x_1804_);
v___x_1806_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1806_, 0, v___x_1796_);
lean_ctor_set(v___x_1806_, 1, v___x_1805_);
v___x_1807_ = l_Lean_Json_mkObj(v___x_1806_);
lean_dec_ref_known(v___x_1806_, 2);
v___x_1808_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit(v___x_1807_);
if (lean_obj_tag(v___x_1808_) == 0)
{
lean_object* v___x_1809_; lean_object* v___x_1810_; 
lean_dec_ref_known(v___x_1808_, 1);
v___x_1809_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___closed__12));
v___x_1810_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_command(v_wait_1749_, v___x_1809_);
if (lean_obj_tag(v___x_1810_) == 0)
{
lean_object* v___x_1811_; 
lean_dec_ref_known(v___x_1810_, 1);
v___x_1811_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume(v_a_1755_, v_fst_1791_, v_snd_1792_, v___x_1758_, v_audit_1750_);
lean_dec(v_fst_1791_);
lean_dec(v_a_1755_);
if (lean_obj_tag(v___x_1811_) == 0)
{
lean_object* v_a_1812_; lean_object* v___x_1813_; 
v_a_1812_ = lean_ctor_get(v___x_1811_, 0);
lean_inc(v_a_1812_);
lean_dec_ref_known(v___x_1811_, 1);
v___x_1813_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_emit(v_a_1812_);
return v___x_1813_;
}
else
{
lean_object* v_a_1814_; lean_object* v___x_1816_; uint8_t v_isShared_1817_; uint8_t v_isSharedCheck_1821_; 
v_a_1814_ = lean_ctor_get(v___x_1811_, 0);
v_isSharedCheck_1821_ = !lean_is_exclusive(v___x_1811_);
if (v_isSharedCheck_1821_ == 0)
{
v___x_1816_ = v___x_1811_;
v_isShared_1817_ = v_isSharedCheck_1821_;
goto v_resetjp_1815_;
}
else
{
lean_inc(v_a_1814_);
lean_dec(v___x_1811_);
v___x_1816_ = lean_box(0);
v_isShared_1817_ = v_isSharedCheck_1821_;
goto v_resetjp_1815_;
}
v_resetjp_1815_:
{
lean_object* v___x_1819_; 
if (v_isShared_1817_ == 0)
{
v___x_1819_ = v___x_1816_;
goto v_reusejp_1818_;
}
else
{
lean_object* v_reuseFailAlloc_1820_; 
v_reuseFailAlloc_1820_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1820_, 0, v_a_1814_);
v___x_1819_ = v_reuseFailAlloc_1820_;
goto v_reusejp_1818_;
}
v_reusejp_1818_:
{
return v___x_1819_;
}
}
}
}
else
{
lean_dec(v_snd_1792_);
lean_dec(v_fst_1791_);
lean_dec_ref(v___x_1758_);
lean_dec(v_a_1755_);
return v___x_1810_;
}
}
else
{
lean_dec(v_snd_1792_);
lean_dec(v_fst_1791_);
lean_dec_ref(v___x_1758_);
lean_dec(v_a_1755_);
return v___x_1808_;
}
}
}
}
}
else
{
lean_object* v_a_1825_; lean_object* v___x_1827_; uint8_t v_isShared_1828_; uint8_t v_isSharedCheck_1832_; 
lean_del_object(v___x_1787_);
lean_dec_ref(v___x_1758_);
lean_dec(v_a_1755_);
v_a_1825_ = lean_ctor_get(v___x_1789_, 0);
v_isSharedCheck_1832_ = !lean_is_exclusive(v___x_1789_);
if (v_isSharedCheck_1832_ == 0)
{
v___x_1827_ = v___x_1789_;
v_isShared_1828_ = v_isSharedCheck_1832_;
goto v_resetjp_1826_;
}
else
{
lean_inc(v_a_1825_);
lean_dec(v___x_1789_);
v___x_1827_ = lean_box(0);
v_isShared_1828_ = v_isSharedCheck_1832_;
goto v_resetjp_1826_;
}
v_resetjp_1826_:
{
lean_object* v___x_1830_; 
if (v_isShared_1828_ == 0)
{
v___x_1830_ = v___x_1827_;
goto v_reusejp_1829_;
}
else
{
lean_object* v_reuseFailAlloc_1831_; 
v_reuseFailAlloc_1831_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1831_, 0, v_a_1825_);
v___x_1830_ = v_reuseFailAlloc_1831_;
goto v_reusejp_1829_;
}
v_reusejp_1829_:
{
return v___x_1830_;
}
}
}
}
}
else
{
lean_dec_ref(v___x_1758_);
lean_dec(v_a_1755_);
return v___x_1785_;
}
}
else
{
lean_dec_ref(v___x_1758_);
lean_dec(v_a_1755_);
return v___x_1783_;
}
}
else
{
lean_object* v_a_1835_; lean_object* v___x_1836_; lean_object* v___x_1837_; 
lean_dec(v_a_1755_);
v_a_1835_ = lean_ctor_get(v___x_1756_, 0);
lean_inc(v_a_1835_);
lean_dec_ref_known(v___x_1756_, 1);
v___x_1836_ = lean_box(0);
v___x_1837_ = l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__0___redArg(v_a_1835_, v___x_1836_);
lean_dec(v_a_1835_);
if (lean_obj_tag(v___x_1837_) == 0)
{
lean_object* v___x_1839_; uint8_t v_isShared_1840_; uint8_t v_isSharedCheck_1844_; 
v_isSharedCheck_1844_ = !lean_is_exclusive(v___x_1837_);
if (v_isSharedCheck_1844_ == 0)
{
lean_object* v_unused_1845_; 
v_unused_1845_ = lean_ctor_get(v___x_1837_, 0);
lean_dec(v_unused_1845_);
v___x_1839_ = v___x_1837_;
v_isShared_1840_ = v_isSharedCheck_1844_;
goto v_resetjp_1838_;
}
else
{
lean_dec(v___x_1837_);
v___x_1839_ = lean_box(0);
v_isShared_1840_ = v_isSharedCheck_1844_;
goto v_resetjp_1838_;
}
v_resetjp_1838_:
{
lean_object* v___x_1842_; 
if (v_isShared_1840_ == 0)
{
lean_ctor_set(v___x_1839_, 0, v___x_1836_);
v___x_1842_ = v___x_1839_;
goto v_reusejp_1841_;
}
else
{
lean_object* v_reuseFailAlloc_1843_; 
v_reuseFailAlloc_1843_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1843_, 0, v___x_1836_);
v___x_1842_ = v_reuseFailAlloc_1843_;
goto v_reusejp_1841_;
}
v_reusejp_1841_:
{
return v___x_1842_;
}
}
}
else
{
return v___x_1837_;
}
}
}
else
{
lean_object* v___x_1846_; size_t v_sz_1847_; size_t v___x_1848_; lean_object* v___x_1849_; 
lean_dec_ref_known(v___x_1756_, 1);
v___x_1846_ = lean_box(0);
v_sz_1847_ = lean_array_size(v_a_1755_);
v___x_1848_ = ((size_t)0ULL);
v___x_1849_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__2(v_a_1755_, v_sz_1847_, v___x_1848_, v___x_1846_);
lean_dec(v_a_1755_);
if (lean_obj_tag(v___x_1849_) == 0)
{
lean_object* v___x_1851_; uint8_t v_isShared_1852_; uint8_t v_isSharedCheck_1856_; 
v_isSharedCheck_1856_ = !lean_is_exclusive(v___x_1849_);
if (v_isSharedCheck_1856_ == 0)
{
lean_object* v_unused_1857_; 
v_unused_1857_ = lean_ctor_get(v___x_1849_, 0);
lean_dec(v_unused_1857_);
v___x_1851_ = v___x_1849_;
v_isShared_1852_ = v_isSharedCheck_1856_;
goto v_resetjp_1850_;
}
else
{
lean_dec(v___x_1849_);
v___x_1851_ = lean_box(0);
v_isShared_1852_ = v_isSharedCheck_1856_;
goto v_resetjp_1850_;
}
v_resetjp_1850_:
{
lean_object* v___x_1854_; 
if (v_isShared_1852_ == 0)
{
lean_ctor_set(v___x_1851_, 0, v___x_1846_);
v___x_1854_ = v___x_1851_;
goto v_reusejp_1853_;
}
else
{
lean_object* v_reuseFailAlloc_1855_; 
v_reuseFailAlloc_1855_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1855_, 0, v___x_1846_);
v___x_1854_ = v_reuseFailAlloc_1855_;
goto v_reusejp_1853_;
}
v_reusejp_1853_:
{
return v___x_1854_;
}
}
}
else
{
return v___x_1849_;
}
}
}
else
{
lean_object* v_a_1858_; lean_object* v___x_1860_; uint8_t v_isShared_1861_; uint8_t v_isSharedCheck_1865_; 
lean_dec(v_a_1755_);
v_a_1858_ = lean_ctor_get(v___x_1756_, 0);
v_isSharedCheck_1865_ = !lean_is_exclusive(v___x_1756_);
if (v_isSharedCheck_1865_ == 0)
{
v___x_1860_ = v___x_1756_;
v_isShared_1861_ = v_isSharedCheck_1865_;
goto v_resetjp_1859_;
}
else
{
lean_inc(v_a_1858_);
lean_dec(v___x_1756_);
v___x_1860_ = lean_box(0);
v_isShared_1861_ = v_isSharedCheck_1865_;
goto v_resetjp_1859_;
}
v_resetjp_1859_:
{
lean_object* v___x_1863_; 
if (v_isShared_1861_ == 0)
{
v___x_1863_ = v___x_1860_;
goto v_reusejp_1862_;
}
else
{
lean_object* v_reuseFailAlloc_1864_; 
v_reuseFailAlloc_1864_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1864_, 0, v_a_1858_);
v___x_1863_ = v_reuseFailAlloc_1864_;
goto v_reusejp_1862_;
}
v_reusejp_1862_:
{
return v___x_1863_;
}
}
}
}
else
{
lean_object* v_a_1866_; lean_object* v___x_1868_; uint8_t v_isShared_1869_; uint8_t v_isSharedCheck_1873_; 
v_a_1866_ = lean_ctor_get(v___x_1754_, 0);
v_isSharedCheck_1873_ = !lean_is_exclusive(v___x_1754_);
if (v_isSharedCheck_1873_ == 0)
{
v___x_1868_ = v___x_1754_;
v_isShared_1869_ = v_isSharedCheck_1873_;
goto v_resetjp_1867_;
}
else
{
lean_inc(v_a_1866_);
lean_dec(v___x_1754_);
v___x_1868_ = lean_box(0);
v_isShared_1869_ = v_isSharedCheck_1873_;
goto v_resetjp_1867_;
}
v_resetjp_1867_:
{
lean_object* v___x_1871_; 
if (v_isShared_1869_ == 0)
{
v___x_1871_ = v___x_1868_;
goto v_reusejp_1870_;
}
else
{
lean_object* v_reuseFailAlloc_1872_; 
v_reuseFailAlloc_1872_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1872_, 0, v_a_1866_);
v___x_1871_ = v_reuseFailAlloc_1872_;
goto v_reusejp_1870_;
}
v_reusejp_1870_:
{
return v___x_1871_;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute___boxed(lean_object* v_path_1874_, lean_object* v_wait_1875_, lean_object* v_audit_1876_, lean_object* v_inputAudit_1877_, lean_object* v_airportAudit_1878_, lean_object* v_a_1879_){
_start:
{
uint8_t v_wait_boxed_1880_; uint8_t v_inputAudit_boxed_1881_; uint8_t v_airportAudit_boxed_1882_; lean_object* v_res_1883_; 
v_wait_boxed_1880_ = lean_unbox(v_wait_1875_);
v_inputAudit_boxed_1881_ = lean_unbox(v_inputAudit_1877_);
v_airportAudit_boxed_1882_ = lean_unbox(v_airportAudit_1878_);
v_res_1883_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute(v_path_1874_, v_wait_boxed_1880_, v_audit_1876_, v_inputAudit_boxed_1881_, v_airportAudit_boxed_1882_);
lean_dec(v_audit_1876_);
lean_dec_ref(v_path_1874_);
return v_res_1883_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__0(lean_object* v_as_1884_, lean_object* v_as_x27_1885_, lean_object* v_b_1886_, lean_object* v_a_1887_){
_start:
{
lean_object* v___x_1889_; 
v___x_1889_ = l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__0___redArg(v_as_x27_1885_, v_b_1886_);
return v___x_1889_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__0___boxed(lean_object* v_as_1890_, lean_object* v_as_x27_1891_, lean_object* v_b_1892_, lean_object* v_a_1893_, lean_object* v___y_1894_){
_start:
{
lean_object* v_res_1895_; 
v_res_1895_ = l_List_forIn_x27_loop___at___00__private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute_spec__0(v_as_1890_, v_as_x27_1891_, v_b_1892_, v_a_1893_);
lean_dec(v_as_x27_1891_);
lean_dec(v_as_1890_);
return v_res_1895_;
}
}
static lean_object* _init_l_main___boxed__const__1(void){
_start:
{
uint32_t v___x_1901_; lean_object* v___x_1902_; 
v___x_1901_ = 2;
v___x_1902_ = lean_box_uint32(v___x_1901_);
return v___x_1902_;
}
}
static lean_object* _init_l_main___boxed__const__2(void){
_start:
{
uint32_t v___x_1903_; lean_object* v___x_1904_; 
v___x_1903_ = 0;
v___x_1904_ = lean_box_uint32(v___x_1903_);
return v___x_1904_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_1905_){
_start:
{
if (lean_obj_tag(v_args_1905_) == 1)
{
lean_object* v_head_1927_; lean_object* v_tail_1928_; lean_object* v___x_1929_; uint8_t v___x_1930_; 
v_head_1927_ = lean_ctor_get(v_args_1905_, 0);
lean_inc(v_head_1927_);
v_tail_1928_ = lean_ctor_get(v_args_1905_, 1);
lean_inc(v_tail_1928_);
lean_dec_ref_known(v_args_1905_, 2);
v___x_1929_ = ((lean_object*)(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_consume___closed__5));
v___x_1930_ = lean_string_dec_eq(v_head_1927_, v___x_1929_);
if (v___x_1930_ == 0)
{
lean_object* v___x_1931_; uint8_t v___x_1932_; 
v___x_1931_ = ((lean_object*)(l_main___closed__1));
v___x_1932_ = lean_string_dec_eq(v_head_1927_, v___x_1931_);
if (v___x_1932_ == 0)
{
lean_object* v___x_1933_; uint8_t v___x_1934_; 
v___x_1933_ = ((lean_object*)(l_main___closed__2));
v___x_1934_ = lean_string_dec_eq(v_head_1927_, v___x_1933_);
lean_dec(v_head_1927_);
if (v___x_1934_ == 0)
{
lean_dec(v_tail_1928_);
goto v___jp_1907_;
}
else
{
if (lean_obj_tag(v_tail_1928_) == 1)
{
lean_object* v_tail_1935_; 
v_tail_1935_ = lean_ctor_get(v_tail_1928_, 1);
if (lean_obj_tag(v_tail_1935_) == 0)
{
lean_object* v_head_1936_; lean_object* v___x_1937_; lean_object* v___x_1938_; 
v_head_1936_ = lean_ctor_get(v_tail_1928_, 0);
lean_inc(v_head_1936_);
lean_dec_ref_known(v_tail_1928_, 2);
v___x_1937_ = lean_box(0);
v___x_1938_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute(v_head_1936_, v___x_1932_, v___x_1937_, v___x_1932_, v___x_1934_);
lean_dec(v_head_1936_);
if (lean_obj_tag(v___x_1938_) == 0)
{
lean_object* v___x_1940_; uint8_t v_isShared_1941_; uint8_t v_isSharedCheck_1946_; 
v_isSharedCheck_1946_ = !lean_is_exclusive(v___x_1938_);
if (v_isSharedCheck_1946_ == 0)
{
lean_object* v_unused_1947_; 
v_unused_1947_ = lean_ctor_get(v___x_1938_, 0);
lean_dec(v_unused_1947_);
v___x_1940_ = v___x_1938_;
v_isShared_1941_ = v_isSharedCheck_1946_;
goto v_resetjp_1939_;
}
else
{
lean_dec(v___x_1938_);
v___x_1940_ = lean_box(0);
v_isShared_1941_ = v_isSharedCheck_1946_;
goto v_resetjp_1939_;
}
v_resetjp_1939_:
{
lean_object* v___x_1942_; lean_object* v___x_1944_; 
v___x_1942_ = l_main___boxed__const__2;
if (v_isShared_1941_ == 0)
{
lean_ctor_set(v___x_1940_, 0, v___x_1942_);
v___x_1944_ = v___x_1940_;
goto v_reusejp_1943_;
}
else
{
lean_object* v_reuseFailAlloc_1945_; 
v_reuseFailAlloc_1945_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1945_, 0, v___x_1942_);
v___x_1944_ = v_reuseFailAlloc_1945_;
goto v_reusejp_1943_;
}
v_reusejp_1943_:
{
return v___x_1944_;
}
}
}
else
{
lean_object* v_a_1948_; lean_object* v___x_1950_; uint8_t v_isShared_1951_; uint8_t v_isSharedCheck_1955_; 
v_a_1948_ = lean_ctor_get(v___x_1938_, 0);
v_isSharedCheck_1955_ = !lean_is_exclusive(v___x_1938_);
if (v_isSharedCheck_1955_ == 0)
{
v___x_1950_ = v___x_1938_;
v_isShared_1951_ = v_isSharedCheck_1955_;
goto v_resetjp_1949_;
}
else
{
lean_inc(v_a_1948_);
lean_dec(v___x_1938_);
v___x_1950_ = lean_box(0);
v_isShared_1951_ = v_isSharedCheck_1955_;
goto v_resetjp_1949_;
}
v_resetjp_1949_:
{
lean_object* v___x_1953_; 
if (v_isShared_1951_ == 0)
{
v___x_1953_ = v___x_1950_;
goto v_reusejp_1952_;
}
else
{
lean_object* v_reuseFailAlloc_1954_; 
v_reuseFailAlloc_1954_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1954_, 0, v_a_1948_);
v___x_1953_ = v_reuseFailAlloc_1954_;
goto v_reusejp_1952_;
}
v_reusejp_1952_:
{
return v___x_1953_;
}
}
}
}
else
{
lean_dec_ref_known(v_tail_1928_, 2);
goto v___jp_1907_;
}
}
else
{
lean_dec(v_tail_1928_);
goto v___jp_1907_;
}
}
}
else
{
lean_dec(v_head_1927_);
if (lean_obj_tag(v_tail_1928_) == 1)
{
lean_object* v_tail_1956_; 
v_tail_1956_ = lean_ctor_get(v_tail_1928_, 1);
if (lean_obj_tag(v_tail_1956_) == 0)
{
lean_object* v_head_1957_; lean_object* v___x_1958_; lean_object* v___x_1959_; 
v_head_1957_ = lean_ctor_get(v_tail_1928_, 0);
lean_inc(v_head_1957_);
lean_dec_ref_known(v_tail_1928_, 2);
v___x_1958_ = lean_box(0);
v___x_1959_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute(v_head_1957_, v___x_1930_, v___x_1958_, v___x_1932_, v___x_1930_);
lean_dec(v_head_1957_);
if (lean_obj_tag(v___x_1959_) == 0)
{
lean_object* v___x_1961_; uint8_t v_isShared_1962_; uint8_t v_isSharedCheck_1967_; 
v_isSharedCheck_1967_ = !lean_is_exclusive(v___x_1959_);
if (v_isSharedCheck_1967_ == 0)
{
lean_object* v_unused_1968_; 
v_unused_1968_ = lean_ctor_get(v___x_1959_, 0);
lean_dec(v_unused_1968_);
v___x_1961_ = v___x_1959_;
v_isShared_1962_ = v_isSharedCheck_1967_;
goto v_resetjp_1960_;
}
else
{
lean_dec(v___x_1959_);
v___x_1961_ = lean_box(0);
v_isShared_1962_ = v_isSharedCheck_1967_;
goto v_resetjp_1960_;
}
v_resetjp_1960_:
{
lean_object* v___x_1963_; lean_object* v___x_1965_; 
v___x_1963_ = l_main___boxed__const__2;
if (v_isShared_1962_ == 0)
{
lean_ctor_set(v___x_1961_, 0, v___x_1963_);
v___x_1965_ = v___x_1961_;
goto v_reusejp_1964_;
}
else
{
lean_object* v_reuseFailAlloc_1966_; 
v_reuseFailAlloc_1966_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1966_, 0, v___x_1963_);
v___x_1965_ = v_reuseFailAlloc_1966_;
goto v_reusejp_1964_;
}
v_reusejp_1964_:
{
return v___x_1965_;
}
}
}
else
{
lean_object* v_a_1969_; lean_object* v___x_1971_; uint8_t v_isShared_1972_; uint8_t v_isSharedCheck_1976_; 
v_a_1969_ = lean_ctor_get(v___x_1959_, 0);
v_isSharedCheck_1976_ = !lean_is_exclusive(v___x_1959_);
if (v_isSharedCheck_1976_ == 0)
{
v___x_1971_ = v___x_1959_;
v_isShared_1972_ = v_isSharedCheck_1976_;
goto v_resetjp_1970_;
}
else
{
lean_inc(v_a_1969_);
lean_dec(v___x_1959_);
v___x_1971_ = lean_box(0);
v_isShared_1972_ = v_isSharedCheck_1976_;
goto v_resetjp_1970_;
}
v_resetjp_1970_:
{
lean_object* v___x_1974_; 
if (v_isShared_1972_ == 0)
{
v___x_1974_ = v___x_1971_;
goto v_reusejp_1973_;
}
else
{
lean_object* v_reuseFailAlloc_1975_; 
v_reuseFailAlloc_1975_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1975_, 0, v_a_1969_);
v___x_1974_ = v_reuseFailAlloc_1975_;
goto v_reusejp_1973_;
}
v_reusejp_1973_:
{
return v___x_1974_;
}
}
}
}
else
{
lean_dec_ref_known(v_tail_1928_, 2);
goto v___jp_1907_;
}
}
else
{
lean_dec(v_tail_1928_);
goto v___jp_1907_;
}
}
}
else
{
lean_dec(v_head_1927_);
if (lean_obj_tag(v_tail_1928_) == 1)
{
lean_object* v_tail_1977_; 
v_tail_1977_ = lean_ctor_get(v_tail_1928_, 1);
if (lean_obj_tag(v_tail_1977_) == 0)
{
lean_object* v_head_1978_; uint8_t v___x_1979_; lean_object* v___x_1980_; lean_object* v___x_1981_; 
v_head_1978_ = lean_ctor_get(v_tail_1928_, 0);
lean_inc(v_head_1978_);
lean_dec_ref_known(v_tail_1928_, 2);
v___x_1979_ = 0;
v___x_1980_ = lean_box(0);
v___x_1981_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute(v_head_1978_, v___x_1979_, v___x_1980_, v___x_1979_, v___x_1979_);
lean_dec(v_head_1978_);
if (lean_obj_tag(v___x_1981_) == 0)
{
lean_object* v___x_1983_; uint8_t v_isShared_1984_; uint8_t v_isSharedCheck_1989_; 
v_isSharedCheck_1989_ = !lean_is_exclusive(v___x_1981_);
if (v_isSharedCheck_1989_ == 0)
{
lean_object* v_unused_1990_; 
v_unused_1990_ = lean_ctor_get(v___x_1981_, 0);
lean_dec(v_unused_1990_);
v___x_1983_ = v___x_1981_;
v_isShared_1984_ = v_isSharedCheck_1989_;
goto v_resetjp_1982_;
}
else
{
lean_dec(v___x_1981_);
v___x_1983_ = lean_box(0);
v_isShared_1984_ = v_isSharedCheck_1989_;
goto v_resetjp_1982_;
}
v_resetjp_1982_:
{
lean_object* v___x_1985_; lean_object* v___x_1987_; 
v___x_1985_ = l_main___boxed__const__2;
if (v_isShared_1984_ == 0)
{
lean_ctor_set(v___x_1983_, 0, v___x_1985_);
v___x_1987_ = v___x_1983_;
goto v_reusejp_1986_;
}
else
{
lean_object* v_reuseFailAlloc_1988_; 
v_reuseFailAlloc_1988_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1988_, 0, v___x_1985_);
v___x_1987_ = v_reuseFailAlloc_1988_;
goto v_reusejp_1986_;
}
v_reusejp_1986_:
{
return v___x_1987_;
}
}
}
else
{
lean_object* v_a_1991_; lean_object* v___x_1993_; uint8_t v_isShared_1994_; uint8_t v_isSharedCheck_1998_; 
v_a_1991_ = lean_ctor_get(v___x_1981_, 0);
v_isSharedCheck_1998_ = !lean_is_exclusive(v___x_1981_);
if (v_isSharedCheck_1998_ == 0)
{
v___x_1993_ = v___x_1981_;
v_isShared_1994_ = v_isSharedCheck_1998_;
goto v_resetjp_1992_;
}
else
{
lean_inc(v_a_1991_);
lean_dec(v___x_1981_);
v___x_1993_ = lean_box(0);
v_isShared_1994_ = v_isSharedCheck_1998_;
goto v_resetjp_1992_;
}
v_resetjp_1992_:
{
lean_object* v___x_1996_; 
if (v_isShared_1994_ == 0)
{
v___x_1996_ = v___x_1993_;
goto v_reusejp_1995_;
}
else
{
lean_object* v_reuseFailAlloc_1997_; 
v_reuseFailAlloc_1997_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1997_, 0, v_a_1991_);
v___x_1996_ = v_reuseFailAlloc_1997_;
goto v_reusejp_1995_;
}
v_reusejp_1995_:
{
return v___x_1996_;
}
}
}
}
else
{
lean_object* v_head_1999_; lean_object* v_head_2000_; lean_object* v_tail_2001_; lean_object* v___x_2002_; uint8_t v___x_2003_; 
lean_inc_ref(v_tail_1977_);
v_head_1999_ = lean_ctor_get(v_tail_1928_, 0);
lean_inc(v_head_1999_);
lean_dec_ref_known(v_tail_1928_, 2);
v_head_2000_ = lean_ctor_get(v_tail_1977_, 0);
lean_inc(v_head_2000_);
v_tail_2001_ = lean_ctor_get(v_tail_1977_, 1);
lean_inc(v_tail_2001_);
lean_dec_ref_known(v_tail_1977_, 2);
v___x_2002_ = ((lean_object*)(l_main___closed__3));
v___x_2003_ = lean_string_dec_eq(v_head_2000_, v___x_2002_);
if (v___x_2003_ == 0)
{
lean_object* v___x_2004_; uint8_t v___x_2005_; 
v___x_2004_ = ((lean_object*)(l_main___closed__4));
v___x_2005_ = lean_string_dec_eq(v_head_2000_, v___x_2004_);
lean_dec(v_head_2000_);
if (v___x_2005_ == 0)
{
lean_dec(v_tail_2001_);
lean_dec(v_head_1999_);
goto v___jp_1907_;
}
else
{
if (lean_obj_tag(v_tail_2001_) == 1)
{
lean_object* v_tail_2006_; 
v_tail_2006_ = lean_ctor_get(v_tail_2001_, 1);
if (lean_obj_tag(v_tail_2006_) == 0)
{
lean_object* v_head_2007_; lean_object* v___x_2008_; lean_object* v___x_2009_; 
v_head_2007_ = lean_ctor_get(v_tail_2001_, 0);
lean_inc(v_head_2007_);
lean_dec_ref_known(v_tail_2001_, 2);
v___x_2008_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2008_, 0, v_head_2007_);
v___x_2009_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute(v_head_1999_, v___x_2003_, v___x_2008_, v___x_2003_, v___x_2003_);
lean_dec_ref_known(v___x_2008_, 1);
lean_dec(v_head_1999_);
if (lean_obj_tag(v___x_2009_) == 0)
{
lean_object* v___x_2011_; uint8_t v_isShared_2012_; uint8_t v_isSharedCheck_2017_; 
v_isSharedCheck_2017_ = !lean_is_exclusive(v___x_2009_);
if (v_isSharedCheck_2017_ == 0)
{
lean_object* v_unused_2018_; 
v_unused_2018_ = lean_ctor_get(v___x_2009_, 0);
lean_dec(v_unused_2018_);
v___x_2011_ = v___x_2009_;
v_isShared_2012_ = v_isSharedCheck_2017_;
goto v_resetjp_2010_;
}
else
{
lean_dec(v___x_2009_);
v___x_2011_ = lean_box(0);
v_isShared_2012_ = v_isSharedCheck_2017_;
goto v_resetjp_2010_;
}
v_resetjp_2010_:
{
lean_object* v___x_2013_; lean_object* v___x_2015_; 
v___x_2013_ = l_main___boxed__const__2;
if (v_isShared_2012_ == 0)
{
lean_ctor_set(v___x_2011_, 0, v___x_2013_);
v___x_2015_ = v___x_2011_;
goto v_reusejp_2014_;
}
else
{
lean_object* v_reuseFailAlloc_2016_; 
v_reuseFailAlloc_2016_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2016_, 0, v___x_2013_);
v___x_2015_ = v_reuseFailAlloc_2016_;
goto v_reusejp_2014_;
}
v_reusejp_2014_:
{
return v___x_2015_;
}
}
}
else
{
lean_object* v_a_2019_; lean_object* v___x_2021_; uint8_t v_isShared_2022_; uint8_t v_isSharedCheck_2026_; 
v_a_2019_ = lean_ctor_get(v___x_2009_, 0);
v_isSharedCheck_2026_ = !lean_is_exclusive(v___x_2009_);
if (v_isSharedCheck_2026_ == 0)
{
v___x_2021_ = v___x_2009_;
v_isShared_2022_ = v_isSharedCheck_2026_;
goto v_resetjp_2020_;
}
else
{
lean_inc(v_a_2019_);
lean_dec(v___x_2009_);
v___x_2021_ = lean_box(0);
v_isShared_2022_ = v_isSharedCheck_2026_;
goto v_resetjp_2020_;
}
v_resetjp_2020_:
{
lean_object* v___x_2024_; 
if (v_isShared_2022_ == 0)
{
v___x_2024_ = v___x_2021_;
goto v_reusejp_2023_;
}
else
{
lean_object* v_reuseFailAlloc_2025_; 
v_reuseFailAlloc_2025_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2025_, 0, v_a_2019_);
v___x_2024_ = v_reuseFailAlloc_2025_;
goto v_reusejp_2023_;
}
v_reusejp_2023_:
{
return v___x_2024_;
}
}
}
}
else
{
lean_dec_ref_known(v_tail_2001_, 2);
lean_dec(v_head_1999_);
goto v___jp_1907_;
}
}
else
{
lean_dec(v_tail_2001_);
lean_dec(v_head_1999_);
goto v___jp_1907_;
}
}
}
else
{
lean_dec(v_head_2000_);
if (lean_obj_tag(v_tail_2001_) == 0)
{
lean_object* v___x_2027_; uint8_t v___x_2028_; lean_object* v___x_2029_; 
v___x_2027_ = lean_box(0);
v___x_2028_ = 0;
v___x_2029_ = l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_execute(v_head_1999_, v___x_2003_, v___x_2027_, v___x_2028_, v___x_2028_);
lean_dec(v_head_1999_);
if (lean_obj_tag(v___x_2029_) == 0)
{
lean_object* v___x_2031_; uint8_t v_isShared_2032_; uint8_t v_isSharedCheck_2037_; 
v_isSharedCheck_2037_ = !lean_is_exclusive(v___x_2029_);
if (v_isSharedCheck_2037_ == 0)
{
lean_object* v_unused_2038_; 
v_unused_2038_ = lean_ctor_get(v___x_2029_, 0);
lean_dec(v_unused_2038_);
v___x_2031_ = v___x_2029_;
v_isShared_2032_ = v_isSharedCheck_2037_;
goto v_resetjp_2030_;
}
else
{
lean_dec(v___x_2029_);
v___x_2031_ = lean_box(0);
v_isShared_2032_ = v_isSharedCheck_2037_;
goto v_resetjp_2030_;
}
v_resetjp_2030_:
{
lean_object* v___x_2033_; lean_object* v___x_2035_; 
v___x_2033_ = l_main___boxed__const__2;
if (v_isShared_2032_ == 0)
{
lean_ctor_set(v___x_2031_, 0, v___x_2033_);
v___x_2035_ = v___x_2031_;
goto v_reusejp_2034_;
}
else
{
lean_object* v_reuseFailAlloc_2036_; 
v_reuseFailAlloc_2036_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2036_, 0, v___x_2033_);
v___x_2035_ = v_reuseFailAlloc_2036_;
goto v_reusejp_2034_;
}
v_reusejp_2034_:
{
return v___x_2035_;
}
}
}
else
{
lean_object* v_a_2039_; lean_object* v___x_2041_; uint8_t v_isShared_2042_; uint8_t v_isSharedCheck_2046_; 
v_a_2039_ = lean_ctor_get(v___x_2029_, 0);
v_isSharedCheck_2046_ = !lean_is_exclusive(v___x_2029_);
if (v_isSharedCheck_2046_ == 0)
{
v___x_2041_ = v___x_2029_;
v_isShared_2042_ = v_isSharedCheck_2046_;
goto v_resetjp_2040_;
}
else
{
lean_inc(v_a_2039_);
lean_dec(v___x_2029_);
v___x_2041_ = lean_box(0);
v_isShared_2042_ = v_isSharedCheck_2046_;
goto v_resetjp_2040_;
}
v_resetjp_2040_:
{
lean_object* v___x_2044_; 
if (v_isShared_2042_ == 0)
{
v___x_2044_ = v___x_2041_;
goto v_reusejp_2043_;
}
else
{
lean_object* v_reuseFailAlloc_2045_; 
v_reuseFailAlloc_2045_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2045_, 0, v_a_2039_);
v___x_2044_ = v_reuseFailAlloc_2045_;
goto v_reusejp_2043_;
}
v_reusejp_2043_:
{
return v___x_2044_;
}
}
}
}
else
{
lean_dec(v_tail_2001_);
lean_dec(v_head_1999_);
goto v___jp_1907_;
}
}
}
}
else
{
lean_dec(v_tail_1928_);
goto v___jp_1907_;
}
}
}
else
{
lean_dec(v_args_1905_);
goto v___jp_1907_;
}
v___jp_1907_:
{
lean_object* v___x_1908_; lean_object* v___x_1909_; 
v___x_1908_ = ((lean_object*)(l_main___closed__0));
v___x_1909_ = l_IO_eprintln___at___00__private_Init_System_IO_0__IO_eprintlnAux_spec__0(v___x_1908_);
if (lean_obj_tag(v___x_1909_) == 0)
{
lean_object* v___x_1911_; uint8_t v_isShared_1912_; uint8_t v_isSharedCheck_1917_; 
v_isSharedCheck_1917_ = !lean_is_exclusive(v___x_1909_);
if (v_isSharedCheck_1917_ == 0)
{
lean_object* v_unused_1918_; 
v_unused_1918_ = lean_ctor_get(v___x_1909_, 0);
lean_dec(v_unused_1918_);
v___x_1911_ = v___x_1909_;
v_isShared_1912_ = v_isSharedCheck_1917_;
goto v_resetjp_1910_;
}
else
{
lean_dec(v___x_1909_);
v___x_1911_ = lean_box(0);
v_isShared_1912_ = v_isSharedCheck_1917_;
goto v_resetjp_1910_;
}
v_resetjp_1910_:
{
lean_object* v___x_1913_; lean_object* v___x_1915_; 
v___x_1913_ = l_main___boxed__const__1;
if (v_isShared_1912_ == 0)
{
lean_ctor_set(v___x_1911_, 0, v___x_1913_);
v___x_1915_ = v___x_1911_;
goto v_reusejp_1914_;
}
else
{
lean_object* v_reuseFailAlloc_1916_; 
v_reuseFailAlloc_1916_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1916_, 0, v___x_1913_);
v___x_1915_ = v_reuseFailAlloc_1916_;
goto v_reusejp_1914_;
}
v_reusejp_1914_:
{
return v___x_1915_;
}
}
}
else
{
lean_object* v_a_1919_; lean_object* v___x_1921_; uint8_t v_isShared_1922_; uint8_t v_isSharedCheck_1926_; 
v_a_1919_ = lean_ctor_get(v___x_1909_, 0);
v_isSharedCheck_1926_ = !lean_is_exclusive(v___x_1909_);
if (v_isSharedCheck_1926_ == 0)
{
v___x_1921_ = v___x_1909_;
v_isShared_1922_ = v_isSharedCheck_1926_;
goto v_resetjp_1920_;
}
else
{
lean_inc(v_a_1919_);
lean_dec(v___x_1909_);
v___x_1921_ = lean_box(0);
v_isShared_1922_ = v_isSharedCheck_1926_;
goto v_resetjp_1920_;
}
v_resetjp_1920_:
{
lean_object* v___x_1924_; 
if (v_isShared_1922_ == 0)
{
v___x_1924_ = v___x_1921_;
goto v_reusejp_1923_;
}
else
{
lean_object* v_reuseFailAlloc_1925_; 
v_reuseFailAlloc_1925_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1925_, 0, v_a_1919_);
v___x_1924_ = v_reuseFailAlloc_1925_;
goto v_reusejp_1923_;
}
v_reusejp_1923_:
{
return v___x_1924_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_main___boxed(lean_object* v_args_2047_, lean_object* v_a_2048_){
_start:
{
lean_object* v_res_2049_; 
v_res_2049_ = _lean_main(v_args_2047_);
return v_res_2049_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_lean1090_Impl(uint8_t builtin);
lean_object* initialize_lean1090_Impl_JSON(uint8_t builtin);
lean_object* initialize_Lean_Data_Json_Parser(uint8_t builtin);
lean_object* initialize_Lean_Data_Json_FromToJson_Basic(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_review_diagnostics_CPRCosts(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_lean1090_Impl(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_lean1090_Impl_JSON(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Data_Json_Parser(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Data_Json_FromToJson_Basic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_expectedMessages = _init_l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_expectedMessages();
lean_mark_persistent(l___private_review_diagnostics_CPRCosts_0__Lean1090_Diagnostics_CPRCosts_expectedMessages);
l_main___boxed__const__1 = _init_l_main___boxed__const__1();
lean_mark_persistent(l_main___boxed__const__1);
l_main___boxed__const__2 = _init_l_main___boxed__const__2();
lean_mark_persistent(l_main___boxed__const__2);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_review_diagnostics_CPRCosts(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = lean_unbox_uint32(lean_io_result_get_value(res));
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
